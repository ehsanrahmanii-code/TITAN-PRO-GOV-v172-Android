# Changelog

## v1.7.2-UI-OVERLAP-SMC
- **ویجت یادگیری حاکم (UI)**: `W.learn` + داده `/api/learn` — نمایش reliability هر خانواده، نرخ برد، وضعیت کالیبراسیون
- **گیت همپوشانی/کول‌داون همان‌سمت**: `learn.same_side_overlap` از siglog (۴۵د، سقف ۴ سیگنال باز همان‌سمت)
- **SMC سبک از V84 technicals_core**:
  - `app/analysis/smc.py` — Order Block / Fair Value Gap روی dataframe محلی
  - همبستگی BTC (Pearson) + فیلتر soft برای آلت‌های high-beta در نوسان بالا
  - boost/هشدار در technicals و وتوی soft در Governor
- ویجت Governor: پشتیبانی، مخالف، تضاد، نزدیک‌ترین OB/FVG

## v1.7.1-LEARN-LITE
- حلقه یادگیری سبک فایل‌محور + گیت R:R + SCORE_ECHO_CAP + رفع alias verdict/cons

## v1.7.0-V84-HARDENED
- آستانه‌های نامتقارن SHORT، support/contradiction، وزن‌های V84

## v1.6.1-GOV-INTEGRATED
- یکپارچگی x10/x12 در Governor
