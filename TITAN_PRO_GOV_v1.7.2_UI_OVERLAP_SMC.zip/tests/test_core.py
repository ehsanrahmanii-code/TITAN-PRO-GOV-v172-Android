"""Offline tests: synthetic data, no network. Run: python -m pytest -q   (or python tests/test_core.py)"""
import os, sys, tempfile, time
os.environ["TITAN_DATA"] = tempfile.mkdtemp()
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pandas as pd

from app.data import market
from app.analysis.technicals import analyze
from app.analysis.forecast import forecast_summary
from app.analysis.deep import deep_analyze
from app.exchange import paper


def synth(n=300, drift=0.0, vol=0.01, seed=1, start=100.0, iv=3600):
    rng = np.random.default_rng(seed)
    r = rng.normal(drift, vol, n)
    c = start * np.exp(np.cumsum(r))
    o = np.r_[start, c[:-1]]
    h = np.maximum(o, c) * (1 + np.abs(rng.normal(0, vol / 2, n)))
    l = np.minimum(o, c) * (1 - np.abs(rng.normal(0, vol / 2, n)))
    t0 = int(time.time()) // iv * iv - n * iv
    ot = pd.to_datetime([(t0 + i * iv) for i in range(n)], unit="s")
    return pd.DataFrame({"open_time": ot, "open": o, "high": h, "low": l, "close": c, "volume": rng.uniform(100, 200, n) * (1 + np.abs(r) * 50)})


def test_signal_sanity():
    up = analyze(synth(drift=0.004, seed=2), "X", "1h")
    dn = analyze(synth(drift=-0.004, seed=3), "X", "1h")
    assert up.score > 15 and dn.score < -15, (up.score, dn.score)
    assert up.side == "LONG" and dn.side == "SHORT", (up.side, dn.side)
    assert up.stop < up.entry < up.tp1 < up.tp2 < up.tp3
    assert dn.stop > dn.entry > dn.tp1 > dn.tp2 > dn.tp3
    assert 36 <= len(up.components) <= 41 and all(-1 <= c["s"] <= 1 for c in up.components)


def test_distribution_not_degenerate():
    sides = [analyze(synth(drift=0.0, seed=s), "X", "1h").side for s in range(40)]
    wait = sides.count("WAIT") / len(sides)
    assert 0.3 < wait < 0.97, wait


def test_forecast_deterministic_and_cone():
    df = synth(seed=5)
    a = forecast_summary(df, "WAIT", 16, "X1h")
    b = forecast_summary(df, "WAIT", 16, "X1h")
    assert a["candles"] == b["candles"]
    assert all(lo <= m <= hi for lo, m, hi in zip(a["bands"]["p10"], a["bands"]["p50"], a["bands"]["p90"]))
    tiny = synth(start=1e-5, seed=6)           # v1 seeded with int(price*1000)=0 for such coins
    assert forecast_summary(tiny, "WAIT", 16, "SHIB1h")["candles"]


def test_closed_only():
    df = synth(n=100)
    forming = df.copy()
    forming.loc[forming.index[-1], "open_time"] = pd.Timestamp.now('UTC').tz_localize(None).floor("h")
    assert len(market.closed_only(forming, "1h")) == 99
    assert len(market.closed_only(df, "1h")) == 100


def test_deep():
    fr = {tf: synth(drift=0.003, seed=i + 10) for i, tf in enumerate(["15m", "1h", "4h", "1d"])}
    d = deep_analyze(fr, "BTCUSDT", "1h")
    assert d["verdict"] in ("LONG", "SHORT", "WAIT") and d["narrative"]
    assert d["verdict"] == "LONG", d["consensus_score"]


def _open(side="LONG", lev=10):
    d = 1 if side == "LONG" else -1
    return paper.open_position("TESTUSDT", side, 100.0, 100 - 2 * d, 100 + 2 * d, 100 + 4 * d, 100 + 7 * d, leverage=lev)


def test_risk_sizing_not_multiplied_by_leverage():
    paper.reset_account()
    r = _open()
    assert r["ok"], r
    p = r["position"]
    loss_at_stop = abs(p["entry"] - p["stop"]) * p["qty"]
    assert abs(loss_at_stop - 100.0) < 3, loss_at_stop          # 1% of 10k, NOT 10%


def test_partial_tps_and_breakeven():
    paper.reset_account()
    p = _open()["position"]
    paper.mark_to_market({"TESTUSDT": 102.5}, lambda *a: (100.0, 102.5))
    acc = paper.get_account({"TESTUSDT": 102.5})
    pos = acc["open_positions"][0]
    assert pos["stage"] == 1 and pos["stop"] > 100.0 and pos["qty_left"] < p["qty"]
    paper.mark_to_market({"TESTUSDT": 104.5}, lambda *a: (102.4, 104.5))
    assert paper.get_account()["open_positions"][0]["stage"] == 2
    closed = paper.mark_to_market({"TESTUSDT": 107.5}, lambda *a: (104.4, 107.5))
    assert closed and closed[0]["reason"] == "tp3" and closed[0]["pnl"] > 0
    assert paper.get_account()["wins"] == 1


def test_wick_stop_detected():
    paper.reset_account()
    _open()
    closed = paper.mark_to_market({"TESTUSDT": 100.5}, lambda *a: (97.0, 100.6))   # price recovered, wick hit SL
    assert closed and closed[0]["reason"] == "stop" and closed[0]["pnl"] < 0
    assert -125 < closed[0]["pnl"] < -90


def test_short_side_and_manual_close_live_price():
    paper.reset_account()
    _open("SHORT")
    r = paper.close_position(paper.get_account()["open_positions"][0]["id"], 98.0)
    assert r["ok"] and r["pnl"] > 50


def test_corrupt_state_not_silently_reset():
    paper.reset_account(); _open()
    paper._ACC = None
    paper._FILE.write_text("{broken")
    acc = paper.get_account()
    assert acc["open_positions"], "must restore from backup"
    assert "backup" in acc["notice"]


def test_invalid_orders_rejected():
    paper.reset_account()
    assert not paper.open_position("AUSDT", "LONG", 100, 101, 102, 103)["ok"]
    assert not paper.open_position("AUSDT", "LONG", 100, 98, 99, 103)["ok"]


def test_flask_api():
    from app.web.app import app
    from app import settings
    c = app.test_client()
    assert c.get("/").status_code == 200
    assert c.get("/api/status").json["version"]
    assert c.get("/api/coin/..%2Fetc").status_code in (400, 404)
    assert c.post("/api/exchange/reset", headers={"Origin": "http://evil.example"}).status_code == 403
    r = c.post("/api/settings", json={"watchlist": ["btc", "ETHUSDT", "bad symbol!"], "ui": {"skin": "titan-ai"}})
    assert r.json["watchlist"] == ["BTCUSDT", "ETHUSDT"], r.json
    assert c.post("/api/settings", json={"watchlist": []}).status_code == 400
    assert c.get("/api/exchange").json["wallet"] > 0


def test_forecast_32_edge_and_levels():
    from app.analysis.forecast import forecast_summary
    df = synth(drift=0.002, seed=4); px = float(df.close.iloc[-1])
    lv = {"entry": px, "stop": px * 0.97, "tp1": px * 1.03, "tp2": px * 1.06, "tp3": px * 1.09}
    f = forecast_summary(df, "LONG", 32, "k", levels=lv); g = forecast_summary(df, "LONG", 32, "k", levels=lv)
    assert len(f["candles"]) == 32 and f["candles"] == g["candles"] and f["edge"] == g["edge"]       # deterministic
    for c in f["candles"]:
        assert c["high"] >= max(c["open"], c["close"]) - 1e-9 and c["low"] <= min(c["open"], c["close"]) + 1e-9
    e = f["edge"]
    assert 0 <= e["p_tp3"] <= e["p_tp2"] <= e["p_tp1"] <= 1 and abs(e["p_stop"] + e["p_tp1"] + e["p_open"] - 1) < 0.02, e
    assert len(f["step_prob"]) == 32 and sum(f["hist"]["counts"]) > 500
    assert forecast_summary(df, "WAIT", 32, "k")["edge"] is None


def test_new_components_and_extras():
    s = analyze(synth(drift=0.003, seed=9), "X", "1h")
    keys = {c["k"] for c in s.components}
    assert {"ichi", "srsi", "mfi", "cmf", "donch", "ha", "pat2"} <= keys
    ex = s.extras
    assert ex["vp"]["val"] <= ex["vp"]["poc"] <= ex["vp"]["vah"] and ex["fib"]["levels"] and ex["pivots"]["r1"] > ex["pivots"]["s1"]
    assert all(z["kind"] in ("R", "S") for z in s.levels["zones"])


def test_backtest_and_grade_and_depth():
    from app.analysis import backtest
    from app.analysis.grade import fuse
    from app.data.market import depth_metrics
    r = backtest.run(synth(n=420, drift=0.001, seed=3), "X", "1h")
    assert r.get("n", 0) == len(r.get("equity", [])) and "error" not in r
    assert fuse({"15m": 60, "1h": 60, "4h": -50, "1d": -50})[1] == "WAIT"       # higher-timeframe veto
    assert fuse({"15m": 60, "1h": 60, "4h": 50, "1d": 40})[1] == "LONG"
    m = depth_metrics([(100 - i * .1, 2) for i in range(50)], [(100.1 + i * .1, 1) for i in range(50)])
    assert m["ok"] and m["imb_1pct"] > 0 and m["spread_pct"] > 0


def test_new_api_endpoints():
    from app.web.app import app
    c = app.test_client()
    assert "per_tf" in c.get("/api/market").json
    assert c.get("/api/micro/..%2Fetc").status_code in (400, 404)
    assert c.get("/api/backtest/bad%20sym").status_code in (400, 404)


def test_patterns_engine():
    from app.analysis import patterns as P
    df = synth(n=320, drift=0.0, seed=11)
    F = P.candle_flags(df)
    assert set(F) <= set(P.INFO) and all(len(v) == len(df) for v in F.values())
    # hand-made bullish engulfing in a down-move must be detected on the last bar
    d2 = synth(n=120, drift=-0.004, seed=5).copy()
    i = len(d2) - 1; px = float(d2.close.iloc[i - 1])
    d2.loc[d2.index[i - 1], ["open", "close", "high", "low"]] = [px * 1.004, px, px * 1.0045, px * 0.998]
    d2.loc[d2.index[i], ["open", "close", "high", "low"]] = [px * 0.996, px * 1.012, px * 1.013, px * 0.995]
    names = {r["k"] for r in P.detect_recent(d2, 3)}
    assert "engulf_bull" in names, names
    st = P.pooled_stats([synth(n=300, drift=0.0, seed=s) for s in range(8)])
    assert "_base" in st and any(k != "_base" for k in st)
    for k, v in st.items():
        if k != "_base":
            assert v["h"] and all(0 <= z["win"] <= 100 for z in v["h"].values())
    assert P.verdict(None, 1)["level"] == "none"
    for z in P.structures(synth(n=200, drift=0.001, seed=3)):
        assert z["lines"] and 0 <= z["conf"] <= 1


def test_alerts_roundtrip_and_flow():
    from app.engine import alerts
    a = alerts.add({"type": "price", "symbol": "BTC", "op": ">", "price": 100.0})
    try:
        alerts.add({"type": "price", "symbol": "BTCUSDT", "op": "?", "price": 1})
        raise AssertionError("bad op accepted")
    except ValueError:
        pass
    assert not alerts.check(lambda s: 90.0, lambda s: {}, ["BTCUSDT"])
    fired = alerts.check(lambda s: 101.0, lambda s: {}, ["BTCUSDT"])
    assert fired and fired[0]["id"] == a["id"] and not alerts.check(lambda s: 150.0, lambda s: {}, ["BTCUSDT"])    # fires once
    s = alerts.add({"type": "signal", "symbol": "*", "min_grade": "B"})
    assert not alerts.check(lambda s_: 1, lambda s_: {"verdict": "WAIT", "grade": "—"}, ["ETHUSDT"])
    assert alerts.check(lambda s_: 1, lambda s_: {"verdict": "LONG", "grade": "A"}, ["ETHUSDT"])
    assert not alerts.check(lambda s_: 1, lambda s_: {"verdict": "LONG", "grade": "A"}, ["ETHUSDT"])            # same state: no repeat
    assert alerts.remove(a["id"]) and alerts.remove(s["id"]) and not alerts.remove("nope")
    f = analyze(synth(drift=0.002, seed=4), "X", "1h").extras["flow"]
    assert 0 <= f["buy_share"] <= 1 and len(f["cvd"]) == len(f["price"])


def test_planner_and_smc_and_osc():
    from app.analysis import planner, forecast
    df = synth(n=300, drift=0.002, seed=4)
    s = analyze(df, "X", "1h"); sim = forecast.simulate(df, 32, 600, "k")
    px = float(df.close.iloc[-1]); atr = s.indicators["atr"]
    for side in ("LONG", "SHORT"):
        r = planner.run(sim, side, px, atr, s.indicators, s.extras, s.levels["zones"])
        assert r["rows"] and all(0 <= x["p_fill"] <= 1 and x["ev_r"] is not None for x in r["rows"])
        d = 1 if side == "LONG" else -1
        for x in r["rows"]:
            assert (x["p"] - x["stop"]) * d > 0 and (x["tp1"] - x["p"]) * d > 0 and x["tp3"] != x["tp1"]
        if r["best"]:
            assert r["best"]["ev_r"] > 0 and r["best"]["p_fill"] >= 0.3
    ex = s.extras
    assert ex["smc"]["structure"]["trend"] in ("bull", "bear", "range", "expand", "squeeze") and ex["smc"]["range"]["zone"] in ("premium", "discount", "equilibrium")
    o = ex["osc"]; assert len(o["osc"]) == 12 and len(o["ma"]) == 12 and -100 <= o["all_score"] <= 100 and o["misc"]["psar_dir"] in ("up", "down")


def test_pending_orders_and_policy():
    from app.exchange import paper as ex, policy
    ex.reset_account()
    o = {"symbol": "BTCUSDT", "side": "LONG", "mode": "limit", "price": 95.0, "stop": 92.0, "tp1": 98.0, "tp2": 101.0, "tp3": 104.0, "valid_h": 4}
    assert ex.place_order(o)["ok"] and not ex.place_order(o)["ok"]                                        # one resting order per coin
    assert not ex.place_order({**o, "symbol": "ETHUSDT", "stop": 96.0})["ok"]                              # stop on the wrong side
    ex.mark_to_market({"BTCUSDT": 100.0}, None)
    assert len(ex.get_account({"BTCUSDT": 100.0})["orders"]) == 1                                         # not touched yet
    ex.mark_to_market({"BTCUSDT": 94.9}, None)
    a = ex.get_account({"BTCUSDT": 94.9})
    assert not a["orders"] and a["open_positions"] and abs(a["open_positions"][0]["entry"] - 95.0) < 1e-9    # limit fills at its own price
    ex.reset_account()
    assert ex.place_order({**o, "mode": "stop", "price": 105.0, "stop": 99.0, "tp1": 108.0, "tp2": 111.0, "tp3": 114.0})["ok"]
    ex.mark_to_market({"BTCUSDT": 98.0}, None)                                                              # stop level breached before the trigger -> cancelled
    assert not ex.get_account({"BTCUSDT": 98.0})["orders"]
    cfg = policy.effective()
    base = {"symbol": "ETHUSDT", "side": "LONG", "verdict": "LONG", "grade": "D", "cons": 60, "agree": 0.9, "plan": None, "ext_atr": 0, "rsi_extreme": False, "qv": 9e9,
            "evidence": {"n": 20, "avg_r": 0.1, "pf": 1.4, "t": 1.2, "dd": 3.0}, "open": [], "n_orders": 0, "risk_open_pct": 0, "corr": lambda s: 0.0, "btc_cons": 10, "vol_hot": False}
    d = policy.evaluate(cfg, base); assert not d["ok"] and any("درجه" in f for f in d["fails"])
    good = {**base, "grade": "A", "plan": {"name": "EMA 21", "mode": "limit", "p": 100, "stop": 98, "tp1": 102.4, "tp2": 104.4, "tp3": 107, "ev_r": 0.3, "p_tp1": 0.55}}
    assert policy.evaluate(cfg, good)["ok"]
    assert not policy.evaluate(cfg, {**good, "evidence": {"n": 20, "avg_r": -0.3, "pf": 0.7, "t": -2.0, "dd": 9.0}})["ok"]   # coin-level evidence blocks it
    assert not policy.evaluate(cfg, {**good, "evidence": {"n": 20, "avg_r": 0.2, "pf": 1.5, "t": 1.5, "dd": 12.0}})["ok"]  # drawdown gate (key "dd") really runs
    assert not policy.evaluate(cfg, {**good, "evidence": {"n": 20, "avg_r": 0.1, "pf": 1.3, "t": 0.2, "dd": 3.0}})["ok"]    # positive mean but statistically indistinguishable from zero
    assert not policy.evaluate(cfg, {**good, "evidence": {"n": 20, "avg_r": 0.1}})["ok"]                                    # incomplete evidence never passes
    assert not policy.evaluate(cfg, {**good, "open": [{"symbol": "A", "side": "LONG"}, {"symbol": "B", "side": "LONG"}]})["ok"]   # same-direction cap
    ex.reset_account()


def test_signal_track_record():
    from app.engine import siglog
    siglog._STATE.update(loaded=True, entries=[], last={})
    t0 = 1_000_000
    assert siglog.tick({"AAAUSDT": {"verdict": "LONG", "grade": "A", "cons": 60}, "BBBUSDT": {"verdict": "SHORT", "grade": "C", "cons": -50}}, {"AAAUSDT": 100.0, "BBBUSDT": 50.0}, now=t0) == 2
    assert siglog.tick({"AAAUSDT": {"verdict": "LONG", "grade": "A", "cons": 61}}, {"AAAUSDT": 101.0}, now=t0 + 60) == 0           # same verdict -> not a new signal
    siglog.tick({"AAAUSDT": {"verdict": "LONG"}, "BBBUSDT": {"verdict": "SHORT"}}, {"AAAUSDT": 103.0, "BBBUSDT": 48.0}, now=t0 + 4 * 3600 + 5)
    v = siglog.view()
    assert v["resolved"] == 2 and v["stats"]["A"]["avg"] == 3.0 and v["stats"]["C"]["avg"] == 4.0 and v["stats"]["A"]["win"] == 100.0       # short wins when price falls
    assert siglog.tick({"AAAUSDT": {"verdict": "WAIT"}}, {"AAAUSDT": 100.0}, now=t0 + 5 * 3600) == 0
    assert siglog.tick({"AAAUSDT": {"verdict": "LONG", "grade": "B", "cons": 55}}, {"AAAUSDT": 100.0}, now=t0 + 6 * 3600) == 1        # re-armed after WAIT
    siglog._STATE.update(loaded=True, entries=[], last={})


def test_x10_indicators_and_integration():
    import math
    from app.analysis import x10
    for seed, drift in ((3, 0.0008), (5, -0.001), (8, 0.0)):
        df = synth(n=300, drift=drift, vol=0.008, seed=seed, start=100, iv=3600)
        r = x10.compute(df)
        assert r["n"] == 10 and set(r["items"]) == set(x10.KEYS), r["items"].keys()
        assert 0 <= r["quality"] <= 100 and -100 <= r["timing"] <= 100 and -100 <= r["flow"] <= 100
        for k, it in r["items"].items():
            assert -1.0 <= it["s"] <= 1.0 and it["t"] and it["role"] in ("quality", "timing", "flow"), k
            assert it["v"] is None or math.isfinite(it["v"]), k
        assert x10.compute(df) == r                                           # deterministic
    assert x10.compute(synth(n=40, seed=1)) is not None                       # short history never raises
    up = analyze(synth(drift=0.004, seed=2), "X", "1h")
    lv = up.levels
    assert 0 <= lv["quality"] <= 100 and "entry_zone" in lv and "tp_notes" in lv and "refs" in lv
    assert any(c["k"].startswith("x_") for c in up.components) and sum(1 for c in up.components if c["k"][2:] in ("hurst", "chop", "linreg", "vol_exp", "crsi", "fisher", "vwapz", "sqz", "klinger", "vortex")) == 10


def test_lab_report_and_performance():
    from app.analysis import lab
    from app.analysis.forecast import forecast_summary
    from app.exchange import paper as ex
    sigs, fcs = {}, {}
    for tf, seed in (("15m", 2), ("1h", 3), ("4h", 4), ("1d", 5)):
        df = synth(drift=0.003, seed=seed)
        s = analyze(df, "BTCUSDT", tf)
        sigs[tf] = s.to_dict(); fcs[tf] = forecast_summary(df, s.side, 32, "k", levels=None)
    deep = {"verdict": "LONG", "consensus_score": 55.0, "primary_tf": "1h", "signal": sigs["1h"], "grade": {"grade": "B", "why": []}, "conviction": 0.7}
    r = lab.build("BTCUSDT", sigs, fcs, deep, micro={"depth": {"ok": True, "imb_1pct": 0.2, "spread_pct": 0.02}, "derivs": {"ok": True, "funding_pct": 0.09, "ls_buy": 0.7}}, price=100.0)
    assert r["ok"] and r["final"] in ("LONG", "SHORT", "WAIT") and 0 < r["confidence"] < 1
    assert len(r["matrix"]) == 10 and all(set(m["cells"]) == {"15m", "1h", "4h", "1d"} for m in r["matrix"])
    assert r["micro"]["ok"] and any("فاندینگ" in f for f in r["micro"]["facts"])      # crowded-long funding is flagged
    assert r["narrative"] and r["action"] and abs(sum(p["w"] for p in r["confidence_parts"]) - 1.0) < 1e-9
    assert lab.build("X", {}, {}, {})["ok"] is False
    deep["verdict"] = "WAIT"
    assert lab.build("BTCUSDT", sigs, fcs, deep)["final"] == "WAIT"                       # the lab never overrides a core veto
    ex.reset_account()
    assert ex.performance()["n"] == 0
    assert ex.open_position("BTCUSDT", "LONG", 100.0, 98.0, 101.0, 103.0, 105.0, leverage=5, source="auto", grade="A")["ok"]
    ex.mark_to_market({"BTCUSDT": 98.0}, None)                                                              # stop level breached before the trigger -> cancelled
    assert not ex.get_account({"BTCUSDT": 98.0})["orders"]
    cfg = policy.effective()
    base = {"symbol": "ETHUSDT", "side": "LONG", "verdict": "LONG", "grade": "D", "cons": 60, "agree": 0.9, "plan": None, "ext_atr": 0, "rsi_extreme": False, "qv": 9e9,
            "evidence": {"n": 20, "avg_r": 0.1, "pf": 1.4, "t": 1.2, "dd": 3.0}, "open": [], "n_orders": 0, "risk_open_pct": 0, "corr": lambda s: 0.0, "btc_cons": 10, "vol_hot": False}
    d = policy.evaluate(cfg, base); assert not d["ok"] and any("درجه" in f for f in d["fails"])
    good = {**base, "grade": "A", "plan": {"name": "EMA 21", "mode": "limit", "p": 100, "stop": 98, "tp1": 102.4, "tp2": 104.4, "tp3": 107, "ev_r": 0.3, "p_tp1": 0.55}}
    assert policy.evaluate(cfg, good)["ok"]
    assert not policy.evaluate(cfg, {**good, "evidence": {"n": 20, "avg_r": -0.3, "pf": 0.7, "t": -2.0, "dd": 9.0}})["ok"]   # coin-level evidence blocks it
    assert not policy.evaluate(cfg, {**good, "evidence": {"n": 20, "avg_r": 0.2, "pf": 1.5, "t": 1.5, "dd": 12.0}})["ok"]  # drawdown gate (key "dd") really runs
    assert not policy.evaluate(cfg, {**good, "evidence": {"n": 20, "avg_r": 0.1, "pf": 1.3, "t": 0.2, "dd": 3.0}})["ok"]    # positive mean but statistically indistinguishable from zero
    assert not policy.evaluate(cfg, {**good, "evidence": {"n": 20, "avg_r": 0.1}})["ok"]                                    # incomplete evidence never passes
    assert not policy.evaluate(cfg, {**good, "open": [{"symbol": "A", "side": "LONG"}, {"symbol": "B", "side": "LONG"}]})["ok"]   # same-direction cap
    ex.reset_account()


def test_signal_track_record():
    from app.engine import siglog
    siglog._STATE.update(loaded=True, entries=[], last={})
    t0 = 1_000_000
    assert siglog.tick({"AAAUSDT": {"verdict": "LONG", "grade": "A", "cons": 60}, "BBBUSDT": {"verdict": "SHORT", "grade": "C", "cons": -50}}, {"AAAUSDT": 100.0, "BBBUSDT": 50.0}, now=t0) == 2
    assert siglog.tick({"AAAUSDT": {"verdict": "LONG", "grade": "A", "cons": 61}}, {"AAAUSDT": 101.0}, now=t0 + 60) == 0           # same verdict -> not a new signal
    siglog.tick({"AAAUSDT": {"verdict": "LONG"}, "BBBUSDT": {"verdict": "SHORT"}}, {"AAAUSDT": 103.0, "BBBUSDT": 48.0}, now=t0 + 4 * 3600 + 5)
    v = siglog.view()
    assert v["resolved"] == 2 and v["stats"]["A"]["avg"] == 3.0 and v["stats"]["C"]["avg"] == 4.0 and v["stats"]["A"]["win"] == 100.0       # short wins when price falls
    assert siglog.tick({"AAAUSDT": {"verdict": "WAIT"}}, {"AAAUSDT": 100.0}, now=t0 + 5 * 3600) == 0
    assert siglog.tick({"AAAUSDT": {"verdict": "LONG", "grade": "B", "cons": 55}}, {"AAAUSDT": 100.0}, now=t0 + 6 * 3600) == 1        # re-armed after WAIT
    siglog._STATE.update(loaded=True, entries=[], last={})


def test_x10_indicators_and_integration():
    import math
    from app.analysis import x10
    for seed, drift in ((3, 0.0008), (5, -0.001), (8, 0.0)):
        df = synth(n=300, drift=drift, vol=0.008, seed=seed, start=100, iv=3600)
        r = x10.compute(df)
        assert r["n"] == 10 and set(r["items"]) == set(x10.KEYS), r["items"].keys()
        assert 0 <= r["quality"] <= 100 and -100 <= r["timing"] <= 100 and -100 <= r["flow"] <= 100
        for k, it in r["items"].items():
            assert -1.0 <= it["s"] <= 1.0 and it["t"] and it["role"] in ("quality", "timing", "flow"), k
            assert it["v"] is None or math.isfinite(it["v"]), k
        assert x10.compute(df) == r                                           # deterministic
    assert x10.compute(synth(n=40, seed=1)) is not None                       # short history never raises
    up = analyze(synth(drift=0.004, seed=2), "X", "1h")
    lv = up.levels
    assert 0 <= lv["quality"] <= 100 and "entry_zone" in lv and "tp_notes" in lv and "refs" in lv
    assert any(c["k"].startswith("x_") for c in up.components) and sum(1 for c in up.components if c["k"][2:] in ("hurst", "chop", "linreg", "vol_exp", "crsi", "fisher", "vwapz", "sqz", "klinger", "vortex")) == 10


def test_lab_report_and_performance():
    from app.analysis import lab
    from app.analysis.forecast import forecast_summary
    from app.exchange import paper as ex
    sigs, fcs = {}, {}
    for tf, seed in (("15m", 2), ("1h", 3), ("4h", 4), ("1d", 5)):
        df = synth(drift=0.003, seed=seed)
        s = analyze(df, "BTCUSDT", tf)
        sigs[tf] = s.to_dict(); fcs[tf] = forecast_summary(df, s.side, 32, "k", levels=None)
    deep = {"verdict": "LONG", "consensus_score": 55.0, "primary_tf": "1h", "signal": sigs["1h"], "grade": {"grade": "B", "why": []}, "conviction": 0.7}
    r = lab.build("BTCUSDT", sigs, fcs, deep, micro={"depth": {"ok": True, "imb_1pct": 0.2, "spread_pct": 0.02}, "derivs": {"ok": True, "funding_pct": 0.09, "ls_buy": 0.7}}, price=100.0)
    assert r["ok"] and r["final"] in ("LONG", "SHORT", "WAIT") and 0 < r["confidence"] < 1
    assert len(r["matrix"]) == 10 and all(set(m["cells"]) == {"15m", "1h", "4h", "1d"} for m in r["matrix"])
    assert r["micro"]["ok"] and any("فاندینگ" in f for f in r["micro"]["facts"])      # crowded-long funding is flagged
    assert r["narrative"] and r["action"] and abs(sum(p["w"] for p in r["confidence_parts"]) - 1.0) < 1e-9
    assert lab.build("X", {}, {}, {})["ok"] is False
    deep["verdict"] = "WAIT"
    assert lab.build("BTCUSDT", sigs, fcs, deep)["final"] == "WAIT"                       # the lab never overrides a core veto
    ex.reset_account()
    assert ex.performance()["n"] == 0
    assert ex.open_position("BTCUSDT", "LONG", 100.0, 98.0, 101.0, 103.0, 105.0, leverage=5, source="auto", grade="A")["ok"]
    ex.mark_to_market({"BTCUSDT": 98.0}, None)                                              # stop out -> loss
    p = ex.performance()
    assert p["n"] == 1 and p["losses"] == 1 and p["win_rate"] == 0.0 and p["by_source"]["auto"]["n"] == 1 and p["by_grade"]["A"]["n"] == 1
    ex.reset_account()


def test_policy_quality_and_timing_gates():
    from app.exchange import policy
    for m in policy.MODES.values():
        assert "min_quality" in m and "min_timing" in m
    assert policy.MODES["safe"]["min_quality"] > policy.MODES["balanced"]["min_quality"] >= policy.MODES["active"]["min_quality"]


# ───────────────────────── v3.2.1 regression tests ─────────────────────────
def test_indicators_never_nan_on_degenerate_data():
    import math
    n = 120
    t = pd.date_range("2026-01-01", periods=n, freq="1h")
    for kind in ("flat", "up"):
        c = np.full(n, 100.0) if kind == "flat" else 100 + np.arange(n) * 0.5
        o = np.r_[c[0], c[:-1]]
        df = pd.DataFrame({"open_time": t, "open": o, "high": np.maximum(o, c) * 1.001, "low": np.minimum(o, c) * 0.999, "close": c, "volume": np.full(n, 1000.0)})
        d = analyze(df, "X", "1h").to_dict()

        def walk(x):
            if isinstance(x, dict):
                for v in x.values(): walk(v)
            elif isinstance(x, (list, tuple)):
                for v in x: walk(v)
            elif isinstance(x, float):
                assert math.isfinite(x), (kind, x)
        walk(d)
    assert d["indicators"]["rsi"] == 100.0                                              # only gains -> 100, not NaN


def test_json_never_contains_nan():
    import json
    from app.web.app import app
    with app.test_request_context():
        from flask import jsonify
        body = jsonify({"a": float("nan"), "b": [float("inf"), 1.5], "c": {"d": np.float64("nan"), "e": np.int64(3)}}).get_data(as_text=True)
    assert json.loads(body) == {"a": None, "b": [None, 1.5], "c": {"d": None, "e": 3}}          # strict JSON.parse-safe


def test_foreign_host_header_blocked():
    from app.web.app import app
    c = app.test_client()
    assert c.get("/api/status", base_url="http://evil.example").status_code == 403           # DNS-rebinding style request
    assert c.get("/api/status").status_code == 200


def test_kline_cache_respects_requested_limit():
    calls = []

    def fake(sym, interval, limit):
        calls.append(limit)
        return synth(limit)
    old = market._download
    market._download = fake
    try:
        market._KCACHE.clear()
        assert len(market.fetch_klines("ZZZUSDT", "1h", 60)) == 60
        assert len(market.fetch_klines("ZZZUSDT", "1h", 300)) == 300                       # used to return the 60 cached candles (EMA200 never warm)
        assert len(market.fetch_klines("ZZZUSDT", "1h", 60)) == 300 and calls == [60, 300]  # bigger cached frame answers a smaller request
    finally:
        market._download = old
        market._KCACHE.clear()


def test_closed_only_does_not_mutate_cached_frame():
    df = synth(100)
    market.closed_only(df, "1h")
    assert "gaps" not in df.attrs and "stale" not in df.attrs


def test_liquidation_always_beyond_stop():
    old = paper.MAX_LEVERAGE
    paper.MAX_LEVERAGE = 125                                                                  # the invariant must not depend on the leverage cap
    try:
        for sd_pct in (0.3, 0.6, 1.0, 2.0, 5.0):
            paper.reset_account()
            stop = 100.0 * (1 - sd_pct / 100)
            r = paper.open_position("BTCUSDT", "LONG", 100.0, stop, 100 + sd_pct, 100 + 2 * sd_pct, 100 + 3 * sd_pct, leverage=125)
            assert r["ok"], r
            p = r["position"]
            assert (p["entry"] - p["liq"]) >= 1.5 * (p["entry"] - p["stop"]), (sd_pct, p["leverage"], p["liq"], p["stop"])
    finally:
        paper.MAX_LEVERAGE = old
        paper.reset_account()


def test_risk_pct_is_clamped():
    paper.reset_account()
    r = paper.open_position("BTCUSDT", "LONG", 100.0, 98.0, 102.0, 104.0, 106.0, leverage=5, risk_pct=80.0)
    assert r["ok"] and r["position"]["risk_usd"] <= 10_000 * 0.031                           # 80 % request -> capped at 3 %
    paper.reset_account()


def test_drawdown_pause_can_be_released():
    paper.reset_account()
    acc = paper._load()
    acc.wallet, acc.peak_equity, acc.trades = 8_500.0, 10_000.0, 6
    assert paper.pause_state({})["paused"]                                                    # 15 % below the peak
    paper.clear_pause()
    assert not paper.pause_state({})["paused"]                                                # used to re-arm immediately: the button did nothing
    paper.reset_account()


def test_profit_factor_without_losses_is_capped_not_gross_profit():
    paper.reset_account()
    assert paper.open_position("BTCUSDT", "LONG", 100.0, 98.0, 101.0, 103.0, 105.0, leverage=5)["ok"]
    paper.mark_to_market({"BTCUSDT": 106.0}, None)
    assert paper.get_account({})["stats"]["profit_factor"] == paper.PF_CAP and paper.performance()["pf"] == paper.PF_CAP
    paper.reset_account()


def test_btc_alignment_uses_time_not_row_position():
    from app.engine import scanner
    a, b = synth(200, seed=5), synth(200, seed=6)
    b2 = b.iloc[:-3].copy()                                                                   # b lags by 3 bars
    ra, rb = scanner._aligned_returns(a, b2, 100)
    ref_a = np.diff(np.log(a["close"].values[-103 - 1:-3].astype(float)))[-100:]
    assert len(ra) == 100 and np.allclose(ra, ref_a)


def test_siglog_attaches_levels_and_resolves_path():
    from app.engine import siglog
    siglog._STATE.update(loaded=True, entries=[], last={})
    assert siglog.is_new("AAAUSDT", "LONG") and not siglog.is_new("AAAUSDT", "WAIT")
    siglog.tick({"AAAUSDT": {"verdict": "LONG", "grade": "A", "cons": 60, "stop": 98.0, "tp1": 103.0}}, {"AAAUSDT": 100.0}, now=2_000_000)
    assert not siglog.is_new("AAAUSDT", "LONG")
    siglog.tick({"AAAUSDT": {"verdict": "LONG"}}, {"AAAUSDT": 103.5}, now=2_000_060)
    assert siglog.view()["path"]["tp1"] == 1


def test_planner_pick_requires_edge_above_noise():
    from app.analysis import planner
    assert "ev_se" in (planner._replay(__import__("app.analysis.forecast", fromlist=["x"]).simulate(synth(300, drift=0.003, seed=9), 32, 600, "t"), "LONG", 100.0, 98.0, (102.4, 104.4, 107.0), "market") or {"ev_se": 0})


def test_stale_data_blocks_auto_pass():
    from app.engine import scanner
    from app.exchange import paper as ex
    ex.reset_account()
    sym = "STALEUSDT"
    df = synth(300, drift=0.004, seed=2)
    sig = analyze(df, sym, "1h").to_dict()
    scanner._FRAMES[scanner._key(sym, "1h")] = df
    scanner._CACHE[scanner._key(sym, "1h")] = {"signal": sig, "forecast": {}, "ticker": {"price": float(df["close"].iloc[-1]), "quote_volume": 9e9}, "klines": [], "updated": time.time() - 3 * 3600, "stale": False}
    ex.set_auto_trade(True)
    scanner._auto_pass([sym], {sym: float(df["close"].iloc[-1])})
    a = ex.get_account({})
    assert not a["open_positions"] and not a["orders"]
    assert any("قدیمی" in x.get("text", "") for x in a["auto_log"])                      # the skip is explained, not silent
    ex.set_auto_trade(False)
    ex.reset_account()


def test_no_undefined_names_or_missing_module_attrs():
    import importlib.util, pathlib
    spec = importlib.util.spec_from_file_location("static_check", str(pathlib.Path(__file__).parent / "static_check.py"))
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    assert m.check() == []


def test_every_get_route_responds_without_500():
    """Sweeps all parameterless GET routes + symbol routes: catches NameError/AttributeError regressions in code paths no other test touches."""
    from app.web.app import app
    c = app.test_client()
    bad = []
    for rule in app.url_map.iter_rules():
        if "GET" not in rule.methods or rule.endpoint == "static":
            continue
        url = rule.rule
        for arg in rule.arguments:
            url = url.replace(f"<{arg}>", "BTCUSDT").replace(f"<string:{arg}>", "BTCUSDT")
        if "<" in url:
            continue
        r = c.get(url)
        if r.status_code >= 500 and r.status_code != 502:          # 502 = upstream exchange unreachable (expected offline)
            bad.append((url, r.status_code, r.get_data(as_text=True)[:120]))
    assert not bad, bad


# ───────────────────────── v3.3 tests ─────────────────────────
def test_context_evaluate_directions_and_missing_data():
    from app.engine import context
    assert context.evaluate({}, {}, None, {})["bias"] == 0.0 and context.evaluate(None, None, None, None)["parts"] == []     # no data -> no opinion
    crowd_long = context.evaluate({"ok": True, "funding_apr": 90.0, "ls_buy": 0.68}, None, None, None)
    assert crowd_long["bias"] < -0.2 and crowd_long["crowd"] == "longs"                                                 # crowded longs = bearish
    squeeze = context.evaluate({"ok": True, "funding_apr": -80.0, "ls_buy": 0.35}, None, None, None)
    assert squeeze["bias"] > 0.2 and squeeze["crowd"] == "shorts"
    assert context.evaluate({"ok": True, "oi_chg_24h": 9.0}, None, 3.0, None)["bias"] > 0                               # new money + rising price
    assert context.evaluate({"ok": True, "oi_chg_24h": 9.0}, None, -3.0, None)["bias"] < 0                              # new money + falling price
    assert context.evaluate(None, None, None, {"fng": 12})["bias"] > 0 and context.evaluate(None, None, None, {"fng": 90})["bias"] < 0
    thin = context.evaluate(None, {"ok": True, "spread_pct": 0.4, "bid_usd_1pct": 1e6, "ask_usd_1pct": 1e6, "imb_1pct": 0.0}, None, None)
    assert thin["liq_ok"] is False
    assert -1.0 <= context.evaluate({"ok": True, "funding_apr": 5000.0, "ls_buy": 0.99, "oi_chg_24h": -50}, {"ok": True, "imb_1pct": 1.0, "spread_pct": 0.01, "bid_usd_1pct": 9e9, "ask_usd_1pct": 9e9}, 9, {"fng": 1})["bias"] <= 1.0


def test_context_shifts_consensus_and_grade():
    from app.analysis.grade import fuse, grade_from
    base = fuse({"15m": 40, "1h": 40, "4h": 40, "1d": 40})
    up = fuse({"15m": 40, "1h": 40, "4h": 40, "1d": 40}, 1.0)
    assert up[0] == base[0] + 10 and fuse({"15m": 40, "1h": 40, "4h": 40, "1d": 40}, -1.0)[0] == base[0] - 10
    assert fuse({"15m": 40, "1h": 40, "4h": 45, "1d": 42}, -0.6)[1] == "WAIT"                                         # strong opposing context vetoes a moderate setup
    sg = {"1h": {"side": "LONG", "regime": "trend", "agree": .8, "risk_reward": 2.2, "warnings": [], "extras": {}}}
    pos = grade_from(sg, {}, "LONG", 50, "1h", {"bias": 0.5, "parts": [{"v": .5, "w": 1, "t": "x"}], "liq_ok": True})
    neg = grade_from(sg, {}, "LONG", 50, "1h", {"bias": -0.5, "parts": [{"v": -.5, "w": 1, "t": "x"}], "liq_ok": False})
    assert pos["points"] - neg["points"] == 3                                                                          # +1 aligned vs -1 opposed and -1 illiquid


def test_x11_items_and_no_lookahead():
    from app.analysis import x11
    df = synth(300, drift=0.002, seed=4)
    r = x11.compute(df, "1h")
    assert {"avwap", "donch", "prior", "rvol", "persist"} <= set(r["items"]) and all(-1 <= it["s"] <= 1 for it in r["items"].values())
    cut = df.iloc[:250]
    a = x11.compute(cut, "1h")
    b = x11.compute(pd.concat([cut, df.iloc[250:]]).iloc[:250], "1h")
    assert a["items"]["donch"]["s"] == b["items"]["donch"]["s"]                                                          # decisions at bar i never use later bars
    n = 120
    t = pd.date_range("2026-01-01", periods=n, freq="1h")
    flat = pd.DataFrame({"open_time": t, "open": 100.0, "high": 100.0, "low": 100.0, "close": 100.0, "volume": 0.0})
    x11.compute(flat, "1h")                                                                                             # degenerate data must not raise


def test_x11_sweep_detection():
    from app.analysis import x11
    t = pd.date_range("2026-01-01 00:00", periods=40, freq="1h")
    close = np.r_[np.full(24, 100.0), np.full(16, 99.0)]
    high = close + 0.5; low = close - 0.5
    high[28] = 103.0                                                    # wick above yesterday's high (100.5) today, close back below it
    df = pd.DataFrame({"open_time": t, "open": close, "high": high, "low": low, "close": close, "volume": 10.0})
    pr = x11.prior_levels(df, "1h")
    assert pr["swept_hi"] and pr["s"] < 0


def test_readiness_verdicts_and_track_gate():
    from app.engine import readiness
    assert readiness._stats([])["n"] == 0
    assert readiness.verdict(readiness._stats([1.0] * 10))["level"] == "insufficient"
    rng = np.random.default_rng(3)
    noise = list(rng.normal(0.0, 1.2, 80))
    assert readiness.verdict(readiness._stats(noise))["level"] in ("not_ready", "insufficient")                         # noise never earns a pass
    good = list(rng.normal(0.35, 1.0, 160))
    assert readiness.verdict(readiness._stats(good))["level"] == "candidate"
    paper.reset_account()
    acc = paper._load()
    acc.history = [{"id": str(i), "r": -0.9 if i % 5 else 0.5, "risk_usd": 50, "grade": "B", "side": "LONG", "reason": "SL"} for i in range(30)]
    ok, txt = readiness.track_gate("B", "LONG")
    assert not ok and "B" in txt and readiness.track_gate("A", "SHORT")[0]
    paper.reset_account()


def test_data_lives_only_in_www_and_legacy_is_migrated():
    import importlib, os, pathlib, shutil, tempfile
    root = pathlib.Path(tempfile.mkdtemp())
    (root / "TTT").mkdir(); (root / "secret").mkdir()
    (root / "TTT" / "paper_state.json").write_text("{}"); (root / "secret" / "gemini_api_key.txt").write_text("k")
    from app import config
    old = (config.ROOT, config.DATA_DIR, config.SECRET_DIR)
    try:
        config.ROOT, config.DATA_DIR, config.SECRET_DIR = root, root / "XXX", root / "XXX" / "secret"
        config.DATA_DIR.mkdir(); config.SECRET_DIR.mkdir()
        moved = config._migrate_legacy()
        assert (root / "XXX" / "paper_state.json").exists() and (root / "XXX" / "secret" / "gemini_api_key.txt").exists()
        assert not (root / "TTT").exists() and not (root / "secret").exists() and len(moved) == 2
    finally:
        config.ROOT, config.DATA_DIR, config.SECRET_DIR = old
        shutil.rmtree(root, ignore_errors=True)
    assert config.DATA_DIR.name in ("XXX",) or os.getenv("TITAN_DATA")


def test_new_api_routes():
    from app.web.app import app
    c = app.test_client()
    r = c.get("/api/readiness").get_json()
    assert r["paper"]["verdict"]["level"] in ("insufficient", "not_ready", "promising", "candidate") and "signals" in r
    assert "global" in c.get("/api/context").get_json()
    assert c.get("/api/context/NOTASYMBOL!!").status_code in (400, 404)


if __name__ == "__main__":
    fails = 0
    for k, v in list(globals().items()):
        if k.startswith("test_"):
            try:
                v(); print("PASS", k)
            except Exception as e:                      # noqa: BLE001
                fails += 1; print("FAIL", k, repr(e))
    sys.exit(fails)
