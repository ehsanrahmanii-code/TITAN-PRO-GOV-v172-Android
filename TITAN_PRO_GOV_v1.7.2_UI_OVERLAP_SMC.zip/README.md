# TITAN PRO Clean v1.7.1 — Governor + Learn-Lite

موتور تصمیم **Central Governor** از خانواده TITAN PRO روی معماری تمیز و سریع.
نسخه ۱.۷.۱ = سخت‌سازی V84 + حلقه یادگیری سبک فایل‌محور + صداقت امتیاز pro_core.

## چه چیزی واقعی است؟

| لایه | منبع |
|------|------|
| Central Governor (لبه، حاشیه، اعتماد، وتو، پشتیبانی، تضاد، R:R) | منطق PRO V84 + سخت‌سازی V84.3 |
| یادگیری سبک وزن‌ها | siglog outcomes → reliability tilt (بدون SQLite) |
| وزن‌های HTF/MTF/Structure/Pattern/DataTrust | PRO calibrated + adaptive |
| آستانه‌های نامتقارن SHORT | V84 edge_lab |
| UI مدرن + صرافی کاغذی + اسکنر | معماری تمیز (سریع) |
| شاخص‌ها، Grade، x10/x11/x12 | یکپارچه با Governor |

## تصمیم‌گیری

فقط **Governor** اجازه انتشار LONG/SHORT می‌دهد:

1. شواهد چندتایم‌فریم (HTF قوی‌تر)
2. مومنتوم و ساختار + volume_flow / pattern / x_layer
3. derivatives + context
4. حداقل لبه / حاشیه / اعتماد (SHORT سخت‌گیرانه‌تر)
5. حداقل ۲ خانواده شواهد مستقل هم‌جهت + تضاد < ۶۲٪
6. R:R قابل قبول (≥ ۱.۰۸)
7. وتوی درجه پایین، نقدینگی، کیفیت x10، تعارض timing

## یادگیری سبک

پس از هر اسکن، نتایج واقعی سیگنال‌های قبلی (SL/TP1 یا بازده ۴س) خوانده می‌شود و ضریب اطمینان هر خانواده شواهد به‌آرامی تنظیم می‌گردد.
وضعیت: `GET /api/learn` — فایل: `XXX/governor_learn.json`

## اجرا

```bash
pip install -r requirements.txt
python run.py
```

داده فقط در `XXX/` — کلید Gemini: `XXX/secret/gemini_api_key.txt`

## هشدار

سیگنال احتمالاتی است. قبل از پول واقعی حتماً فوروارد‌تست کاغذی بگیرید.
