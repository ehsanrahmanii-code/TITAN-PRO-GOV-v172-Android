#!/usr/bin/env python3
"""A/B walk-forward backtest: signal engine WITHOUT vs WITH the x11 layer, on REAL candles of your watchlist (needs internet).

    python tools/ab_backtest.py                 # default 1h, 12 coins
    python tools/ab_backtest.py --tf 4h --coins BTCUSDT,ETHUSDT,SOLUSDT
Each variant runs in its own process (TITAN_ADV=0/1). It reports per-variant pooled R statistics and the per-coin paired difference.
With ~15 trades per coin the noise is large: only believe a difference whose t-stat is clearly > 2 on many coins.
`--synthetic` replaces the network with random walks (self-test of the tool; no edge exists there by construction).
"""
import argparse
import json
import os
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def worker(tf: str, coins: list[str], synthetic: bool) -> None:
    import numpy as np
    import pandas as pd
    from app.analysis import backtest as bt
    from app.data import market
    out = {}
    for c in coins:
        if synthetic:
            r = np.random.default_rng(abs(hash(c)) % 10_000 + 1)
            n = 500
            px = 100 * np.exp(np.cumsum(r.normal(0, .012, n)))
            o = np.r_[px[0], px[:-1]]
            df = pd.DataFrame({"open_time": pd.date_range("2026-01-01", periods=n, freq="1h"), "open": o, "high": np.maximum(o, px) * 1.003,
                               "low": np.minimum(o, px) * .997, "close": px, "volume": r.uniform(100, 200, n)})
        else:
            try:
                df = market.closed_only(market.fetch_klines(c, tf, 500), tf)
            except Exception as e:                             # noqa: BLE001
                out[c] = {"error": str(e)[:80]}
                continue
        res = bt.run(df, c, tf)
        out[c] = {k: res.get(k) for k in ("n", "avg_r", "win_rate", "pf", "t_stat")} if res.get("n") else {"n": 0}
    print("@@" + json.dumps(out))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tf", default="1h")
    ap.add_argument("--coins", default="BTCUSDT,ETHUSDT,SOLUSDT,BNBUSDT,XRPUSDT,ADAUSDT,DOGEUSDT,AVAXUSDT,LINKUSDT,NEARUSDT,SUIUSDT,AAVEUSDT")
    ap.add_argument("--synthetic", action="store_true")
    ap.add_argument("--worker", action="store_true")
    a = ap.parse_args()
    coins = [c.strip().upper() for c in a.coins.split(",") if c.strip()]
    if a.worker:
        return worker(a.tf, coins, a.synthetic)
    import numpy as np
    res = {}
    for flag in ("0", "1"):
        env = dict(os.environ, TITAN_ADV=flag, PYTHONHASHSEED="0")
        cmd = [sys.executable, __file__, "--worker", "--tf", a.tf, "--coins", ",".join(coins)] + (["--synthetic"] if a.synthetic else [])
        p = subprocess.run(cmd, capture_output=True, text=True, env=env, timeout=3600)
        line = next((x for x in p.stdout.splitlines() if x.startswith("@@")), None)
        if not line:
            sys.exit(f"worker failed: {p.stderr[-400:]}")
        res[flag] = json.loads(line[2:])
    print(f"{'coin':<10}{'base n':>7}{'base avgR':>10}{'x11 n':>7}{'x11 avgR':>10}{'diff':>8}")
    diffs, pool = [], {"0": [], "1": []}
    for c in coins:
        b, x = res["0"].get(c, {}), res["1"].get(c, {})
        if not b.get("n") or not x.get("n"):
            print(f"{c:<10}{'—':>7}")
            continue
        d = x["avg_r"] - b["avg_r"]
        diffs.append(d)
        pool["0"].append(b["avg_r"]); pool["1"].append(x["avg_r"])
        print(f"{c:<10}{b['n']:>7}{b['avg_r']:>+10.3f}{x['n']:>7}{x['avg_r']:>+10.3f}{d:>+8.3f}")
    if len(diffs) >= 3:
        d = np.array(diffs)
        t = d.mean() / (d.std(ddof=1) / np.sqrt(len(d))) if d.std(ddof=1) > 0 else 0.0
        print(f"\nmean paired difference {d.mean():+.3f}R over {len(d)} coins, t={t:+.2f}  (|t|>2 needed before believing it)")
        print(f"mean avgR: baseline {np.mean(pool['0']):+.3f} | with x11 {np.mean(pool['1']):+.3f}")
    print("Backtests are in-sample-ish and cost-modelled only by fees+slippage: use as a sanity check, not proof of profit.")


if __name__ == "__main__":
    main()
