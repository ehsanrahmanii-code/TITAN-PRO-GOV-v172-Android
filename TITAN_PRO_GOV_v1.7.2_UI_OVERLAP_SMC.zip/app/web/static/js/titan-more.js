/* TITAN AI — More: appearance, chart, dashboard layout, scan, data backup, system */
(function () {
'use strict';
const { $, g, num, fmt, kv, empty, loading, noData, esc, ic, cur, ST, N, ago } = T;
const V = T.V, H = T.H;
const seg = (k, opts) => `<div class="seg" style="flex-wrap:wrap">${opts.map(([v, n]) => `<button data-pref-s="${k}|${v}" class="${String(T.P[k]) === String(v) ? 'on' : ''}">${n}</button>`).join('')}</div>`;
const sl = (k, l, a, b, st) => `<div class="f col"><label>${l} <b class="n" style="color:var(--acc)" id="pv-${k}">${T.P[k]}</b></label><input type="range" min="${a}" max="${b}" step="${st || 1}" value="${T.P[k]}" data-pref="${k}"></div>`;
const tg = (k, l) => `<div class="f"><label>${l}</label><button class="sw ${T.P[k] ? 'on' : ''}" data-pref-t="${k}" aria-label="${l}"></button></div>`;
const card = (t, inner) => `<div class="glass card"><h2>${t}</h2>${inner}</div>`;

V['more:look'] = { needs: [], live: false, paint(el) {
  const P = T.P;
  el.innerHTML = card('قالب‌های آماده', `<p class="note" style="margin-top:0">با یک لمس تم، رنگ، پس‌زمینه، سبک کارت، تراکم، فونت، عرض و چیدمان ویجت‌ها تنظیم می‌شود؛ بعد می‌توانید ریزتنظیم کنید.</p><div class="tgrid">${Object.entries(T.TEMPLATES).map(([k, v]) => { const th = T.THEMES[v.p.theme]; return `<div class="thm" data-tpl="${k}"><i style="background:linear-gradient(135deg,${th.bgTop},${th.card2} 55%,${(T.ACC[v.p.accent] || {}).acc || th.g1})"></i>${esc(v.n)}<small style="display:block;font-weight:400;opacity:.7">${esc(v.d)}</small></div>`; }).join('')}</div>`)
  + card('تم کامل', `<p class="note" style="margin-top:0">پس‌زمینه، کارت‌ها و متن را تغییر می‌دهد؛ رنگ نئونی جداگانه انتخاب می‌شود (${Object.keys(T.THEMES).length} تم × ${Object.keys(T.ACC).length} رنگ).</p><div class="tgrid">${Object.entries(T.THEMES).map(([k, v]) => `<div class="thm ${P.theme === k ? 'on' : ''}" data-theme="${k}"><i style="background:linear-gradient(135deg,${v.bgTop},${v.card2} 60%,${v.line2})"></i>${esc(v.n)}</div>`).join('')}</div>`)
  + card('رنگ اصلی (نئون)', `<div class="sw-c">${Object.entries(T.ACC).map(([k, v]) => `<button data-acc="${k}" class="${P.accent === k ? 'on' : ''}" style="background:linear-gradient(135deg,${v.acc},${v.pri1});color:${v.acc}" aria-label="${v.n}" title="${v.n}"></button>`).join('')}</div>`)
  + card('پس‌زمینه و کارت', `<div class="sh" style="margin-top:0">پس‌زمینه</div>${seg('bg', [['stars', 'ستاره‌ای'], ['grid', 'شبکه‌ای'], ['aurora', 'شفق'], ['grad', 'گرادیان'], ['mesh', 'مش رنگی'], ['dots', 'نقطه‌ای'], ['waves', 'موجی'], ['radial', 'کانونی'], ['scan', 'خط‌اسکن'], ['carbonfib', 'کربن'], ['plain', 'ساده']])}
  <div class="sh">سبک کارت‌ها</div>${seg('card', [['glass', 'شیشه‌ای'], ['neon', 'نئونی'], ['solid', 'توپر'], ['outline', 'خطی'], ['flat', 'تخت'], ['soft', 'نرم'], ['gradient', 'گرادیانی'], ['frost', 'مات']])}
  <div class="sh">حاشیهٔ نئونی</div>${seg('ring', [['normal', 'ضخیم'], ['thin', 'نازک'], ['none', 'بدون']])}
  ${sl('glow', 'شدت نئون', 0, 100)}${sl('blur', 'میزان بلور', 0, 30)}${sl('radius', 'گردی گوشه‌ها', 4, 34)}${sl('glassop', 'شفافیت کارت‌ها', 30, 100)}`)
  + card('تصویر پس‌زمینه سفارشی', `<p class="note" style="margin-top:0">آدرس کامل تصویر (URL) را وارد کنید. روی تم فعلی قرار می‌گیرد.</p>
  <div class="f col"><label>آدرس تصویر پس‌زمینه</label><input type="url" id="bg-img-url" value="${esc(P.bgImg || '')}" placeholder="https://.../image.jpg" dir="ltr"></div>
  ${sl('bgImgO', 'تاریکی روی تصویر', 0, 100)}
  ${P.bgImg ? `<img class="img-prev" src="${esc(P.bgImg)}" alt="preview" onerror="this.style.display='none'">` : ''}
  <div class="acts"><button class="btn" data-act="bgimg-apply">اعمال تصویر</button><button class="btn o" data-act="bgimg-clear">پاک کردن</button></div>`)
  + card('تصویر نمای اصلی (Hero)', `<p class="note" style="margin-top:0">به‌جای گاو/کره می‌توانید تصویر دلخواه بگذارید.</p>
  <div class="f col"><label>آدرس تصویر Hero</label><input type="url" id="hero-img-url" value="${esc(P.heroImg || '')}" placeholder="https://.../hero.jpg" dir="ltr"></div>
  ${P.heroImg ? `<img class="img-prev" src="${esc(P.heroImg)}" alt="hero" onerror="this.style.display='none'">` : ''}
  <div class="acts"><button class="btn" data-act="heroimg-apply">اعمال</button><button class="btn o" data-act="heroimg-clear">پیش‌فرض</button></div>
  <div class="sh">چیدمان کادر قیمت و سیگنال</div>${seg('heroLayout', [['split', 'کنار هم'], ['stack', 'زیر هم'], ['signal', 'سیگنال بالا']])}
  ${tg('hero', 'نمایش تصاویر نمای اصلی')}${tg('showBull', 'تصویر گاو')}${tg('showGlobe', 'کره نئونی')}`)
  + card('رنگ پس‌زمینه کارت و پنجره', `<p class="note" style="margin-top:0">رنگ سفارشی کارت‌ها و شیت‌ها. خالی = تم پیش‌فرض.</p>
  <div class="color-row">
    <div class="f col"><label>پس‌زمینه کارت</label><input type="color" id="card-bg-c" value="${esc((P.cardBg && P.cardBg.startsWith('#')) ? P.cardBg : '#050b24')}"><input type="text" id="card-bg-t" value="${esc(P.cardBg || '')}" placeholder="#050b24 یا rgba(...)" dir="ltr" style="margin-top:4px;font-size:.72rem"></div>
    <div class="f col"><label>پس‌زمینه پنجره (Sheet)</label><input type="color" id="sheet-bg-c" value="${esc((P.sheetBg && P.sheetBg.startsWith('#')) ? P.sheetBg : '#08133a')}"><input type="text" id="sheet-bg-t" value="${esc(P.sheetBg || '')}" placeholder="#08133a یا rgba(...)" dir="ltr" style="margin-top:4px;font-size:.72rem"></div>
  </div>
  <div class="acts"><button class="btn" data-act="surf-apply">اعمال رنگ‌ها</button><button class="btn o" data-act="surf-clear">بازنشانی رنگ</button></div>`)
  + card('متن و چیدمان', `<div class="sh" style="margin-top:0">فونت</div>${seg('font', Object.entries(T.FONTS).map(([k, v]) => [k, v[0]]))}
  ${sl('fs', 'اندازهٔ متن پایه', 11, 22)}${sl('fw', 'ضخامت متن', 300, 700, 100)}${sl('pxfs', 'اندازه قیمت (٪)', 110, 240, 5)}
  ${sl('brandSize', 'اندازه عنوان برند', 18, 40)}${sl('pad', 'پدینگ کارت', 4, 28)}${sl('gap', 'فاصله کارت‌ها', 2, 24)}${sl('secgap', 'فاصله بخش‌ها', 0, 28)}
  <div class="sh">تراکم</div>${seg('density', [['ultra', 'فوق‌فشرده'], ['compact', 'فشرده'], ['normal', 'عادی'], ['cozy', 'راحت']])}
  <div class="sh">عرض صفحه</div>${seg('maxw', [[560, 'موبایل'], [760, 'تبلت'], [1040, 'دسکتاپ']])}
  <div class="sh">ستون‌های داشبورد</div>${seg('cols', [[1, 'یک ستون'], [2, 'دو ستون']])}
  <div class="sh">نوار پایین</div>${seg('tabs', [['labels', 'متن + آیکون'], ['icons', 'فقط آیکون']])}`)
  + card('رنگ کندل‌ها', `${seg('candle', Object.entries(T.CND).map(([k, v]) => [k, v[2]]))}${P.candle === 'custom' ? `<div class="fgrid" style="margin-top:8px"><div class="f col"><label>کندل صعودی</label><input type="color" value="${esc(P.cup)}" data-pref-c="cup"></div><div class="f col"><label>کندل نزولی</label><input type="color" value="${esc(P.cdn)}" data-pref-c="cdn"></div></div>` : ''}`)
  + card('نمایش و رفتار', `${tg('brand', 'زیرنویس برند')}${tg('banner', 'تصاویر بنر')}${tg('anim', 'انیمیشن‌ها')}${tg('sound', 'صدای هشدار')}${tg('tbl', 'جزئیات بیشتر در جدول‌ها')}${tg('headerCompact', 'هدر فشرده')}`)
  + card('CSS سفارشی', `<p class="note" style="margin-top:0">هر استایل دلخواه را بنویسید. مستقیماً روی رابط اعمال می‌شود. (پیشرفته)</p>
  <textarea id="custom-css-box" dir="ltr">${esc(P.customCss || '')}</textarea>
  <div class="acts"><button class="btn" data-act="css-apply">اعمال CSS</button><button class="btn o" data-act="css-clear">پاک کردن</button></div>`)
  + card('بازنشانی ظاهر', `<div class="acts"><button class="btn o" data-act="reset-look">بازنشانی ظاهر</button></div>`);
} };

V['more:chart'] = { needs: [], live: false, paint(el) {
  const P = T.P;
  el.innerHTML = card('نوع نمودار', `${seg('ctype', [['candle', 'کندل'], ['hollow', 'توخالی'], ['heikin', 'هایکین‌آشی'], ['ohlc', 'میله‌ای'], ['line', 'خطی'], ['area', 'ناحیه‌ای']])}${sl('ch', 'ارتفاع نمودار (px)', 200, 640, 20)}`)
  + card('لایه‌ها', `${tg('ema', 'میانگین‌های EMA')}${tg('vol', 'حجم')}${tg('grid', 'شبکه')}${tg('lastp', 'خط قیمت لحظه‌ای')}${tg('tag', 'برچسب خطوط')}${tg('lvl', 'خطوط ورود / حد ضرر / اهداف / حد متحرک')}${tg('ez', 'ناحیهٔ ورود بهتر')}${tg('zones', 'سطوح حمایت و مقاومت')}${tg('vwap', 'VWAP و باندهای σ')}${tg('bb', 'باند بولینگر')}${tg('lr', 'کانال رگرسیون خطی')}`)
  + card('پیش‌بینی', `${tg('fut', 'کندل‌های آینده')}${tg('band', 'باندهای احتمال')}${sl('fcN', 'تعداد کندل آینده', 6, 32)}`)
  + card('تایم‌فریم پیش‌فرض', `<div class="seg">${T.CTF.map(([k, n]) => `<button data-pref-s="tf|${k}" class="${P.tf === k ? 'on' : ''}">${n}</button>`).join('')}</div>`);
} };

V['more:dash'] = { needs: [], live: false, paint(el) {
  const P = T.P, nm = Object.fromEntries(T.WREG.map(w => [w[0], w[1]]));
  el.innerHTML = card('چیدمان‌های آماده', `<div class="seg" style="flex-wrap:wrap">${Object.entries(T.WPRESET).map(([k, v]) => `<button data-wpre="${k}">${v.n}</button>`).join('')}</div><p class="note">یک چیدمان آماده را انتخاب کنید و سپس ریزتنظیم کنید.</p>`)
  + card('ویجت‌های داشبورد', `<p class="note" style="margin-top:0">ترتیب، نمایش و اندازه (تمام‌عرض / نیم‌عرض در حالت دو ستونه) هر ویجت را تعیین کنید.</p>${P.widgets.map((w, i) => `<div class="wcfg"><span class="g">${esc(nm[w])} <small class="wcat">${esc(T.WCAT[w] || '')}</small></span><button class="btn s o" data-wsz="${w}" aria-label="اندازه">${T.wsize(w) === 'half' ? '½' : '▬'}</button><button class="btn s o" data-wmv="${w}|-1" ${i === 0 ? 'disabled' : ''} aria-label="بالا">▲</button><button class="btn s o" data-wmv="${w}|1" ${i === P.widgets.length - 1 ? 'disabled' : ''} aria-label="پایین">▼</button><button class="sw ${P.hidden.includes(w) ? '' : 'on'}" data-whide="${w}" aria-label="نمایش"></button></div>`).join('')}`)
  + card('به‌روزرسانی', `${sl('refresh', 'فاصلهٔ تازه‌سازی داده (ثانیه)', 3, 60)}`);
} };

V['more:scan'] = { needs: ['settings', 'status'], live: false, paint(el) {
  const s = cur('settings'), st = cur('status'); if (!s || s.error) { el.innerHTML = `<div class="glass card">${noData(s) || loading}</div>`; return; }
  el.innerHTML = card('فهرست ارزها', `<div class="chips" style="margin:0 0 8px">${(s.watchlist || []).map(x => `<span class="chipx">${esc(x.replace('USDT', ''))}</span>`).join('')}</div><textarea id="wl" aria-label="فهرست ارزها">${esc((s.watchlist || []).map(x => x.replace('USDT', '')).join(', '))}</textarea><div class="acts"><button class="btn" data-act="wl-save">ذخیره و اسکن</button></div>`)
  + card('اسکن بازار', `<div class="f" style="margin-top:0"><label for="scan-sec">فاصلهٔ اسکن (ثانیه)</label><input id="scan-sec" type="number" min="30" max="900" value="${esc(s.scan_sec || 120)}"></div><div class="mu" style="font-size:.8rem;margin-top:8px">${st && st.last_scan ? 'آخرین اسکن ' + esc(ago(st.last_scan)) : 'هنوز اسکن نشده'}</div><div class="acts"><button class="btn o" data-act="sec-save">ذخیرهٔ فاصله</button><button class="btn y" data-act="scan">اسکن کامل اکنون</button></div>`);
} };

V['more:data'] = { needs: [], live: false, paint(el) {
  el.innerHTML = card('پشتیبان‌گیری از تنظیمات', `<p class="note" style="margin-top:0">همهٔ تنظیمات ظاهری، نمودار و چیدمان داشبورد در یک متن JSON ذخیره می‌شود.</p><textarea id="prefs-json" style="min-height:150px;direction:ltr;font-size:.72rem">${esc(JSON.stringify(T.P, null, 1))}</textarea><div class="acts"><button class="btn" data-act="prefs-import">وارد کردن</button><button class="btn o" data-act="prefs-copy">کپی</button></div>`)
  + card('بازنشانی', `<div class="acts"><button class="btn o" data-act="reset-look">ظاهر</button><button class="btn o" data-act="reset-dash">چیدمان داشبورد</button><button class="btn o" data-act="reset-chart">نمودار</button><button class="btn r" data-act="reset-all">همه چیز</button></div>`);
} };

V['more:sys'] = { needs: ['status', 'acct'], live: true, paint(el) {
  const st = cur('status'); if (!st || st.error) { el.innerHTML = `<div class="glass card">${noData(st) || loading}</div>`; return; }
  el.innerHTML = card('وضعیت سیستم', `<div class="kv">${kv('نسخه', N(esc(st.version)))}${kv('آخرین اسکن', st.last_scan ? esc(ago(st.last_scan)) : '—')}${kv('مدت اسکن', N(fmt(st.duration, 1) + 's'))}${kv('ارزها', N((st.symbols || []).length))}</div><div class="chips">${Object.entries(st.sources || {}).map(([k, v]) => `<span class="tag ${v && v.ok === false ? 'dn' : 'up'}">${esc(k)}</span>`).join('')}</div>${(st.errors || []).length ? `<div class="am" style="font-size:.8rem;margin-top:8px">${esc(st.errors.slice(-3).join(' · '))}</div>` : ''}`)
  + card('درباره', `<div class="row"><span>TITAN AI</span><span class="mu n">v${esc(st.version)}</span></div><p class="mu" style="font-size:.8rem;margin:6px 0 0">سیگنال‌ها صرفاً تحلیلی‌اند و توصیهٔ مالی نیستند. صرافی این برنامه کاغذی (شبیه‌سازی) است.</p>`);
} };

/* ── actions ── */
T.ACT = T.ACT || {}; T.DATA = T.DATA || {};
const repaint = () => { const v = V[T.ST.tab + ':' + T.ST.sub[T.ST.tab]]; if (v) v.paint($('#page')); };
T.DATA.theme = (el, d) => { T.setPref('theme', d.theme); T.redrawCharts(); repaint(); };
T.DATA.tpl = (el, d) => { if (T.applyTemplate(d.tpl)) { T.redrawCharts(); T.toast('قالب «' + T.TEMPLATES[d.tpl].n + '» اعمال شد'); repaint(); } };
T.DATA.wpre = (el, d) => { const p = T.WPRESET[d.wpre]; T.setPref('hidden', p.hidden.slice()); T.setPref('wsize', {}); T.toast('چیدمان «' + p.n + '» اعمال شد'); repaint(); };
T.DATA.wsz = (el, d) => { const w = d.wsz, ws = Object.assign({}, T.P.wsize); ws[w] = T.wsize(w) === 'half' ? 'full' : 'half'; T.setPref('wsize', ws); repaint(); };
T.DATA.prefC = (el, d) => { T.setPref(d.prefC, el.value); T.redrawCharts(); };
T.ACT['prefs-copy'] = () => { const t = $('#prefs-json'); try { t.select(); navigator.clipboard.writeText(t.value); T.toast('کپی شد'); } catch (e) { T.toast('کپی نشد؛ متن را دستی انتخاب کنید'); } };
T.ACT['prefs-import'] = () => { try { const o = JSON.parse($('#prefs-json').value); if (!o || typeof o !== 'object' || Array.isArray(o)) throw 0; Object.keys(o).forEach(k => { if (k in T.PD) T.P[k] = o[k]; }); T.applyPrefs(); T.savePrefs(); T.redrawCharts(); T.toast('تنظیمات وارد شد'); repaint(); } catch (e) { T.toast('JSON نامعتبر است'); } };
T.ACT['reset-look'] = () => { T.resetPrefs(['theme', 'accent', 'glow', 'blur', 'radius', 'fs', 'fw', 'font', 'density', 'card', 'ring', 'bg', 'maxw', 'cols', 'candle', 'cup', 'cdn', 'anim', 'brand', 'hero', 'banner', 'tabs', 'pxfs', 'secgap', 'heroLayout', 'glassop', 'bgImg', 'bgImgO', 'heroImg', 'cardBg', 'sheetBg', 'customCss', 'pad', 'gap', 'brandSize', 'showGlobe', 'showBull', 'headerCompact']); T.toast('ظاهر بازنشانی شد'); repaint(); };
T.ACT['reset-dash'] = () => { T.resetPrefs(['widgets', 'hidden', 'wsize', 'refresh']); T.toast('چیدمان بازنشانی شد'); repaint(); };
T.ACT['reset-chart'] = () => { T.resetPrefs(['ema', 'vol', 'fut', 'band', 'lvl', 'grid', 'fcN', 'ctype', 'ch', 'vwap', 'bb', 'zones', 'ez', 'lr', 'lastp', 'tag']); T.redrawCharts(); T.toast('نمودار بازنشانی شد'); repaint(); };
T.ACT['reset-all'] = () => { if (confirm('همهٔ تنظیمات به حالت کارخانه برگردد؟')) { T.resetPrefs(); T.redrawCharts(); T.toast('همه‌چیز بازنشانی شد'); repaint(); } };

T.ACT['bgimg-apply'] = () => { const v = ($('#bg-img-url') || {}).value || ''; T.setPref('bgImg', v.trim()); T.setPref('bg', v.trim() ? 'image' : (T.P.bg === 'image' ? 'stars' : T.P.bg)); T.toast(v.trim() ? 'تصویر پس‌زمینه اعمال شد' : 'آدرس خالی است'); const v2 = V['more:look']; if (v2) v2.paint($('#page')); };
T.ACT['bgimg-clear'] = () => { T.setPref('bgImg', ''); if (T.P.bg === 'image') T.setPref('bg', 'stars'); T.toast('تصویر پس‌زمینه پاک شد'); const v2 = V['more:look']; if (v2) v2.paint($('#page')); };
T.ACT['heroimg-apply'] = () => { const v = ($('#hero-img-url') || {}).value || ''; T.setPref('heroImg', v.trim()); T.toast(v.trim() ? 'تصویر Hero اعمال شد' : 'آدرس خالی است'); if (T.ST.tab === 'dash') T.paintWidgets(); const v2 = V['more:look']; if (v2) v2.paint($('#page')); };
T.ACT['heroimg-clear'] = () => { T.setPref('heroImg', ''); T.toast('Hero به پیش‌فرض برگشت'); if (T.ST.tab === 'dash') T.paintWidgets(); const v2 = V['more:look']; if (v2) v2.paint($('#page')); };
T.ACT['surf-apply'] = () => {
  const ct = (($('#card-bg-t') || {}).value || '').trim() || (($('#card-bg-c') || {}).value || '');
  const st = (($('#sheet-bg-t') || {}).value || '').trim() || (($('#sheet-bg-c') || {}).value || '');
  T.setPref('cardBg', ct); T.setPref('sheetBg', st); T.toast('رنگ سطوح اعمال شد');
};
T.ACT['surf-clear'] = () => { T.setPref('cardBg', ''); T.setPref('sheetBg', ''); T.toast('رنگ سطوح بازنشانی شد'); const v2 = V['more:look']; if (v2) v2.paint($('#page')); };
T.ACT['css-apply'] = () => { const v = ($('#custom-css-box') || {}).value || ''; T.setPref('customCss', v); T.toast('CSS سفارشی اعمال شد'); };
T.ACT['css-clear'] = () => { T.setPref('customCss', ''); const box = $('#custom-css-box'); if (box) box.value = ''; T.toast('CSS پاک شد'); };

})();