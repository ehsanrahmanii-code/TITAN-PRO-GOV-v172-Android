/* TITAN AI — boot: navigation, sheets, actions, refresh loop */
(function () {
'use strict';
const { $, $$, g, num, fmt, fp, sg, pc, usd, p100, N, FA, tag, ago, coin, kv, empty, loading, noData, esc, ic, cur, ST, R, syms, sideOf, SIG, atf, V, W, P } = Object.assign({}, T, { P: null });
const base = s => String(s).replace('USDT', '');
const TABS = [
  { id: 'dash', t: 'خانه', ic: 'home', subs: [] },
  { id: 'mkt', t: 'بازار', ic: 'mk', subs: [['watch', 'ارزها'], ['rank', 'رتبه'], ['heat', 'نقشه'], ['mood', 'حال بازار'], ['move', 'نوسان‌گرها'], ['corr', 'همبستگی']] },
  { id: 'ana', t: 'تحلیل', ic: 'an', subs: [['sig', 'سیگنال'], ['tf', 'تایم‌فریم'], ['fc', 'پیش‌بینی'], ['pat', 'الگوها'], ['lvl', 'سطوح'], ['bt', 'بک‌تست'], ['x10', 'شاخص x10'], ['x11', 'شاخص x11'], ['x12', 'شاخص x12'], ['ind', 'اسیلاتورها'], ['gov', 'حاکم مرکزی'], ['ev', 'شواهد']] },
  { id: 'lab', t: 'آزمایشگاه', ic: 'lab', subs: [['sum', 'نتیجه'], ['mx', 'ماتریس'], ['plan', 'برنامه ورود'], ['fc', 'پیش‌بینی'], ['deep', 'عمیق'], ['pro', 'هسته PRO']] },
  { id: 'ai', t: 'هوش', ic: 'ai', subs: [['opin', 'نظر AI'], ['pick', 'برترها'], ['al', 'هشدار'], ['trk', 'کارنامه'], ['ready', 'آمادگی']] },
  { id: 'ex', t: 'معامله', ic: 'ex', subs: [['pos', 'باز'], ['tik', 'سفارش'], ['auto', 'خودکار'], ['perf', 'عملکرد'], ['his', 'تاریخچه'], ['risk', 'ریسک'], ['pol', 'سیاست']] },
  { id: 'more', t: 'بیشتر', ic: 'more', subs: [['look', 'ظاهر'], ['chart', 'نمودار'], ['dash', 'چیدمان'], ['scan', 'اسکن'], ['data', 'پشتیبان'], ['sys', 'سیستم'], ['core', 'هسته مرکزی']] }
];
const BASE = ['matrix', 'status', 'coin', 'k', 'acct', 'mkt', 'alerts'];
const viewKey = () => ST.tab + ':' + ST.sub[ST.tab];
const needsNow = () => ST.tab === 'dash' ? T.dashNeeds() : (V[viewKey()] ? V[viewKey()].needs : []);
let pending = false;
function buildNav() {
  $('#tabbar').innerHTML = TABS.map(t => `<button data-go="${t.id}" class="${ST.tab === t.id ? 'on' : ''}" aria-label="${t.t}">${ic(t.ic)}${t.t}</button>`).join('');
  document.documentElement.style.setProperty('--tabs', TABS.length);
  const tb = TABS.find(t => t.id === ST.tab); $('#sub').innerHTML = tb.subs.map(([k, n]) => `<button class="pill-t ${ST.sub[ST.tab] === k ? 'on' : ''}" data-go="${ST.tab}:${k}">${n}</button>`).join('');
  const on = $('#sub .on'); if (on) on.scrollIntoView({ inline: 'center', block: 'nearest' });
}
function paintView() {
  const el = $('#page'), v = V[viewKey()]; if (!v) return;
  try { v.paint(el); } catch (e) { el.innerHTML = '<div class="glass card empty err">خطا در نمایش این بخش</div>'; console.error(viewKey(), e); }
  pending = !v.needs.every(n => cur(n));
}
function go(tab, sub) {
  const tb = TABS.find(t => t.id === tab); if (!tb) return; ST.tab = tab; if (sub && tb.subs.some(s => s[0] === sub)) ST.sub[tab] = sub; else if (!ST.sub[tab] && tb.subs.length) ST.sub[tab] = tb.subs[0][0];
  buildNav(); const el = $('#page'); el.innerHTML = ''; el.className = ''; ST.cx = -1;
  if (tab === 'dash') { T.dashShell(el); T.paintWidgets(); } else paintView();
  refresh(false); window.scrollTo(0, 0);
}
T.go = go;
T.onData = function (n) {
  if (n === 'matrix' || n === 'status') drawStatus();
  if (n === 'alerts') bell();
  if (n === 'matrix' && syms().length && !syms().includes(ST.sel)) { ST.sel = syms().includes('BTCUSDT') ? 'BTCUSDT' : syms()[0]; refresh(true); }
  if (ST.tab === 'dash') { T.paintWidgets(n); return; }
  const v = V[viewKey()]; if (!v || !v.needs.includes(n)) return;
  if (v.live || pending) paintView(); else if (n === 'k' || n === 'coin') T.redrawCharts();
};
function refresh(force) { BASE.concat(needsNow()).forEach(n => T.load(n, force)); }
function drawStatus() {
  const st = cur('status'), el = $('#status'); if (!st || st.error) { el.innerHTML = `<span class="dot bad"></span><span>${esc(st ? st.error : 'در حال اتصال…')}</span>`; return; }
  const sc = st.scanning, pr = st.progress || {};
  el.innerHTML = `<span class="dot ${sc ? '' : 'ok'}"></span><span>${sc ? `در حال اسکن ${pr.done || 0}/${pr.total || '—'}` : st.last_scan ? 'آخرین اسکن ' + ago(st.last_scan) : 'آماده'}</span><span class="sp"></span><button data-act="scan">${ic('scan').replace('<svg', '<svg width="13" height="13" style="display:inline;vertical-align:-2px;margin-inline-end:4px" fill="none" stroke="currentColor" stroke-width="2.2"')}اسکن</button>`;
}
let lastFired = null;
function beep() { try { const A = window.AudioContext || window.webkitAudioContext, c = new A(), o = c.createOscillator(), gn = c.createGain(); o.connect(gn); gn.connect(c.destination); o.frequency.value = 880; gn.gain.value = .06; o.start(); o.stop(c.currentTime + .18); } catch (e) { /* audio unavailable */ } }
function bell() { const d = cur('alerts'), n = (g(d, 'alerts', []) || []).filter(x => x.fired).length, b = $('#bell-n'); b.hidden = !n; b.textContent = n; if (lastFired !== null && n > lastFired && T.P.sound) beep(); lastFired = n; }
function select(s) { ST.sel = s; T.setPref('sel', s); ST.cx = -1; if (ST.tk) ST.tk = null; if (ST.tab === 'dash') T.paintWidgets(); else if (V[viewKey()]) { $('#page').innerHTML = ''; paintView(); } refresh(true); }
/* ── sheets ── */
function coinSheet(s) {
  const r = R(s); if (!r) return; const t = r.ticker || {}, sd = sideOf(r), u = (t.change_pct || 0) >= 0, tf = r.tfs || {};
  T.sheet(base(s) + '/USDT', `<div style="display:flex;align-items:center;gap:12px">${coin(base(s), 44)}<div style="flex:1"><div class="n" style="font-size:1.5rem;font-weight:800">${fp(t.price)}</div><div class="n ${u ? 'up' : 'dn'}">${pc(t.change_pct)}</div></div><span class="sd ${sd}" style="min-width:84px;margin:0">${sd}</span></div>
  <div style="direction:ltr;margin:10px 0">${T.spark(r.spark, 300, 60, r.fcc).replace(/width="300" height="60"/, 'style="width:100%;height:70px"')}</div>
  <div class="kv c3">${kv('اجماع', N(sg(r.cons, 0)), r.cons >= 0 ? 'up' : 'dn')}${kv('درجه', esc(r.grade || '—'))}${kv('هم‌جهتی', N(g(r, 'aligned', '—')))}</div>
  <div class="chips">${['15m', '1h', '4h', '1d'].filter(x => tf[x]).map(x => `<span class="tag ${tf[x].side}">${x} ${FA[tf[x].side] || ''}</span>`).join('')}</div>
  <div class="acts"><button class="btn" data-sel="${esc(s)}" data-go="ana:sig">تحلیل</button><button class="btn y" data-sel="${esc(s)}" data-go="lab:sum">تحلیل عمیق</button><button class="btn o" data-sel="${esc(s)}" data-go="ai:opin">نظر AI</button><button class="btn g" data-sel="${esc(s)}" data-go="ex:tik">سفارش</button></div>`);
}
function pickSheet(q) {
  const l = syms().filter(s => !q || s.toLowerCase().includes(q.toLowerCase()));
  T.sheet('انتخاب ارز', `<input id="pk-q" placeholder="جستجو…" value="${esc(q || '')}" autocomplete="off"><div id="pk-l" style="margin-top:8px">${l.map(s => `<div class="nav-i" data-sel="${esc(s)}">${coin(base(s), 28)}${esc(base(s))}<span class="mu n" style="margin-inline-start:auto">${fp(g(R(s), 'ticker.price'))}</span></div>`).join('') || empty('نتیجه‌ای نیست')}</div>`);
}
const drawer = () => T.sheet('ناوبری', TABS.map(t => `<div class="nav-i" data-go="${t.id}">${ic(t.ic).replace('<svg', '<svg width="22" height="22" fill="none" stroke="var(--acc)" stroke-width="2"')}${t.t}</div>${t.subs.map(([k, n]) => `<div class="nav-i" style="padding-inline-start:36px;font-weight:600;color:var(--mu)" data-go="${t.id}:${k}">${n}</div>`).join('')}`).join(''));
function bellSheet() { const al = (g(cur('alerts'), 'alerts', []) || []).filter(x => x.fired); T.sheet('اعلان‌ها', al.length ? al.map(x => `<div class="row"><span class="g"><b>${esc(base(x.symbol))}</b> ${x.type === 'price' ? (x.op === '>' ? 'بالاتر از ' : 'پایین‌تر از ') + N(fp(x.price)) : 'سیگنال درجه ' + esc(x.min_grade)}</span><span class="tag am">فعال شد</span></div>`).join('') + `<div class="acts"><button class="btn o" data-go="ai:al">مدیریت هشدارها</button></div>` : empty('اعلان جدیدی نیست')); }
function chartOpts() {
  const p = T.P, tg = (k, l) => `<div class="f"><label>${l}</label><button class="sw ${p[k] ? 'on' : ''}" data-pref-t="${k}" aria-label="${l}"></button></div>`;
  T.sheet('تنظیمات نمودار', `<div class="seg" style="flex-wrap:wrap">${[['candle', 'کندل'], ['hollow', 'توخالی'], ['heikin', 'هایکین'], ['ohlc', 'میله‌ای'], ['line', 'خط'], ['area', 'ناحیه']].map(([k, n]) => `<button data-pref-s="ctype|${k}" class="${p.ctype === k ? 'on' : ''}">${n}</button>`).join('')}</div>` + tg('ema', 'EMA') + tg('vol', 'حجم') + tg('fut', 'کندل‌های آینده') + tg('band', 'باند احتمال') + tg('lvl', 'خطوط ورود/SL/TP') + tg('ez', 'ناحیهٔ ورود') + tg('zones', 'حمایت/مقاومت') + tg('vwap', 'VWAP±σ') + tg('bb', 'بولینگر') + tg('lr', 'کانال رگرسیون') + tg('lastp', 'خط قیمت') + tg('grid', 'شبکه') + `<div class="f col"><label>تعداد کندل آینده <b class="n" style="color:var(--acc)" id="pv-fcN">${p.fcN}</b></label><input type="range" min="6" max="32" value="${p.fcN}" data-pref="fcN"></div>`);
}
function fullChart() {
  let f = $('#full'); if (f) { f.remove(); document.body.style.overflow = ''; return; }
  f = document.createElement('div'); f.id = 'full'; f.className = 'on'; f.innerHTML = `<div class="tfs">${T.CTF.map(([k, n]) => `<button data-tf="${k}" class="${ST.tf === k ? 'on' : ''}">${n}</button>`).join('')}<button class="ic" data-act="chart-opts" aria-label="تنظیمات">${ic('ind')}</button><button class="ic" data-act="full" aria-label="بستن">✕</button></div><div class="cwrap"><canvas id="cv-full"></canvas></div>`;
  document.body.appendChild(f); document.body.style.overflow = 'hidden'; T.chartInit('cv-full'); setTimeout(T.redrawCharts, 30);
}
/* ── tf / prefs helpers ── */
function setTf(t) { ST.tf = t; T.setPref('tf', t); ST.cx = -1; $$('[data-tf]').forEach(b => b.classList.toggle('on', b.dataset.tf === t)); T.redrawCharts(); refresh(false); if (ST.tab !== 'dash' && V[viewKey()] && V[viewKey()].live) paintView(); }
function viewRepaint() { if (ST.tab === 'dash') return T.paintWidgets(); const v = V[viewKey()]; if (v) v.paint($('#page')); }
const prefRepaint = () => { T.redrawCharts(); if (ST.tab === 'dash') T.paintWidgets(); };
const num0 = v => { const x = parseFloat(v); return isFinite(x) ? x : 0; };
/* ── clicks ── */
document.addEventListener('click', async e => {
  const t = e.target.closest('[data-go],[data-sel],[data-sheet],[data-hs],[data-tf],[data-act],[data-tk-side],[data-tk-mode],[data-acc],[data-pref-s],[data-pref-t],[data-wmv],[data-whide],[data-ov-b],[data-theme],[data-wpre],[data-tpl],[data-wsz],[data-hf],[data-pos],[data-trade],[data-cell],[data-info],[data-rk]'); if (!t) return; const d = t.dataset;
  if (d.cell) { const [id, tf] = d.cell.split('|'); return T.cellSheet(id, tf); }
  if (d.info) return T.infoSheet(d.info);
  for (const k of ['theme', 'wpre', 'tpl', 'wsz', 'hf', 'pos', 'trade', 'rk']) if (d[k] !== undefined && T.DATA[k]) { const f = k === 'rk' ? T.ACT.rk : T.DATA[k]; return f(t, d); }
  if (d.tf) return setTf(d.tf);
  if (d.sheet) return coinSheet(d.sheet);
  if (d.hs) { const [s, tf] = d.hs.split('|'); ST.sel = s; T.setPref('sel', s); if (T.ATF.includes(tf)) { ST.tf = tf; T.setPref('tf', tf); } return go('ana', 'sig'); }
  if (d.sel || d.go) { const was = $('#sheet-root .sheet'); if (was) T.closeSheet(); if (d.sel && d.sel !== ST.sel) { if (d.go) { ST.sel = d.sel; T.setPref('sel', d.sel); ST.tk = null; } else select(d.sel); } if (d.go) { const [tb, sb] = d.go.split(':'); return go(tb, sb); } return; }
  if (d.tkSide) { T.tkInit(); ST.tk.side = d.tkSide; return V['ex:tik'].paint($('#page')); }
  if (d.tkMode) { T.tkInit(); ST.tk.mode = d.tkMode; return V['ex:tik'].paint($('#page')); }
  if (d.acc) { T.setPref('accent', d.acc); T.redrawCharts(); return V['more:look'].paint($('#page')); }
  if (d.prefS) { const [k, v] = d.prefS.split('|'); T.setPref(k, v); if (k === 'tf') { setTf(v); } else prefRepaint(); return V[viewKey()].paint($('#page')); }
  if (d.prefT) { T.setPref(d.prefT, T.P[d.prefT] ? 0 : 1); t.classList.toggle('on', !!T.P[d.prefT]); return prefRepaint(); }
  if (d.wmv) { const [w, dir] = d.wmv.split('|'), a = T.P.widgets, i = a.indexOf(w), j = i + +dir; if (j < 0 || j >= a.length) return; [a[i], a[j]] = [a[j], a[i]]; T.setPref('widgets', a); return V['more:dash'].paint($('#page')); }
  if (d.whide) { const h = T.P.hidden, i = h.indexOf(d.whide); if (i >= 0) h.splice(i, 1); else h.push(d.whide); T.setPref('hidden', h); return V['more:dash'].paint($('#page')); }
  if (d.ovB !== undefined) return t.classList.toggle('on');
  const a = d.act;
  if (a && T.ACT[a]) return T.ACT[a](t, d);
  if (a === 'sheet-x') return T.closeSheet();
  if (a === 'drawer') return drawer(); if (a === 'bell') return bellSheet(); if (a === 'pick') return pickSheet(''); if (a === 'chart-opts') return chartOpts(); if (a === 'full') return fullChart();
  if (a === 'to-ticket') { T.tkFill(); return go('ex', 'tik'); }
  if (a === 'tk-fill') { if (!T.tkFill()) return T.toast('سیگنال فعالی برای پر کردن نیست'); return V['ex:tik'].paint($('#page')); }
  if (a === 'tk-send') {
    T.tkInit(); const k = ST.tk, px = num0(k.price), b = { symbol: ST.sel, side: k.side, mode: k.mode, stop: num0(k.sl), tp1: num0(k.tp1), tp2: num0(k.tp2), tp3: num0(k.tp3), leverage: Math.max(1, Math.round(num0(k.lev) || 5)), risk_pct: num0(k.risk) || undefined };
    if (k.mode !== 'market') b.price = px; else b.price = px || g(R(ST.sel), 'ticker.price', 0);
    if (!(b.stop > 0 && b.tp1 > 0 && b.tp2 > 0)) return T.toast('حد ضرر، هدف ۱ و هدف ۲ را وارد کنید'); if (k.mode !== 'market' && !(px > 0)) return T.toast('قیمت ورود را وارد کنید');
    t.disabled = true; const r = await T.post('/api/order', b); t.disabled = false; T.toast(r.ok ? (k.mode === 'market' ? 'موقعیت باز شد ✓' : 'سفارش ثبت شد ✓') : (r.error || 'رد شد')); T.load('acct', true); T.load('perf', true); if (r.ok) go('ex', k.mode === 'market' ? 'pos' : 'ord'); return;
  }
  if (a === 'ord-x') { const r = await T.post('/api/order/cancel', { id: d.id }); T.toast(r.ok ? 'لغو شد' : (r.error || 'خطا')); return T.load('acct', true); }
  if (a === 'close') { const r = await T.post('/api/exchange/close', { id: d.id }); T.toast(r.ok ? 'موقعیت بسته شد' : (r.error || 'خطا')); T.load('perf', true); T.closeSheet(); return T.load('acct', true); }
  if (a === 'ai-re') { $('#page').innerHTML = `<div class="glass card">${loading}</div>`; return T.load('ai', true); }
  if (a === 'al-add') { const px = parseFloat($('#al-px').value); if (!(px > 0)) return T.toast('قیمت را وارد کنید'); const r = await T.post('/api/alerts', { type: 'price', symbol: ST.sel, op: $('#al-op').value, price: px }); T.toast(r.error || 'هشدار افزوده شد'); $('#al-px').value = ''; return T.load('alerts', true); }
  if (a === 'al-sig') { const r = await T.post('/api/alerts', { type: 'signal', symbol: ST.sel, min_grade: 'B' }); T.toast(r.error || 'هشدار سیگنال افزوده شد'); return T.load('alerts', true); }
  if (a === 'al-del') { await T.api('/api/alerts/' + d.id, { method: 'DELETE' }); return T.load('alerts', true); }
  if (a === 'wl-save') { const l = $('#wl').value.split(/[\s,;،]+/).filter(Boolean), r = await T.post('/api/settings', { watchlist: l }); if (r.error || r.ok === false) return T.toast('فهرست نامعتبر است'); T.toast('ذخیره شد؛ اسکن شروع شد'); await T.load('settings', true); await T.post('/api/scan?full=1'); return setTimeout(() => refresh(true), 1500); }
  if (a === 'sec-save') { const r = await T.post('/api/settings', { scan_sec: +$('#scan-sec').value }); return T.toast(r.error || r.ok === false ? 'مقدار نامعتبر' : 'ذخیره شد'); }
  if (a === 'scan') { const r = await T.post('/api/scan?full=1'); T.toast(r && r.error ? 'خطا در اسکن' : 'اسکن شروع شد'); return setTimeout(() => T.load('status', true), 800); }
  if (a === 'auto') { const ac = cur('acct'); t.disabled = true; const r = await T.post('/api/exchange/auto', { enabled: !(ac && ac.auto_trade) }); await T.load('acct', true); T.toast(r && r.error ? r.error : (r.auto_trade ? 'ترید خودکار روشن شد' : 'ترید خودکار خاموش شد')); return viewRepaint(); }
  if (a === 'mode-save') { const ov = {}; $$('[data-ov]').forEach(i => { ov[i.dataset.ov] = i.tagName === 'SELECT' ? i.value : num0(i.value); }); $$('[data-ov-b]').forEach(b => ov[b.dataset.ovB] = b.classList.contains('on')); const r = await T.post('/api/auto/config', { mode: $('#mode').value, overrides: ov }); T.toast(r.error || 'ذخیره شد'); return T.load('cfg', true); }
  if (a === 'resume') { await T.post('/api/auto/resume'); T.toast('ادامه یافت'); await T.load('acct', true); return viewRepaint(); }
  if (a === 'reset') { if (confirm('حساب کاغذی ریست شود؟')) { await T.post('/api/exchange/reset'); T.toast('حساب ریست شد'); return T.load('acct', true); } return; }
  if (a === 'prefs-reset') return T.ACT['reset-look']();
});
document.addEventListener('input', e => {
  const t = e.target, d = t.dataset;
  if (d.pref) { T.setPref(d.pref, +t.value); const o = $('#pv-' + d.pref); if (o) o.textContent = t.value; return prefRepaint(); }
  if (d.tk) { T.tkInit(); ST.tk[d.tk] = t.value; return T.tkPreview(); }
  if (t.id === 'pk-q') { const l = $('#pk-l'), q = t.value.toLowerCase(); l.innerHTML = syms().filter(s => s.toLowerCase().includes(q)).map(s => `<div class="nav-i" data-sel="${esc(s)}">${coin(base(s), 28)}${esc(base(s))}</div>`).join('') || empty('نتیجه‌ای نیست'); }
});
document.addEventListener('change', async e => { const t = e.target; if (t.dataset.act === 'mode-change') { await T.post('/api/auto/config', { mode: t.value, overrides: {} }); await T.load('cfg', true); V['ex:auto'].paint($('#page')); } });
addEventListener('resize', () => T.redrawCharts());
addEventListener('keydown', e => { if (e.key === 'Escape') { if ($('#sheet-root .sheet')) T.closeSheet(); else if ($('#full')) fullChart(); } });
/* ── boot ── */
(async function () {
  T.applyPrefs(); buildNav(); drawStatus(); go(ST.tab === 'dash' ? 'dash' : 'dash');
  const s = await T.api('/api/settings'); if (s && !s.error) {
    if (T.adoptServerPrefs(s.ui)) { ST.sel = T.P.sel; ST.tf = T.P.tf; go('dash'); }
    const ui = s.ui || {}; if (Object.keys(ui).some(k => k !== 'skin' && k !== 'prefs')) T.post('/api/settings', { ui: { skin: 'titan-ai', prefs: T.P } });      // purge leftover keys of removed UIs
  }
  refresh(true); (function loop() { setTimeout(() => { if (!document.hidden) refresh(false); loop(); }, Math.max(3, +T.P.refresh || 6) * 1000); })(); document.addEventListener('visibilitychange', () => { if (!document.hidden) refresh(false); });
})();
})();
