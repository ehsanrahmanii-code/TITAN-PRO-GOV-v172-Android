/* TITAN AI — Exchange (paper): control panel with auto ON/OFF, positions, orders, history, auto-trade, performance, risk */
(function () {
'use strict';
const { $, $$, g, num, fmt, fp, sg, pc, usd, p100, N, cls, FA, ago, coin, kv, bar, empty, loading, noData, esc, ic, cur, ST, R, syms, SIG } = T;
const V = T.V, H = T.H, base = s => String(s).replace('USDT', '');
const sdp = H.side;
const symHead = () => { const r = R(ST.sel), t = g(r, 'ticker', {}); return `<div class="glass card" style="margin-top:6px"><div class="row" style="padding:0;border:0"><span style="display:flex;align-items:center;gap:8px;font-weight:800;direction:ltr">${coin(base(ST.sel), 30)}${esc(base(ST.sel))}<span class="mu n" style="font-weight:600">/USDT</span></span><span class="n" style="font-weight:800">${fp(t.price)}</span><button class="btn s o" data-act="pick">تغییر ارز</button></div></div>`; };
const guard = (el, a) => { const e = noData(a); if (e) { el.innerHTML = `<div class="glass card">${e}</div>`; return true; } return false; };
const REASON = { tp1: 'هدف ۱', tp2: 'هدف ۲', tp3: 'هدف ۳', stop: 'حد ضرر', breakeven: 'سربه‌سر', trail: 'حد متحرک', manual: 'دستی', time: 'توقف زمانی', liquidation: 'لیکویید' };
const SRC = { auto: 'خودکار', manual: 'دستی' };
const hold = h => !num(h) ? '—' : h < 1 ? Math.round(h * 60) + ' دقیقه' : h < 48 ? fmt(h, 1) + ' ساعت' : fmt(h / 24, 1) + ' روز';
const winTxt = x => `${x.n} معامله · برد ${fmt(x.win, 0)}٪ · ${sg(x.avg_r, 2)}R`;

/* ── control panel shown above every exchange page ── */
const panel = (a, p) => {
  const c = cur('cfg'), cfg = g(c, 'cfg', {}), modes = g(c, 'modes', {}), m = modes[cfg.mode] || {}, ov = cfg.overrides || {}, grade = ov.min_grade || m.min_grade || '—', cons = ov.min_cons ?? m.min_cons;
  const wr = p && p.n ? p.win_rate : a.trades ? a.win_rate : null, pf = p && p.n ? p.pf : g(a, 'stats.profit_factor', null);
  return `<div class="glass card ${a.auto_trade ? 'gold' : ''}"><button class="bsw ${a.auto_trade ? 'on' : ''}" data-act="auto" aria-label="ترید خودکار"><span class="k"></span><span><b>ترید خودکار ${a.auto_trade ? 'روشن' : 'خاموش'}</b><small>${a.paused ? esc(a.pause_reason || 'متوقف شده') : a.auto_trade ? 'سیستم خودش وارد و خارج می‌شود' : 'فقط سفارش دستی'}</small></span></button>
  <div class="chips" style="margin-top:8px"><span class="chipx info" data-go="ex:auto">حالت: ${esc(m.name || cfg.mode || '—')}</span><span class="chipx am" data-go="ex:auto">سطح سیگنال: حداقل ${esc(grade)}</span>${num(cons) ? `<span class="chipx" data-go="ex:auto">اجماع: حداقل ${fmt(cons, 0)}</span>` : ''}${num(ov.min_quality ?? m.min_quality) ? `<span class="chipx" data-go="ex:auto">کیفیت: حداقل ${fmt(ov.min_quality ?? m.min_quality, 0)}</span>` : ''}</div>
  ${a.paused ? `<div class="am" style="font-size:.84rem;margin-top:8px">${esc(a.pause_reason || 'ترید خودکار متوقف شده')} <button class="btn s y" data-act="resume">ادامه</button></div>` : ''}
  <div class="kv c3" style="margin-top:10px">${kv('سرمایه', N(usd(a.equity)))}${kv('سود امروز', N(usd(a.day_pnl)), H.pcls(a.day_pnl))}${kv('نرخ برد', N(num(wr) ? fmt(wr, 1) + '٪' : '—'), wr >= 50 ? 'up' : 'am')}${kv('ضریب سود', N(num(pf) && pf ? fmt(pf, 2) : '—'), pf >= 1 ? 'up' : 'dn')}${kv('باز / معلق', N(`${(a.open_positions || []).length} / ${(a.orders || []).length}`))}${kv('افت', N(fmt(a.max_drawdown_pct, 2) + '٪'), 'dn')}</div></div>`;
};
const frame = (el, a, p, inner) => { el.innerHTML = panel(a, p) + inner; };

/* ── position card (full details) ── */
const ladder = x => {
  const pts = [x.stop, x.entry, x.price, x.tp1, x.tp2, x.tp3].filter(num), lo = Math.min(...pts), hi = Math.max(...pts), pos = v => hi === lo ? 50 : (v - lo) / (hi - lo) * 100;
  const ln = (v, c, l) => `<div class="ln ${c}" style="left:${pos(v)}%"><span>${l}</span></div>`;
  return `<div class="ladder"><div class="rail"></div>${ln(x.stop, 'sl', 'SL')}${ln(x.entry, 'en', 'E')}${ln(x.tp1, 'tp', '1')}${ln(x.tp2, 'tp', '2')}${num(x.tp3) ? ln(x.tp3, 'tp', '3') : ''}<div class="now" style="left:${pos(x.price)}%"></div></div>`;
};
const posCard = x => `<div class="pc ${x.side}"><div class="hd"><span class="nm" data-pos="${esc(x.id)}" style="cursor:pointer">${coin(base(x.symbol), 26)}${esc(base(x.symbol))} ${sdp(x.side)}<span class="mu n" style="font-size:.74rem">${x.leverage || ''}x</span></span><span class="g"></span><b class="n ${H.pcls(x.unrealized)}">${usd(x.unrealized)}</b></div>
  <div class="meta"><span class="chipx ${H.pcls(x.r_now)}">${sg(x.r_now, 2)}R الان</span><span class="chipx">درجه ${esc(x.grade || '—')}</span><span class="chipx">${esc(SRC[x.source] || x.source || 'دستی')}</span>${x.plan ? `<span class="chipx info">${esc(x.plan)}</span>` : ''}${x.regime ? `<span class="chipx">${esc(({ trend: 'روندی', range: 'رنج', neutral: 'گذار' })[x.regime] || x.regime)}</span>` : ''}${num(x.score) ? `<span class="chipx">امتیاز ${sg(x.score, 0)}</span>` : ''}<span class="chipx">مرحله ${x.stage || 0}</span><span class="chipx">${hold(x.held_h)}</span></div>
  ${ladder(x)}<div class="kv c3" style="margin-top:14px">${kv('ورود', N(fp(x.entry)))}${kv('قیمت', N(fp(x.price)))}${kv('٪ سود (با اهرم)', N(pc(x.pnl_pct)), H.pcls(x.pnl_pct))}${kv('SL', N(fp(x.stop)), 'dn')}${kv('TP1', N(fp(x.tp1)), 'up')}${kv('TP2', N(fp(x.tp2)), 'up')}${kv('تا SL', N(fmt(x.to_stop_pct, 2) + '٪'), 'dn')}${kv('تا TP1', N(fmt(x.to_tp1_pct, 2) + '٪'), 'up')}${kv('لیکویید', N(fp(x.liq)), 'am')}</div>
  <div class="acts"><button class="btn s r" data-act="close" data-id="${esc(x.id)}">بستن</button><button class="btn s o" data-pos="${esc(x.id)}">جزئیات</button><button class="btn s o" data-sel="${esc(x.symbol)}" data-go="lab:sum">تحلیل عمیق</button></div></div>`;

V['ex:pos'] = { needs: ['acct', 'perf', 'cfg', 'matrix'], live: true, paint(el) {
  const a = cur('acct'); if (guard(el, a)) return; const pos = a.open_positions || [], tot = pos.reduce((s, x) => s + (x.unrealized || 0), 0), risk = pos.reduce((s, x) => s + (x.risk_usd || 0), 0);
  frame(el, a, cur('perf'), `<div class="glass card"><h2>موقعیت‌های باز <small>${N(pos.length)}</small></h2>${pos.length ? `<div class="kv c3">${kv('سود شناور', N(usd(tot)), H.pcls(tot))}${kv('ریسک کل', N(usd(risk)), 'am')}${kv('نشست مارجین', N(usd(pos.reduce((s, x) => s + (x.margin_left || x.margin || 0), 0))))}</div>` : ''}${pos.map(posCard).join('') || empty('موقعیت بازی نیست — از برگهٔ سفارش، تحلیل یا ترید خودکار شروع کنید')}</div>`);
} };

T.posSheet = id => {
  const a = cur('acct'), x = (a && a.open_positions || []).find(p => p.id === id); if (!x) return;
  T.sheet(`${base(x.symbol)} · ${FA[x.side] || x.side}`, `${ladder(x)}<div class="kv c3" style="margin-top:14px">${kv('ورود', N(fp(x.entry)))}${kv('قیمت', N(fp(x.price)))}${kv('R الان', N(sg(x.r_now, 2)), H.pcls(x.r_now))}${kv('SL فعلی', N(fp(x.stop)), 'dn')}${kv('SL اولیه', N(fp(x.stop0)))}${kv('لیکویید', N(fp(x.liq)), 'am')}${kv('TP1', N(fp(x.tp1)), 'up')}${kv('TP2', N(fp(x.tp2)), 'up')}${kv('TP3', N(fp(x.tp3)), 'up')}${kv('حجم', N(fmt(x.qty, 4)))}${kv('باقی‌مانده', N(fmt(x.qty_left, 4)))}${kv('ارزش', N(usd(x.notional)))}${kv('مارجین', N(usd(x.margin_left || x.margin)))}${kv('ریسک', N(usd(x.risk_usd)), 'am')}${kv('اهرم', N(x.leverage + 'x'))}${kv('سود محقق', N(usd(x.realized)), H.pcls(x.realized))}${kv('MFE', N(usd(x.mfe)), 'up')}${kv('MAE', N(usd(x.mae)), 'dn')}${kv('درجه', esc(x.grade || '—'))}${kv('منبع', esc(SRC[x.source] || x.source || 'دستی'))}${kv('روش ورود', esc(x.plan || '—'))}${kv('مدت', hold(x.held_h))}${kv('مرحله', N(x.stage || 0))}</div>
  <div class="acts"><button class="btn r" data-act="close" data-id="${esc(x.id)}">بستن موقعیت</button><button class="btn o" data-sel="${esc(x.symbol)}" data-go="lab:sum">تحلیل عمیق</button></div>`);
};
T.tradeSheet = i => {
  const a = cur('acct'), x = (a && a.history || [])[i]; if (!x) return;
  T.sheet(`${base(x.symbol)} · ${FA[x.side] || x.side}`, `<div class="row" style="border:0">${sdp(x.side)}<span class="g"></span><b class="n ${H.pcls(x.pnl)}" style="font-size:1.2rem">${usd(x.pnl)}</b></div><div class="kv c3">${kv('نتیجه R', N(sg(x.r, 2) + 'R'), H.pcls(x.r))}${kv('دلیل خروج', esc(REASON[x.reason] || x.reason || x.exit || '—'))}${kv('درجه', esc(x.grade || '—'))}${kv('منبع', esc(SRC[x.source] || x.source || 'دستی'))}${kv('روش', esc(x.plan || '—'))}${kv('رژیم', esc(x.regime || '—'))}${kv('ورود', N(fp(x.entry)))}${kv('خروج', N(fp(x.exit_price || x.exit)))}${kv('اهرم', N((x.leverage || '—') + 'x'))}${kv('مدت', hold(x.closed_at && x.opened_at ? (x.closed_at - x.opened_at) / 3600 : null))}${kv('MFE', N(usd(x.mfe)), 'up')}${kv('MAE', N(usd(x.mae)), 'dn')}${kv('ریسک', N(usd(x.risk_usd)))}${kv('امتیاز', N(num(x.score) ? sg(x.score, 0) : '—'))}${kv('مارجین', N(usd(x.margin)))}</div>`);
};

/* ── order ticket ── */
T.tkInit = () => { if (!ST.tk) ST.tk = { side: 'LONG', mode: 'market', price: '', sl: '', tp1: '', tp2: '', tp3: '', lev: 5, risk: 1 }; };
T.tkFill = () => { const s = SIG(); T.tkInit(); if (!s || s.side === 'WAIT') return false; Object.assign(ST.tk, { side: s.side, price: String(s.entry ?? ''), sl: String(s.stop ?? ''), tp1: String(s.tp1 ?? ''), tp2: String(s.tp2 ?? ''), tp3: String(s.tp3 ?? '') }); return true; };
T.tkPreview = () => {
  const k = ST.tk, box = $('#tk-prev'); if (!box) return; const a = cur('acct'), px = +k.price || g(R(ST.sel), 'ticker.price', 0), sl = +k.sl, t1 = +k.tp1, d = k.side === 'LONG' ? 1 : -1;
  const ok = px > 0 && sl > 0 && t1 > 0 && (px - sl) * d > 0 && (t1 - px) * d > 0, rr = ok ? (t1 - px) * d / ((px - sl) * d) : null, rk = a && num(a.equity) ? a.equity * (+k.risk || 0) / 100 : null, dist = ok ? Math.abs(px - sl) / px : null, qty = ok && rk ? rk / Math.abs(px - sl) : null, lev = +k.lev || 1;
  box.innerHTML = `<div class="kv c3">${kv('R:R تا TP1', N(num(rr) ? fmt(rr, 2) : '—'), rr >= 1.5 ? 'up' : 'am')}${kv('ریسک (دلار)', N(usd(rk)))}${kv('فاصلهٔ SL', N(ok ? fmt(dist * 100, 2) + '٪' : '—'), 'dn')}${kv('حجم', N(num(qty) ? fmt(qty, 4) : '—'))}${kv('ارزش موقعیت', N(num(qty) ? usd(qty * px) : '—'))}${kv('مارجین', N(num(qty) ? usd(qty * px / lev) : '—'))}</div>${!ok && (k.sl || k.tp1) ? `<div class="am" style="font-size:.8rem;margin-top:6px">حد ضرر و هدف باید در دو سوی قیمت ورود باشند.</div>` : ''}`;
};
V['ex:tik'] = { needs: ['acct', 'perf', 'cfg'], live: false, paint(el) {
  T.tkInit(); const k = ST.tk, st = cur('status'), a = cur('acct'), maxl = g(st, 'max_leverage', 20), inp = (id, l, v, ph) => `<div class="f col"><label for="tk-${id}">${l}</label><input id="tk-${id}" data-tk="${id}" type="number" step="any" inputmode="decimal" value="${esc(v)}" placeholder="${esc(ph || '')}"></div>`;
  el.innerHTML = (a && !a.error ? panel(a, cur('perf')) : '') + symHead() + `<div class="glass card"><h2>برگهٔ سفارش <small>${esc(base(ST.sel))}</small></h2><div class="seg"><button data-tk-side="LONG" class="LONG ${k.side === 'LONG' ? 'on' : ''}">خرید LONG</button><button data-tk-side="SHORT" class="SHORT ${k.side === 'SHORT' ? 'on' : ''}">فروش SHORT</button></div>
  <div class="seg"><button data-tk-mode="market" class="${k.mode === 'market' ? 'on' : ''}">بازار</button><button data-tk-mode="limit" class="${k.mode === 'limit' ? 'on' : ''}">لیمیت</button><button data-tk-mode="stop" class="${k.mode === 'stop' ? 'on' : ''}">استاپ‌ورود</button></div>
  <div class="fgrid">${inp('price', 'قیمت ورود', k.price, 'بازار = لحظه‌ای')}${inp('sl', 'حد ضرر', k.sl)}${inp('tp1', 'هدف ۱', k.tp1)}${inp('tp2', 'هدف ۲', k.tp2)}${inp('tp3', 'هدف ۳ (اختیاری)', k.tp3)}${inp('lev', `اهرم (حداکثر ${maxl})`, k.lev)}${inp('risk', 'ریسک ٪ سرمایه', k.risk)}</div><div id="tk-prev" style="margin-top:10px"></div>
  <div class="acts"><button class="btn o" data-act="tk-fill">پر کردن از سیگنال</button><button class="btn y" data-act="tk-lab">پر کردن از تحلیل عمیق</button><button class="btn ${k.side === 'LONG' ? 'g' : 'r'}" data-act="tk-send">ثبت سفارش</button></div></div>`;
  T.tkPreview();
} };

V['ex:ord'] = { needs: ['acct', 'perf', 'cfg'], live: true, paint(el) {
  const a = cur('acct'); if (guard(el, a)) return; const o = a.orders || [];
  frame(el, a, cur('perf'), `<div class="glass card"><h2>سفارش‌های معلق <small>${N(o.length)}</small></h2>${o.map(x => `<div class="pc ${x.side}"><div class="hd"><span class="nm">${esc(base(x.symbol))} ${sdp(x.side)}</span><span class="g"></span><span class="chipx">${x.mode === 'limit' ? 'لیمیت' : 'استاپ'}</span></div><div class="meta">${x.grade ? `<span class="chipx">درجه ${esc(x.grade)}</span>` : ''}${x.source ? `<span class="chipx">${esc(SRC[x.source] || x.source)}</span>` : ''}${x.plan ? `<span class="chipx info">${esc(x.plan)}</span>` : ''}${x.expires ? `<span class="chipx am">انقضا ${esc(ago(2 * Date.now() / 1000 - x.expires)).replace(' پیش', '')}</span>` : ''}</div>
  <div class="kv c3" style="margin-top:8px">${kv('قیمت', N(fp(x.price)))}${kv('SL', N(fp(x.stop)), 'dn')}${kv('TP1', N(fp(x.tp1)), 'up')}${kv('TP2', N(fp(x.tp2)), 'up')}${kv('اهرم', N((x.leverage || '—') + 'x'))}${kv('ریسک', N(x.risk_pct ? fmt(x.risk_pct, 2) + '٪' : '—'))}</div><div class="acts"><button class="btn s r" data-act="ord-x" data-id="${esc(x.id)}">لغو</button></div></div>`).join('') || empty('سفارش معلقی نیست')}</div>`);
} };

/* ── history with filters ── */
ST.hf = ST.hf || 'all';
const HF = [['all', 'همه'], ['win', 'برنده'], ['loss', 'بازنده'], ['LONG', 'LONG'], ['SHORT', 'SHORT'], ['auto', 'خودکار'], ['manual', 'دستی']];
V['ex:his'] = { needs: ['acct', 'perf', 'cfg'], live: true, paint(el) {
  const a = cur('acct'); if (guard(el, a)) return; const all = (a.history || []).map((x, i) => Object.assign({ i }, x)).reverse(), f = ST.hf;
  const l = all.filter(x => f === 'all' ? true : f === 'win' ? x.pnl > 0 : f === 'loss' ? x.pnl <= 0 : f === 'auto' ? x.source === 'auto' : f === 'manual' ? x.source !== 'auto' : x.side === f), sum = l.reduce((s, x) => s + x.pnl, 0), w = l.filter(x => x.pnl > 0).length;
  frame(el, a, cur('perf'), `<div class="glass card"><h2>تاریخچهٔ معاملات <small>${N(l.length)} از ${N(all.length)}</small></h2><div class="filt">${HF.map(([k, n]) => `<button data-hf="${k}" class="${f === k ? 'on' : ''}">${n}</button>`).join('')}</div>
  ${l.length ? `<div class="kv c3" style="margin-top:8px">${kv('برد', N(fmt(w / l.length * 100, 0) + '٪'))}${kv('مجموع', N(usd(sum)), H.pcls(sum))}${kv('میانگین', N(usd(sum / l.length)), H.pcls(sum))}</div>` : ''}${l.map(x => `<div class="row" data-trade="${x.i}" style="cursor:pointer"><span class="g"><b>${esc(base(x.symbol))}</b> ${sdp(x.side)} ${x.grade ? `<span class="tag">${esc(x.grade)}</span>` : ''}<div class="mu" style="font-size:.72rem">${esc(REASON[x.reason] || x.reason || x.exit || '')} · ${esc(SRC[x.source] || 'دستی')}${x.plan ? ' · ' + esc(x.plan) : ''}</div></span><span class="n mu">${num(x.r) ? sg(x.r, 1) + 'R' : ''}</span><b class="n ${H.pcls(x.pnl)}">${usd(x.pnl)}</b></div>`).join('') || empty('معامله‌ای با این فیلتر نیست')}</div>`);
} };

/* ── auto-trade ── */
const LAB = { allow_market: 'ورود بازاری', max_ext_atr: 'حداکثر فاصله از ورود (ATR)', max_open: 'حداکثر موقعیت باز', max_same_dir: 'حداکثر هم‌جهت', max_total_risk: 'ریسک کل ٪', min_agree: 'حداقل هم‌جهتی', min_cons: 'حداقل اجماع', min_ev: 'حداقل EV', min_grade: 'حداقل درجه سیگنال', min_ptp1: 'حداقل P(TP1)', min_qv: 'حداقل حجم دلاری', min_rr: 'حداقل R:R', need_evidence: 'نیاز به شواهد بک‌تست', risk_pct: 'ریسک هر معامله ٪', time_stop_h: 'توقف زمانی (ساعت)', valid_h: 'اعتبار سفارش (ساعت)', min_quality: 'حداقل کیفیت بازار (x10)', min_timing: 'حداقل زمان‌بندی ورود (x10)' };
V['ex:auto'] = { needs: ['cfg', 'acct', 'perf'], live: false, paint(el) {
  const c = cur('cfg'), a = cur('acct'); if (!c || !a || c.error) { el.innerHTML = `<div class="glass card">${noData(c || a) || loading}</div>`; return; }
  const modes = c.modes || {}, mode = g(c, 'cfg.mode', ''), ov = g(c, 'cfg.overrides', {}), m = modes[mode] || {}, eff = Object.assign({}, m, ov);
  const fields = Object.keys(m).filter(k => k !== 'name' && k !== 'desc').map(k => { const v = eff[k], L = LAB[k] || k; return typeof m[k] === 'boolean' ? `<div class="f"><label>${L}</label><button class="sw ${v ? 'on' : ''}" data-ov-b="${k}" aria-label="${L}"></button></div>` : k === 'min_grade' ? `<div class="f"><label>${L}</label><select data-ov="${k}">${['A', 'B', 'C'].map(x => `<option ${x === v ? 'selected' : ''}>${x}</option>`).join('')}</select></div>` : `<div class="f"><label>${L}</label><input data-ov="${k}" type="number" step="any" value="${esc(v)}"></div>`; }).join('');
  const log = (a.auto_log || []).slice().reverse();
  frame(el, a, cur('perf'), `<div class="glass card"><h2>حالت و سطح سیگنال</h2><div class="seg" id="mode-seg">${Object.entries(modes).map(([k, v]) => `<button data-act="mode-pick" data-v="${esc(k)}" class="${k === mode ? 'on' : ''}">${esc(v.name)}</button>`).join('')}</div>${m.desc ? `<p class="note">${esc(m.desc)}</p>` : ''}
  <div class="sh">حداقل درجهٔ سیگنال برای ورود خودکار</div><div class="qrow" style="grid-template-columns:repeat(3,1fr)">${['A', 'B', 'C'].map(x => `<button data-act="grade-pick" data-v="${x}" class="${eff.min_grade === x ? 'on' : ''}">${x}${x === 'A' ? ' (سخت‌گیر)' : x === 'C' ? ' (فعال)' : ''}</button>`).join('')}</div>
  <p class="note">هرچه درجه بالاتر، سیگنال کمتر ولی با اطمینان بیشتر. دروازه‌های x10 (کیفیت و زمان‌بندی) هم قبل از ورود بررسی می‌شوند.</p>
  <select id="mode" data-act="mode-change" style="display:none">${Object.entries(modes).map(([k, v]) => `<option value="${esc(k)}" ${k === mode ? 'selected' : ''}>${esc(v.name)}</option>`).join('')}</select>
  <div class="sh">پارامترها (قابل شخصی‌سازی)</div><div id="ov-box">${fields}</div><div class="acts"><button class="btn" data-act="mode-save">ذخیرهٔ پارامترها</button><button class="btn r" data-act="reset">ریست حساب</button></div></div>
  <div class="glass card"><h2>گزارش تصمیم‌های خودکار <small>${N(log.length)}</small></h2>${log.map(x => `<div class="row"><span class="g" style="font-size:.8rem"><span class="${x.ok ? 'up' : 'am'}">${x.ok ? '✓' : '•'}</span> <b>${esc(base(x.symbol || ''))}</b> ${esc(x.text || x.reason || x.msg || '')}${x.checks ? `<div class="mu" style="font-size:.68rem">${esc(JSON.stringify(x.checks).slice(0, 140))}</div>` : ''}</span><span class="mu" style="font-size:.7rem">${ago(x.t)}</span></div>`).join('') || empty('هنوز تصمیمی ثبت نشده — پس از روشن‌کردن و اسکن بعدی پر می‌شود')}</div>`);
} };

/* ── full performance ── */
const grp = (t, o) => { const e = Object.entries(o || {}); return e.length ? `<div class="glass card"><h2>${t}</h2>${e.map(([k, v]) => `<div class="row"><span class="g"><b>${esc(({ LONG: 'LONG', SHORT: 'SHORT', auto: 'خودکار', manual: 'دستی' })[k] || REASON[k] || k)}</b><div class="mu" style="font-size:.7rem">${winTxt(v)}</div></span><span style="width:70px">${H.m100(v.win)}</span><b class="n ${H.pcls(v.pnl)}" style="width:64px;text-align:left">${usd(v.pnl)}</b></div>`).join('')}</div>` : ''; };
V['ex:perf'] = { needs: ['acct', 'perf', 'cfg'], live: true, paint(el) {
  const a = cur('acct'), p = cur('perf'); if (guard(el, a)) return; if (!p) { frame(el, a, null, `<div class="glass card">${loading}</div>`); return; }
  if (!p.n) { frame(el, a, p, `<div class="glass card"><h2>عملکرد</h2>${empty('هنوز معامله‌ای بسته نشده است. پس از اولین معامله، نرخ برد و آمار کامل اینجا نمایش داده می‌شود.')}</div>`); return; }
  const mx = Math.max(1, ...(p.r_hist.counts || [1])), dm = Math.max(1, ...(p.daily || []).map(d => Math.abs(d.pnl)));
  frame(el, a, p, `<div class="glass card"><h2>نرخ برد و عملکرد کلی <small>${N(p.n)} معامله</small></h2><div style="display:flex;align-items:center;gap:14px"><div class="gauge" style="width:104px;height:104px">${T.gauge(p.win_rate, p.win_rate >= 50 ? 'up' : 'am')}<div class="t"><b>${fmt(p.win_rate, 1)}٪</b><small>Win</small></div></div><div class="kv" style="flex:1">${kv('برد / باخت', N(`${p.wins} / ${p.losses}`))}${kv('ضریب سود', N(fmt(p.pf, 2)), p.pf >= 1 ? 'up' : 'dn')}${kv('امید ریاضی', N(usd(p.expectancy)), H.pcls(p.expectancy))}${kv('میانگین R', N(sg(p.avg_r, 2)), H.pcls(p.avg_r))}</div></div></div>
  <div class="glass card"><h2>منحنی سرمایه (معاملات بسته)</h2>${T.spark(p.equity, 300, 70).replace(/width="300" height="70"/, 'style="width:100%;height:90px"')}<div class="kv c3" style="margin-top:8px">${kv('بازده', N(pc(p.return_pct)), H.pcls(p.return_pct))}${kv('سود کل', N(usd(p.total_pnl)), H.pcls(p.total_pnl))}${kv('افت حداکثر', N(fmt(p.max_dd_pct, 2) + '٪'), 'dn')}</div></div>
  <div class="glass card"><h2>آمار کامل</h2><div class="kv c3">${kv('میانگین برد', N(usd(p.avg_win)), 'up')}${kv('میانگین باخت', N(usd(p.avg_loss)), 'dn')}${kv('Payoff', N(fmt(p.payoff, 2)))}${kv('بهترین', N(usd(p.best)), 'up')}${kv('بدترین', N(usd(p.worst)), 'dn')}${kv('جمع R', N(sg(p.total_r, 1)), H.pcls(p.total_r))}${kv('رشتهٔ برد', N(p.max_win_streak), 'up')}${kv('رشتهٔ باخت', N(p.max_loss_streak), 'dn')}${kv('مدت متوسط', hold(p.avg_hold_h))}${kv('Sharpe(R)', N(fmt(p.sharpe_r, 2)))}${kv('کارمزد', N(usd(p.fees)))}${kv('Kelly', N(fmt(p.kelly * 100, 0) + '٪'), p.kelly > 0 ? 'up' : 'dn')}</div></div>
  ${grp('بر اساس سمت', p.by_side)}${grp('بر اساس منبع (خودکار / دستی)', p.by_source)}${grp('بر اساس درجهٔ سیگنال', p.by_grade)}${grp('بر اساس رژیم بازار', p.by_regime)}${grp('بر اساس دلیل خروج', p.by_reason)}
  <div class="glass card"><h2>توزیع نتیجهٔ R</h2><div style="display:flex;align-items:flex-end;gap:3px;height:70px;direction:ltr">${p.r_hist.counts.map((c, i) => `<div style="flex:1;text-align:center"><i style="display:block;height:${c / mx * 56}px;border-radius:3px;background:${p.r_hist.edges[i] >= 0 ? 'var(--up)' : 'var(--dn)'};opacity:.8"></i><span class="n mu" style="font-size:.5rem">${fmt(p.r_hist.edges[i], 1)}</span></div>`).join('')}</div></div>
  ${(p.daily || []).length ? `<div class="glass card"><h2>سود روزانه</h2><div style="display:flex;align-items:center;gap:3px;height:80px;direction:ltr">${p.daily.map(d => `<i title="${usd(d.pnl)}" style="flex:1;height:${Math.max(3, Math.abs(d.pnl) / dm * 38)}px;align-self:${d.pnl >= 0 ? 'flex-end' : 'flex-start'};background:${d.pnl >= 0 ? 'var(--up)' : 'var(--dn)'};border-radius:2px;opacity:.85"></i>`).join('')}</div></div>` : ''}
  ${(p.by_symbol || []).length ? `<div class="glass card"><h2>بر اساس ارز</h2>${p.by_symbol.map(v => `<div class="row"><b style="width:52px">${esc(base(v.symbol))}</b><span class="g mu" style="font-size:.7rem">${winTxt(v)}</span><b class="n ${H.pcls(v.pnl)}" style="width:68px;text-align:left">${usd(v.pnl)}</b></div>`).join('')}</div>` : ''}`);
} };

/* ── risk ── */
V['ex:risk'] = { needs: ['acct', 'perf', 'cfg'], live: true, paint(el) {
  const a = cur('acct'); if (guard(el, a)) return; const pos = a.open_positions || [], L = a.limits || {}, eq = a.equity || 1, tr = pos.reduce((s, x) => s + (x.risk_usd || 0), 0), mg = pos.reduce((s, x) => s + (x.margin_left || x.margin || 0), 0), lg = pos.filter(x => x.side === 'LONG').reduce((s, x) => s + (x.notional || 0), 0), sh = pos.filter(x => x.side === 'SHORT').reduce((s, x) => s + (x.notional || 0), 0);
  frame(el, a, cur('perf'), `<div class="glass card"><h2>ریسک حساب</h2><div class="kv c3">${kv('ریسک باز', N(fmt(tr / eq * 100, 2) + '٪'), tr / eq * 100 > 4 ? 'dn' : 'am')}${kv('مارجین مصرفی', N(fmt(mg / eq * 100, 1) + '٪'))}${kv('باخت پیاپی', N(a.consec_losses || 0), a.consec_losses >= 3 ? 'dn' : '')}${kv('Long', N(usd(lg)), 'up')}${kv('Short', N(usd(sh)), 'dn')}${kv('خالص', N(usd(lg - sh)))}</div></div>
  <div class="glass card"><h2>محدودیت‌های سیستم</h2><div class="kv c3">${kv('ریسک هر معامله', N(fmt(L.risk_pct, 2) + '٪'))}${kv('حداکثر اهرم', N(L.max_leverage + 'x'))}${kv('حداکثر موقعیت', N(L.max_positions))}${kv('سقف ضرر روزانه', N(fmt(L.daily_loss_pct, 1) + '٪'), 'dn')}${kv('افت فعلی', N(fmt(a.max_drawdown_pct, 2) + '٪'), 'dn')}${kv('کارمزد کل', N(usd(a.total_fees)))}</div></div>
  <div class="glass card"><h2>مواجهه به تفکیک ارز</h2>${pos.map(x => `<div class="row" data-pos="${esc(x.id)}" style="cursor:pointer"><span class="g"><b>${esc(base(x.symbol))}</b> ${sdp(x.side)}</span><span class="n mu">${usd(x.notional)}</span><span style="width:70px">${H.m100(Math.min(100, (x.notional || 0) / eq * 50), (x.notional || 0) / eq < 1.5)}</span></div>`).join('') || empty('موقعیتی باز نیست')}</div>
  ${a.notice ? `<div class="glass card"><h2>اعلان</h2><p class="note am">${esc(typeof a.notice === 'string' ? a.notice : JSON.stringify(a.notice))}</p></div>` : ''}`);
} };

/* ── actions ── */
T.ACT = T.ACT || {};
T.ACT['mode-pick'] = async (el, d) => { await T.post('/api/auto/config', { mode: d.v, overrides: {} }); await T.load('cfg', true); V['ex:auto'].paint($('#page')); T.toast('حالت تغییر کرد'); };
T.ACT['grade-pick'] = async (el, d) => { const c = cur('cfg'), mode = g(c, 'cfg.mode', ''), ov = Object.assign({}, g(c, 'cfg.overrides', {}), { min_grade: d.v }); const r = await T.post('/api/auto/config', { mode, overrides: ov }); T.toast(r.error || 'سطح سیگنال ذخیره شد'); await T.load('cfg', true); V['ex:auto'].paint($('#page')); };
T.ACT['tk-lab'] = async () => { if (!cur('rep')) { T.toast('در حال تحلیل عمیق…'); await T.load('rep', true); } const r = cur('rep'); const p = r && r.plan; if (!p) { T.toast('تحلیل عمیق فعلاً سیگنال ورود نمی‌دهد'); return; } T.tkInit(); Object.assign(ST.tk, { side: p.side, price: String(p.entry), sl: String(p.stop), tp1: String(p.tp1), tp2: String(p.tp2), tp3: String(p.tp3) }); V['ex:tik'].paint($('#page')); };
T.DATA = T.DATA || {};
T.DATA.hf = (el, d) => { ST.hf = d.hf; V['ex:his'].paint($('#page')); };
T.DATA.pos = (el, d) => T.posSheet(d.pos);
T.DATA.trade = (el, d) => T.tradeSheet(+d.trade);
})();
