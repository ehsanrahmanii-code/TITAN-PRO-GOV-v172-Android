/* TITAN AI — pages: dashboard widgets, markets, analysis, AI center, exchange, more */
(function () {
'use strict';
const { $, $$, g, num, fmt, fp, sg, pc, usd, p100, N, cls, FA, tag, ago, coin, kv, bar, empty, loading, noData, esc, ic, cur, ST, R, syms, sideOf, SIG, atf, ATF } = T;
const V = T.V, W = {}; T.W = W;
const gradeW = { A: 3, B: 2, C: 1 };
const base = s => String(s).replace('USDT', '');
const sdp = s => `<span class="sd sm ${esc(s)}">${FA[s] || esc(s)}</span>`;
const rank = () => syms().map(s => ({ s, r: R(s) })).filter(x => x.r).map(x => Object.assign(x, { k: Math.abs(x.r.cons || 0) * (1 + (gradeW[x.r.grade] || 0) * .15) }));
const symHead = () => { const r = R(ST.sel), t = g(r, 'ticker', {}); return `<div class="glass card" style="margin-top:6px"><div class="row" style="padding:0;border:0"><span style="display:flex;align-items:center;gap:8px;font-weight:800;direction:ltr">${coin(base(ST.sel), 30)}${esc(base(ST.sel))}<span class="mu n" style="font-weight:600">/USDT</span></span><span class="n" style="font-weight:800">${fp(t.price)}</span><span class="n ${t.change_pct < 0 ? 'dn' : 'up'}">${pc(t.change_pct)}</span>${r ? sdp(sideOf(r)) : ''}<button class="btn s o" data-act="pick">تغییر</button></div></div>`; };

/* ═════════ DASHBOARD WIDGETS ═════════ */
W.hero = { needs: ['matrix', 'coin', 'k'], paint(el) {
  const r = R(ST.sel), s = SIG(), kl = g(cur('k'), 'klines', []), t = g(r, 'ticker', {}), b = base(ST.sel), P = T.P;
  let px = t.price; if (!num(px) && kl.length) px = kl[kl.length - 1].c; const ch = t.change_pct, abs = num(px) && num(ch) ? px - px / (1 + ch / 100) : null, u = (ch || 0) >= 0;
  const side = r ? sideOf(r) : g(s, 'side', 'WAIT'), cf = p100(g(s, 'confidence', null)), c = cls(side), gk = side === 'SHORT' ? 'dn' : side === 'WAIT' ? 'am' : 'up';
  const layout = P.heroLayout || 'split';
  const customHero = (P.heroImg || '').trim();
  const bgLayer = customHero
    ? `<div class="hero-bg"><img class="hero-custom-img" src="${esc(customHero)}" alt=""></div>`
    : `<div class="hero-bg"><div class="globe"></div><img class="bull" src="/static/img/bull.jpg" alt=""></div>`;
  el.innerHTML = `<div class="hero hero-layout-${esc(layout)}${customHero ? ' has-custom-img' : ''}">${bgLayer}
    <div class="hero-top">
      <div class="glass btc"><div class="sym">${coin(b, 26)}${esc(b)}<span class="mu" style="font-weight:600;font-size:.78rem">/USDT</span></div>
        <div class="px">${num(px) ? fp(px) : '<span class="spin"></span>'}</div>
        <div class="chg ${u ? 'up' : 'dn'}"><span>${pc(ch)} ${u ? '▲' : '▼'}</span><span class="mu">${num(abs) ? (abs >= 0 ? '+' : '-') + fp(Math.abs(abs)) : ''}</span></div>
      </div>
      <div class="glass sig" data-go="ana:sig" style="cursor:pointer">
        <div class="gauge">${T.gauge(num(cf) ? cf : (side === 'WAIT' ? 12 : 60), gk)}<div class="t"><b class="${c}">${side}</b><small>${side === 'LONG' ? '▲' : side === 'SHORT' ? '▼' : '◔'}</small></div></div>
        <div style="flex:1;min-width:0"><div class="lb">AI SIGNAL</div><div class="cf">Confidence</div><div class="cv">${num(cf) ? cf.toFixed(1) + '%' : '—'}</div>${bar(cf || 0, side === 'SHORT' ? 'dn' : side === 'WAIT' ? 'am' : '')}</div>
      </div>
    </div>
  </div>`;
} };
W.chart = { needs: ['k', 'coin'], paint(el) {
  if (!el.dataset.init) { el.dataset.init = 1; el.innerHTML = `<div class="glass card" style="padding:8px">${T.chartHTML('cv-dash')}</div>`; T.chartInit('cv-dash'); }
  $$('[data-tf]', el).forEach(b => b.classList.toggle('on', b.dataset.tf === ST.tf)); T.redrawCharts();
} };
W.stats = { needs: ['matrix', 'mkt', 'acct', 'ev'], paint(el) {
  const r = R(ST.sel), mk = cur('mkt'), a = cur('acct'), ev = g(cur('ev'), 'agg', null), mood = g(mk, 'mood', null), v = g(mk, 'avg_cons', null);
  const tr = num(mood) ? (mood >= 56 ? ['BULLISH', 'up'] : mood <= 44 ? ['BEARISH', 'dn'] : ['NEUTRAL', 'am']) : num(v) ? (v > 8 ? ['BULLISH', 'up'] : v < -8 ? ['BEARISH', 'dn'] : ['NEUTRAL', 'am']) : null;
  const sc = num(g(r, 'cons', null)) ? Math.min(100, Math.abs(r.cons)) : null, has = a && a.trades > 0, wr = has ? a.win_rate : g(ev, 'win', null), pf = has ? g(a, 'stats.profit_factor', null) : null;
  const log = (g(a, 'equity_log', []) || []).slice(-7).map(x => x.eq), mn = Math.min(...log), mx = Math.max(...log), bh = log.length > 2 && mx > mn ? log.map(x => 8 + (x - mn) / (mx - mn) * 34) : [10, 15, 20, 26, 31, 36];
  el.innerHTML = `<div class="stats"><div class="glass stat" data-go="mkt:mood"><h3>${ic('bars')}Market Trend</h3><div class="trend"><b class="${tr ? tr[1] : 'mu'}">${tr ? tr[0] : '…'}</b><img src="/static/img/bull-green.jpg" alt=""></div></div>
    <div class="glass stat sc gold" data-go="ai:opin"><h3>♛ AI Score</h3><div class="gauge">${T.gauge(sc || 0, 'score')}<div class="t"><b>${sc == null ? '—' : sc.toFixed(1)}</b><small class="n">/100</small></div></div></div>
    <div class="glass stat wr" data-go="ex:perf"><h3>${ic('cup')}Win Rate</h3><div class="big">${num(wr) ? wr.toFixed(1) + '%' : '—'}</div><div class="pf"><span>Profit Factor<b>${num(pf) && pf ? pf : '—'}</b></span><div class="mini">${bh.slice(-6).map(h => `<i style="height:${h}px"></i>`).join('')}</div></div></div></div>`;
} };
W.top = { needs: ['matrix'], paint(el) {
  const l = rank().filter(x => sideOf(x.r) !== 'WAIT').sort((a, b) => b.k - a.k).slice(0, 8);
  el.innerHTML = `<div class="card glass"><h2>برترین سیگنال‌ها <small>${N(l.length)} مورد</small></h2><div class="hs">${l.length ? l.map(x => `<div class="glass cc" style="min-width:130px;--r:16px" data-sheet="${esc(x.s)}"><div class="h">${coin(base(x.s), 26)}${esc(base(x.s))}</div><div class="c ${x.r.cons >= 0 ? 'up' : 'dn'}" style="margin:4px 0">${sg(x.r.cons, 0)} · ${esc(x.r.grade || '')}</div><div style="direction:ltr">${T.spark(x.r.spark, 100, 34, x.r.fcc)}</div><span class="sd ${sideOf(x.r)}">${sideOf(x.r)}</span></div>`).join('') : empty('هنوز سیگنال قوی‌ای نیست')}</div></div>`;
} };
W.coins = { needs: ['matrix', 'status'], paint(el) {
  const o = syms().filter(s => s !== ST.sel).slice(0, 12);
  el.innerHTML = `<div class="coins">${o.length ? o.map(s => { const r = R(s), t = g(r, 'ticker', {}), sd = sideOf(r), u = (t.change_pct || 0) >= 0; return `<div class="glass cc" data-sel="${esc(s)}"><div class="h">${coin(base(s), 28)}${esc(base(s))}</div><div class="p">${num(t.price) ? fp(t.price) : '—'}</div><div class="c ${u ? 'up' : 'dn'}">${pc(t.change_pct)} ${u ? '▲' : '▼'}</div><span class="sd ${sd}">${sd === 'WAIT' ? ic('clock').replace('<svg', '<svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2"') : ''}${sd}</span></div>`; }).join('') : `<div class="glass card empty" style="grid-column:1/-1"><span class="spin"></span>در حال اسکن بازار…</div>`}</div>`;
} };
W.mood = { needs: ['mkt'], paint(el) {
  const m = cur('mkt'); if (!m || m.error) { el.innerHTML = `<div class="glass card" data-go="mkt:mood">${noData(m) || ''}</div>`; return; }
  const pt = m.per_tf || {}, mood = m.mood;
  el.innerHTML = `<div class="glass card" data-go="mkt:mood" style="cursor:pointer"><h2>حال بازار <small>${N(m.n)} ارز</small></h2><div style="display:flex;align-items:center;gap:14px"><div class="gauge">${T.gauge(mood, mood >= 55 ? 'up' : mood <= 45 ? 'dn' : 'am')}<div class="t"><b>${num(mood) ? mood : '—'}</b><small>Mood</small></div></div><div style="flex:1">${ATF.filter(t => pt[t]).map(t => `<div class="row" style="padding:4px 0"><b style="width:30px">${t}</b><span class="up n">${pt[t].long}</span>${bar(pt[t].long / Math.max(1, pt[t].long + pt[t].short) * 100, 'up')}<span class="dn n">${pt[t].short}</span></div>`).join('')}</div></div></div>`;
} };
W.banner = { needs: [], paint(el) { if (el.dataset.init) return; el.dataset.init = 1; el.innerHTML = `<div class="glass gold banner"><img class="m" src="/static/img/map.jpg" alt=""><img class="pt" src="/static/img/portal.jpg" alt=""><div><h2>TITAN AI</h2><p>Trade Smarter…<br>Win Bigger…</p></div></div>`; } };
T.paintWidgets = n => $$('[data-w]').forEach(e => { const w = W[e.dataset.w]; if (!w || (n && !w.needs.includes(n))) return; try { w.paint(e); } catch (x) { e.innerHTML = '<div class="glass card empty err">خطا در نمایش ویجت</div>'; console.error(e.dataset.w, x); } });

/* ═════════ MARKETS ═════════ */
const mini = (r) => `<div class="sp" style="direction:ltr">${T.spark(r.spark, 90, 30, r.fcc)}</div>`;
V['mkt:watch'] = { needs: ['matrix', 'status'], live: true, paint(el) {
  const l = syms().map(s => ({ s, r: R(s) })).filter(x => x.r);
  el.innerHTML = `<div class="glass card"><h2>ارزهای زیر نظر <small>${N(l.length)}</small></h2>${l.length ? l.map(({ s, r }) => { const t = r.ticker || {}, u = (t.change_pct || 0) >= 0; return `<div class="wl" data-sheet="${esc(s)}">${coin(base(s), 32)}<div class="nm">${esc(base(s))}<div class="mu" style="font-size:.7rem;font-weight:600">${esc(r.grade || '')} · ${sg(r.cons, 0)}</div></div>${mini(r)}<div class="pr"><div class="n" style="font-weight:700">${fp(t.price)}</div><div class="n ${u ? 'up' : 'dn'}" style="font-size:.78rem">${pc(t.change_pct)}</div></div>${sdp(sideOf(r))}</div>`; }).join('') : empty('اسکن در حال انجام است…')}</div>`;
} };
V['mkt:heat'] = { needs: ['matrix', 'status'], live: true, paint(el) {
  const l = syms().filter(s => R(s)); if (!l.length) { el.innerHTML = `<div class="glass card">${loading}</div>`; return; }
  el.innerHTML = `<div class="glass card"><h2>نقشهٔ حرارتی سیگنال‌ها <small>امتیاز هر تایم‌فریم</small></h2><div class="heat" style="grid-template-columns:62px repeat(${ATF.length + 1},1fr)"><div style="cursor:default"></div>${ATF.map(t => `<div style="cursor:default;color:var(--mu)">${t}</div>`).join('')}<div style="cursor:default;color:var(--acc)">اجماع</div>
    ${l.map(s => { const r = R(s); return `<div style="text-align:left;cursor:pointer" data-sheet="${esc(s)}">${esc(base(s))}</div>${ATF.map(t => { const x = g(r, 'tfs.' + t, null); return x ? `<div style="background:${T.heatColor(x.side, x.score)}" data-hs="${esc(s)}|${t}">${fmt(x.score, 0)}</div>` : '<div style="cursor:default;opacity:.3">—</div>'; }).join('')}<div style="background:${T.heatColor(sideOf(r), r.cons)}" data-hs="${esc(s)}|${atf()}">${sg(r.cons, 0)}</div>`; }).join('')}</div></div>`;
} };
V['mkt:move'] = { needs: ['mkt'], live: true, paint(el) {
  const m = cur('mkt'), e = noData(m); if (e) { el.innerHTML = `<div class="glass card">${e}</div>`; return; }
  const sec = (t, a, f) => (a || []).length ? `<div class="glass card"><h2>${t}</h2>${a.slice(0, 5).map(i => `<div class="row" data-sheet="${esc(i.symbol)}" style="cursor:pointer"><span class="g">${coin(i.base, 24)} <b>${esc(i.base)}</b></span><span class="n ${i.chg >= 0 ? 'up' : 'dn'}">${f(i)}</span>${sdp(i.verdict)}</div>`).join('')}</div>` : '';
  el.innerHTML = sec('پرسودترین‌ها', m.gainers, i => pc(i.chg)) + sec('پرضررترین‌ها', m.losers, i => pc(i.chg)) + sec('پرنوسان‌ترین‌ها', m.volatile, i => 'ATR ' + fmt(i.atr, 2) + '٪') + sec('فشردگی (Squeeze)', m.squeeze, i => 'ATR ' + fmt(i.atr, 2) + '٪') + sec('بیشترین حجم', m.volume, i => '$' + fmt((i.qv || 0) / 1e6, 0) + 'M') + sec('بهترین سیگنال‌ها', m.best, i => sg(i.cons, 0));
} };
V['mkt:corr'] = { needs: ['mkt'], live: true, paint(el) {
  const m = cur('mkt'), e = noData(m, 'corr.names'); if (e) { el.innerHTML = `<div class="glass card">${e}</div>`; return; }
  const c = m.corr, n = c.names.length; el.innerHTML = `<div class="glass card"><h2>ماتریس همبستگی <small>${n} ارز</small></h2><div class="heat" style="grid-template-columns:42px repeat(${n},1fr)"><div></div>${c.names.map(x => `<div style="cursor:default;color:var(--mu);font-size:.62rem">${esc(x)}</div>`).join('')}${c.m.map((row, i) => `<div style="cursor:default;color:var(--mu);font-size:.62rem;text-align:left">${esc(c.names[i])}</div>${row.map(v => `<div style="cursor:default;font-size:.6rem;background:${v >= 0 ? `rgba(90,162,255,${.1 + Math.abs(v) * .7})` : `rgba(255,59,78,${.1 + Math.abs(v) * .7})`}">${num(v) ? v.toFixed(1) : ''}</div>`).join('')}`).join('')}</div><p class="mu" style="font-size:.78rem">آبی = هم‌جهت، قرمز = معکوس. برای تنوع پرتفوی ارزهای کم‌همبستگی انتخاب کنید.</p></div>`;
} };
V['mkt:mood'] = { needs: ['mkt'], live: true, paint(el) {
  const m = cur('mkt'), e = noData(m); if (e) { el.innerHTML = `<div class="glass card">${e}</div>`; return; }
  const pt = m.per_tf || {};
  el.innerHTML = `<div class="glass card"><h2>حال و هوای بازار</h2><div style="display:flex;align-items:center;gap:16px"><div class="gauge" style="width:130px;height:130px">${T.gauge(m.mood, m.mood >= 55 ? 'up' : m.mood <= 45 ? 'dn' : 'am')}<div class="t"><b style="font-size:1.8rem">${num(m.mood) ? m.mood : '—'}</b><small>از ۱۰۰</small></div></div><div class="kv" style="flex:1">${kv('میانگین اجماع', N(sg(m.avg_cons, 1)), m.avg_cons >= 0 ? 'up' : 'dn')}${kv('ارزها', N(m.n))}</div></div></div>
  ${ATF.filter(t => pt[t]).map(t => { const x = pt[t]; return `<div class="glass card"><h2>${t} <small>امتیاز ${N(sg(x.score, 1))}</small></h2><div class="kv c3">${kv('خرید', N(x.long), 'up')}${kv('فروش', N(x.short), 'dn')}${kv('RSI میانگین', N(fmt(x.rsi, 0)))}${kv('بالای EMA50', N(fmt(x.above50, 0) + '٪'))}${kv('بالای EMA200', N(fmt(x.above200, 0) + '٪'))}${kv('ADX', N(fmt(x.adx, 0)))}</div></div>`; }).join('')}`;
} };

/* ═════════ ANALYSIS ═════════ */
V['ana:sig'] = { needs: ['coin', 'plan', 'deep', 'status', 'matrix'], live: true, paint(el) {
  const d = cur('coin'), e = noData(d, 'signal'); if (e) { el.innerHTML = symHead() + `<div class="glass card">${e}</div>`; return; }
  const s = d.signal, pl = cur('plan'), dp = cur('deep'), c = cls(s.side), cf = p100(s.confidence), rows = s.side === 'WAIT' ? [] : g(pl, s.side === 'LONG' ? 'long.rows' : 'short.rows', []);
  const comps = (s.components || []).slice().sort((a, b) => Math.abs((b.s || 0) * (b.w || 1)) - Math.abs((a.s || 0) * (a.w || 1))).slice(0, 8), gr = g(dp, 'grade', null), best = rows.length ? Math.max(...rows.map(z => z.ev_r)) : null;
  el.innerHTML = symHead() + `<div class="glass card"><h2>سیگنال ${atf()}</h2><div style="display:flex;align-items:center;gap:14px"><div class="gauge" style="width:104px;height:104px">${T.gauge(num(cf) ? cf : 10, s.side === 'SHORT' ? 'dn' : s.side === 'WAIT' ? 'am' : 'up')}<div class="t"><b class="${c}">${FA[s.side] || s.side}</b><small>${num(cf) ? cf.toFixed(0) + '٪' : ''}</small></div></div><div class="kv" style="flex:1">${kv('امتیاز', N(fmt(s.score, 1)))}${kv('R:R', N(fmt(s.risk_reward, 2)))}${kv('رژیم', esc(s.regime || '—'))}${kv('درجه', esc(g(gr, 'grade', '—')))}</div></div>
    <div class="kv c3" style="margin-top:10px">${kv('ورود', N(fp(s.entry)))}${kv('حد ضرر', N(fp(s.stop)), 'dn')}${kv('TP1', N(fp(s.tp1)), 'up')}${kv('TP2', N(fp(s.tp2)), 'up')}${kv('TP3', N(fp(s.tp3)), 'up')}${kv('ریسک٪', N(num(s.entry) && num(s.stop) ? fmt(Math.abs(s.entry - s.stop) / s.entry * 100, 2) + '٪' : '—'))}</div>
    <div class="acts"><button class="btn ${s.side === 'SHORT' ? 'r' : 'g'}" data-act="to-ticket" ${s.side === 'WAIT' ? 'disabled' : ''}>ارسال به برگهٔ سفارش</button><button class="btn o" data-go="ana:fc">پیش‌بینی روی نمودار</button></div></div>
    ${rows.length ? `<div class="glass card"><h2>روش‌های ورود <small>امید ریاضی R</small></h2>${rows.slice(0, 4).map(r => `<div class="row"><span class="g">${esc(r.name || r.k)}${r.ev_r === best ? ' ⭐' : ''}</span><span class="mu n">TP1 ${fmt(p100(r.p_tp1), 0)}٪</span><b class="n ${r.ev_r >= 0 ? 'up' : 'dn'}">${sg(r.ev_r, 2)}R</b></div>`).join('')}</div>` : ''}
    <div class="glass card"><h2>دلایل</h2>${(s.reasons || []).length ? `<ul class="ls">${s.reasons.map(x => `<li>${esc(x)}</li>`).join('')}</ul>` : empty('دلیلی ثبت نشده')}${(s.warnings || []).length ? `<div class="sh">هشدارها</div><ul class="ls am">${s.warnings.map(x => `<li>${esc(x)}</li>`).join('')}</ul>` : ''}</div>
    ${comps.length ? `<div class="glass card"><h2>قوی‌ترین مولفه‌ها</h2>${comps.map(x => `<div class="row"><span class="g">${esc(x.n)}<div class="mu" style="font-size:.72rem">${esc(x.t || '')}</div></span><span style="width:80px">${bar(50 + (x.s || 0) * 50, (x.s || 0) > 0 ? '' : 'dn', 1)}</span></div>`).join('')}${gr && gr.why ? `<div class="sh">درجه‌بندی ${esc(gr.grade || '')}</div>${gr.why.map(w => `<div class="row"><span>${esc(w.t)}</span><b class="n ${w.p >= 0 ? 'up' : 'dn'}">${sg(w.p, 0)}</b></div>`).join('')}` : ''}</div>` : ''}`;
} };
V['ana:tf'] = { needs: ['coin', 'deep'], live: true, paint(el) {
  const d = cur('coin'), e = noData(d, 'all_tf'); if (e) { el.innerHTML = symHead() + `<div class="glass card">${e}</div>`; return; }
  const dp = cur('deep'), fcs = d.all_forecasts || {};
  el.innerHTML = symHead() + `<div class="glass card"><h2>هم‌افزایی تایم‌فریم‌ها</h2>${ATF.filter(t => d.all_tf[t]).map(t => { const x = d.all_tf[t], pu = p100(g(fcs[t], 'prob_up', null)); return `<div class="row" data-tf="${t}" style="cursor:pointer"><b style="width:32px;direction:ltr">${t}</b>${tag(x.side)}<span class="g">${bar(Math.min(100, Math.abs(x.score || 0)), cls(x.side) === 'up' ? '' : cls(x.side))}</span><span class="n mu" style="width:34px">${fmt(x.score, 0)}</span><span class="n ${pu >= 50 ? 'up' : 'dn'}" style="width:44px">${num(pu) ? pu.toFixed(0) + '٪↑' : ''}</span></div>`; }).join('')}</div>
  ${dp && !dp.error ? `<div class="glass card"><h2>جمع‌بندی عمیق</h2><div class="kv c3">${kv('هم‌جهتی', esc(String(dp.agreement || '—').replace(/_/g, ' ')))}${kv('اجماع وزنی', N(sg(dp.consensus_score, 0)), dp.consensus_score >= 0 ? 'up' : 'dn')}${kv('اطمینان', num(dp.conviction) ? N(p100(dp.conviction).toFixed(0) + '٪') : '—')}</div>${dp.narrative ? `<p class="mu" style="font-size:.86rem;line-height:1.9">${esc(dp.narrative)}</p>` : ''}</div>` : ''}`;
} };
V['ana:fc'] = { needs: ['coin', 'k'], live: true, paint(el) {
  if (!$('#cv-fc', el)) { el.innerHTML = symHead() + `<div class="glass card" style="padding:8px">${T.chartHTML('cv-fc', true)}</div><div id="fc-info"></div>`; T.chartInit('cv-fc'); }
  $$('[data-tf]', el).forEach(b => b.classList.toggle('on', b.dataset.tf === ST.tf));
  const d = cur('coin'), f = d && d.forecast, box = $('#fc-info', el); if (!f) { box.innerHTML = `<div class="glass card">${noData(d, 'forecast') || empty('پیش‌بینی در دسترس نیست')}</div>`; T.redrawCharts(); return; }
  const pu = p100(f.prob_up), ed = f.edge || {}, h = f.hist || {}, cnt = h.counts || [], mx = Math.max(1, ...cnt), sp = f.step_prob || [];
  box.innerHTML = `${ST.tf !== atf() ? `<div class="glass card am" style="font-size:.85rem">کندل‌های آینده فقط روی تایم‌فریم‌های تحلیلی (${ATF.join('، ')}) نمایش داده می‌شوند.</div>` : ''}
    <div class="glass card"><h2>پیش‌بینی ${f.n || ''} کندل بعدی</h2><div class="row"><span>احتمال صعود</span><b class="n ${pu >= 50 ? 'up' : 'dn'}">${num(pu) ? pu.toFixed(0) + '٪' : '—'}</b></div>${bar(pu, pu >= 50 ? '' : 'dn')}
    <div class="kv c3" style="margin-top:10px">${kv('حرکت مورد انتظار', N(pc(f.expected_move_pct)), f.expected_move_pct >= 0 ? 'up' : 'dn')}${kv('نوسان σ', N(num(f.sigma_pct) ? f.sigma_pct.toFixed(2) + '٪' : '—'))}${kv('اطمینان', N(num(f.confidence) ? (f.confidence * 100).toFixed(0) + '٪' : '—'))}${kv('احتمال > +۱٪', N(num(f.p_up10) ? (f.p_up10 * 100).toFixed(0) + '٪' : '—'), 'up')}${kv('احتمال < −۱٪', N(num(f.p_dn10) ? (f.p_dn10 * 100).toFixed(0) + '٪' : '—'), 'dn')}${kv('میانهٔ محدوده', N(fp(g(f, 'cone.mid'))))}</div>
    ${cnt.length ? `<div class="sh">توزیع بازده شبیه‌سازی‌شده</div><svg viewBox="0 0 ${cnt.length * 6} 60" preserveAspectRatio="none" style="width:100%;height:60px">${cnt.map((c, i) => { const e2 = (h.edges || [])[i]; return `<rect x="${i * 6 + .5}" y="${60 - c / mx * 58}" width="5" height="${c / mx * 58}" rx="1" fill="${num(e2) && e2 < 0 ? 'var(--dn)' : 'var(--up)'}" opacity=".8"/>`; }).join('')}</svg>` : ''}</div>
    ${ed.p_tp1 != null ? `<div class="glass card"><h2>لبهٔ آماری معامله</h2><div class="kv c3">${kv('P(TP1)', N(fmt(ed.p_tp1 * 100, 0) + '٪'), 'up')}${kv('P(TP2)', N(fmt(ed.p_tp2 * 100, 0) + '٪'), 'up')}${kv('P(TP3)', N(fmt(ed.p_tp3 * 100, 0) + '٪'), 'up')}${kv('P(استاپ)', N(fmt(ed.p_stop * 100, 0) + '٪'), 'dn')}${kv('EV', N(sg(ed.ev_r, 2) + 'R'), ed.ev_r >= 0 ? 'up' : 'dn')}${kv('کلی', N(fmt(ed.kelly, 2)))}</div></div>` : ''}
    ${sp.length ? `<div class="glass card"><h2>احتمال صعود در هر کندل</h2>${T.spark(sp.map(v => v * 100), 300, 50).replace(/width="300" height="50"/, 'style="width:100%;height:50px"')}</div>` : ''}`;
  T.redrawCharts();
} };
V['ana:ind'] = { needs: ['coin'], live: true, paint(el) {
  const s = SIG(); if (!s) { el.innerHTML = symHead() + `<div class="glass card">${noData(cur('coin'), 'signal') || loading}</div>`; return; }
  const I = s.indicators || {}, o = g(s, 'extras.osc', {}), ox = {}; (o.osc || []).forEach(x => ox[x.n] = x); const sc = v => v > 0 ? 'up' : v < 0 ? 'dn' : '';
  const lab = (t, l, c) => `<div>${t}<b class="${/خرید/.test(l || '') ? 'up' : /فروش/.test(l || '') ? 'dn' : ''}">${esc(l || '—')}</b>${c ? `<span style="font-size:.7rem">${N(c)}</span>` : ''}</div>`;
  el.innerHTML = symHead() + `<div class="glass card"><h2>جمع‌بندی اندیکاتورها</h2><div class="kv c3">${lab('کل', o.all_label)}${lab('اسیلاتورها', o.osc_label, `${o.osc_buy ?? 0}/${o.osc_neu ?? 0}/${o.osc_sell ?? 0}`)}${lab('میانگین‌ها', o.ma_label, `${o.ma_buy ?? 0}/${o.ma_sell ?? 0}`)}</div>
  <div class="kv c3" style="margin-top:8px">${kv('RSI 14', N(fmt(g(ox, 'RSI 14.v'), 1)), sc(g(ox, 'RSI 14.s', 0)))}${kv('ADX', N(fmt(I.adx, 1)))}${kv('ATR٪', N(fmt(I.atr_pct, 2)))}${kv('MACD hist', N(fmt(I.macd_hist, 4)), sc(I.macd_hist))}${kv('BB موقعیت', N(fmt(I.bb_pos, 2)))}${kv('MFI', N(fmt(I.mfi, 0)))}${kv('CMF', N(fmt(I.cmf, 2)), sc(I.cmf))}${kv('EMA 9', N(fp(I.ema9)))}${kv('EMA 200', N(fp(I.ema200)))}</div></div>
  ${(o.osc || []).length ? `<div class="glass card"><h2>اسیلاتورها</h2>${o.osc.slice(0, 14).map(x => `<div class="row"><span class="g">${esc(x.n)}</span><span class="n mu">${fmt(x.v, 2)}</span><span class="tag ${x.s > 0 ? 'up' : x.s < 0 ? 'dn' : 'am'}" style="min-width:54px;text-align:center">${x.s > 0 ? 'خرید' : x.s < 0 ? 'فروش' : 'خنثی'}</span></div>`).join('')}</div>` : ''}`;
} };
V['ana:lvl'] = { needs: ['coin'], live: true, paint(el) {
  const s = SIG(); if (!s) { el.innerHTML = symHead() + `<div class="glass card">${noData(cur('coin'), 'signal') || loading}</div>`; return; }
  const L = s.levels || {}, X = s.extras || {}, sm = X.smc || {}, pv = X.pivots || {}, fb = X.fib || {}, px = s.entry;
  const lst = (a, c, t) => (a || []).slice(0, 4).map(v => `<div class="row"><span class="mu">${t}</span><b class="n ${c}">${fp(v)}</b><span class="n mu">${num(px) ? pc((v - px) / px * 100) : ''}</span></div>`).join('');
  el.innerHTML = symHead() + `<div class="glass card"><h2>حمایت و مقاومت</h2>${lst(L.resistance, 'dn', 'مقاومت')}${lst(L.support, 'up', 'حمایت') || ''}${!(L.resistance || []).length && !(L.support || []).length ? empty('سطحی یافت نشد') : ''}</div>
  ${pv.p ? `<div class="glass card"><h2>پیوت‌ها</h2><div class="kv c3">${kv('R1', N(fp(pv.r1)), 'dn')}${kv('P', N(fp(pv.p)))}${kv('S1', N(fp(pv.s1)), 'up')}</div></div>` : ''}
  ${sm.structure ? `<div class="glass card"><h2>ساختار بازار (SMC)</h2><div class="kv">${kv('ساختار', esc(sm.structure.label || '—'), sm.structure.trend === 'bull' ? 'up' : sm.structure.trend === 'bear' ? 'dn' : '')}${kv('محدوده', esc(g(sm, 'range.zone', '—')))}${kv('FVG باز', N((sm.fvg || []).filter(f => !f.partial).length + ' / ' + (sm.fvg || []).length))}${kv('اوردر بلاک', N((sm.ob || []).filter(o => !o.touched).length + ' / ' + (sm.ob || []).length))}${sm.event ? kv('آخرین رویداد', esc(sm.event.kind + (sm.event.dir === 'up' ? ' ↑' : ' ↓'))) : ''}${sm.sweep ? kv('جاروی نقدینگی', esc(sm.sweep.kind || '✓')) : ''}</div></div>` : ''}
  ${fb.near ? `<div class="glass card"><h2>فیبوناچی ${fb.dir === 'up' ? 'صعودی' : 'نزولی'}</h2><div class="kv">${kv('نزدیک‌ترین', N(fb.near.r + ' → ' + fp(fb.near.p)))}${kv('بازه', N(fp(fb.lo) + '–' + fp(fb.hi)))}</div></div>` : ''}`;
} };
V['ana:pat'] = { needs: ['pat'], live: true, paint(el) {
  const d = cur('pat'), e = noData(d); if (e) { el.innerHTML = symHead() + `<div class="glass card">${e}</div>`; return; }
  const rc = (d.recent || []).slice(0, 8), sts = (d.structs || []).slice(0, 5), sm = d.summary || {};
  el.innerHTML = symHead() + `${(sm.items || []).length ? `<div class="glass card"><h2>خلاصه</h2><div class="chips" style="margin:0">${sm.items.map(x => `<span class="tag ${sm.score >= 0 ? 'up' : 'dn'}">${esc(x)}</span>`).join('')}</div></div>` : ''}
  ${sts.length ? `<div class="glass card"><h2>ساختارهای نموداری</h2>${sts.map(x => `<div class="row"><span class="g"><b>${esc(x.fa || x.k)}</b><div class="mu" style="font-size:.74rem">${esc(x.expect || x.meaning || '')}</div></span>${x.target ? `<span class="n ${x.bias >= 0 ? 'up' : 'dn'}">→ ${fp(x.target)}</span>` : ''}</div>`).join('')}</div>` : ''}
  ${rc.length ? `<div class="glass card"><h2>الگوهای کندلی اخیر</h2>${rc.map(x => `<div class="row"><span class="g"><b>${esc(x.fa || x.k)}</b><div class="mu" style="font-size:.74rem">${esc(x.meaning || '')}</div></span><span class="tag ${x.bias > 0 ? 'up' : x.bias < 0 ? 'dn' : 'am'}">${x.ago} کندل پیش</span></div>`).join('')}</div>` : ''}
  ${!rc.length && !sts.length && !(sm.items || []).length ? `<div class="glass card">${empty('الگوی معناداری یافت نشد')}</div>` : ''}`;
} };
V['ana:depth'] = { needs: ['micro'], live: true, paint(el) {
  const d = cur('micro'), e = noData(d); if (e) { el.innerHTML = symHead() + `<div class="glass card">${e}</div>`; return; }
  const p = d.depth || {}, v = d.derivs || {};
  el.innerHTML = symHead() + `<div class="glass card"><h2>دفتر سفارش</h2>${p.ok ? `<div class="row"><span>عدم‌توازن (۱٪)</span><b class="n ${p.imb_1pct >= 0 ? 'up' : 'dn'}">${sg(p.imb_1pct * 100, 0)}٪</b></div>${bar(50 + (p.imb_1pct || 0) * 50, p.imb_1pct >= 0 ? '' : 'dn', 1)}<div class="kv c3" style="margin-top:10px">${kv('خرید ±۱٪', N('$' + fmt((p.bid_usd_1pct || 0) / 1e6, 2) + 'M'), 'up')}${kv('فروش ±۱٪', N('$' + fmt((p.ask_usd_1pct || 0) / 1e6, 2) + 'M'), 'dn')}${kv('اسپرد', N(fmt(p.spread_pct, 3) + '٪'))}</div>` : empty('دفتر سفارش در دسترس نیست')}</div>
  ${v.ok ? `<div class="glass card"><h2>مشتقات</h2><div class="kv c3">${kv('فاندینگ', N(fmt(v.funding_pct, 4) + '٪'), v.funding_pct > 0 ? 'am' : '')}${kv('OI', N('$' + fmt((v.oi_usd || 0) / 1e6, 1) + 'M'))}${kv('Long ratio', N(fmt(p100(v.ls_buy), 0) + '٪'))}${kv('بیسیس', N(fmt(v.basis_pct, 3) + '٪'))}${kv('Mark', N(fp(v.mark)))}${kv('APR فاندینگ', N(fmt(v.funding_apr, 1) + '٪'))}</div></div>` : ''}`;
} };
V['ana:bt'] = { needs: ['bt'], live: true, paint(el) {
  const d = cur('bt'), e = noData(d); if (e) { el.innerHTML = symHead() + `<div class="glass card">${e}</div>`; return; }
  if (!d.n) { el.innerHTML = symHead() + `<div class="glass card">${empty('معامله‌ای در دورهٔ بک‌تست نبود')}</div>`; return; }
  const eq = d.equity || [], by = d.by_side || {};
  el.innerHTML = symHead() + `<div class="glass card"><h2>بک‌تست ${atf()}</h2><div class="kv c3">${kv('معاملات', N(d.n))}${kv('نرخ برد', N(fmt(d.win_rate, 1) + '٪'), d.win_rate >= 50 ? 'up' : 'dn')}${kv('ضریب سود', N(fmt(d.pf, 2)), d.pf >= 1.3 ? 'up' : d.pf >= 1 ? 'am' : 'dn')}${kv('مجموع R', N(sg(d.total_r, 1)), d.total_r >= 0 ? 'up' : 'dn')}${kv('میانگین R', N(sg(d.avg_r, 2)))}${kv('حداکثر افت', N(fmt(d.max_dd_r, 1) + 'R'), 'dn')}</div>
  <div class="row"><span>معناداری آماری</span><span class="tag ${d.significant ? 'up' : 'am'}">${d.significant ? 'معنادار' : 'نامعنادار'} · t=${N(fmt(d.t_stat, 1))}</span></div>
  ${Object.entries(by).map(([k, v]) => `<div class="row">${tag(k)}<span class="n mu">n=${g(v, 'n', '—')}</span><span class="n">${num(g(v, 'win_rate', null)) ? fmt(v.win_rate, 0) + '٪ برد' : ''}</span><b class="n">${num(g(v, 'total_r', null)) ? sg(v.total_r, 1) + 'R' : ''}</b></div>`).join('')}
  ${eq.length > 1 ? `<div class="sh">منحنی سرمایه (R)</div>${T.spark(eq, 300, 60).replace(/width="300" height="60"/, 'style="width:100%;height:70px"')}` : ''}<div class="mu" style="font-size:.78rem;margin-top:6px">خرید‌ونگه‌داری همین دوره: ${N(pc(d.buy_hold_pct))}</div></div>`;
} };

/* ═════════ AI CENTER ═════════ */
V['ai:opin'] = { needs: ['ai', 'deep', 'coin'], live: true, paint(el) {
  const a = cur('ai'), e = noData(a); if (e) { el.innerHTML = symHead() + `<div class="glass card">${e}</div>`; return; }
  const cf = p100(a.confidence), dp = cur('deep'), gk = a.side === 'SHORT' ? 'dn' : a.side === 'WAIT' ? 'am' : 'up';
  el.innerHTML = symHead() + `<div class="glass card gold"><h2>${ic('ai').replace('<svg', '<svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2"')}نظر هوش مصنوعی <small>${a.source === 'gemini' ? 'Gemini' : 'موتور محلی'}</small></h2>
  <div style="display:flex;align-items:center;gap:14px"><div class="gauge">${T.gauge(num(cf) ? cf : 10, gk)}<div class="t"><b class="${cls(a.side)}">${FA[a.side] || 'صبر'}</b><small>${num(cf) ? cf.toFixed(0) + '٪' : ''}</small></div></div><p style="flex:1;margin:0;font-size:.92rem;line-height:1.9">${esc(a.summary || a.error || '')}</p></div>
  ${(a.bullets || []).length ? `<ul class="ls" style="margin-top:8px">${a.bullets.map(x => `<li>${esc(x)}</li>`).join('')}</ul>` : ''}${a.risk_note ? `<p class="am" style="font-size:.82rem">${esc(a.risk_note)}</p>` : ''}<div class="acts"><button class="btn y" data-act="ai-re">تحلیل دوباره</button><button class="btn o" data-go="ai:scen">سناریوها</button></div></div>
  ${dp && !dp.error && dp.narrative ? `<div class="glass card"><h2>روایت چندتایم‌فریم</h2><p class="mu" style="font-size:.88rem;line-height:1.9;margin:0">${esc(dp.narrative)}</p></div>` : ''}`;
} };
V['ai:scen'] = { needs: ['coin', 'k'], live: true, paint(el) {
  const f = T.forecastOf(), kl = g(cur('k'), 'klines', []), s = SIG(); if (!f) { el.innerHTML = symHead() + `<div class="glass card">${noData(cur('coin')) || empty('پیش‌بینی در دسترس نیست')}</div>`; return; }
  const b = f.bands || {}, n = Math.min(f.candles.length, (b.p50 || []).length) - 1, p0 = num(g(s, 'entry', null)) ? s.entry : (kl.length ? kl[kl.length - 1].c : null);
  const sc = [['صعودی', 'p90', 'up', f.p_up10], ['پایه', 'p50', 'info', null], ['نزولی', 'p10', 'dn', f.p_dn10]].map(([t, k, c, pr]) => { const v = (b[k] || [])[n]; return { t, c, v, pr, ch: num(v) && p0 ? (v - p0) / p0 * 100 : null }; });
  el.innerHTML = symHead() + `<div class="glass card"><h2>سناریوهای ${n + 1} کندل بعدی (${atf()})</h2>${sc.map(x => `<div class="glass card" style="--r:16px;margin-top:8px"><div class="row" style="border:0;padding:0"><b class="${x.c}">${x.t}</b><b class="n">${fp(x.v)}</b><b class="n ${x.c}">${pc(x.ch)}</b></div>${x.pr != null ? `<div class="mu" style="font-size:.78rem;margin:4px 0">احتمال حرکت ${x.c === 'up' ? 'بیش از +۱٪' : 'کمتر از −۱٪'}: ${N(fmt(x.pr * 100, 0) + '٪')}</div>${bar(x.pr * 100, x.c === 'up' ? '' : 'dn')}` : '<div class="mu" style="font-size:.78rem;margin-top:4px">میانهٔ مسیرهای شبیه‌سازی</div>'}</div>`).join('')}</div>
  <div class="glass card"><h2>برنامهٔ ریسک</h2>${s && s.side !== 'WAIT' ? `<div class="kv c3">${kv('ورود', N(fp(s.entry)))}${kv('حد ضرر', N(fp(s.stop)), 'dn')}${kv('TP1', N(fp(s.tp1)), 'up')}</div>` : empty('سیگنال فعالی برای برنامهٔ ریسک نیست')}<p class="mu" style="font-size:.78rem">این سناریوها خروجی شبیه‌سازی آماری‌اند، نه تضمین.</p></div>`;
} };
V['ai:pick'] = { needs: ['matrix'], live: true, paint(el) {
  const l = rank().filter(x => sideOf(x.r) !== 'WAIT'), sec = (t, side) => { const a = l.filter(x => sideOf(x.r) === side).sort((x, y) => y.k - x.k).slice(0, 6); return `<div class="glass card"><h2>${t}</h2>${a.length ? a.map(x => `<div class="wl" data-sheet="${esc(x.s)}">${coin(base(x.s), 30)}<div class="nm">${esc(base(x.s))}<div class="mu" style="font-size:.7rem">${esc(x.r.grade || '')} · ${sg(x.r.cons, 0)}</div></div>${mini(x.r)}<div class="pr n" style="font-weight:700">${fp(g(x.r, 'ticker.price'))}</div></div>`).join('') : empty('موردی نیست')}</div>`; };
  el.innerHTML = sec('برترین‌های خرید', 'LONG') + sec('برترین‌های فروش', 'SHORT');
} };
V['ai:al'] = { needs: ['alerts'], live: true, paint(el) {
  if (!$('#al-list', el)) el.innerHTML = `<div class="glass card"><h2>هشدارها</h2><div id="al-list"></div></div><div class="glass card"><h2>هشدار قیمتی <small>${esc(base(ST.sel))}</small></h2><div class="f" style="margin-top:0"><select id="al-op" style="max-width:110px"><option value=">">بالاتر از</option><option value="<">پایین‌تر از</option></select><input id="al-px" type="number" step="any" inputmode="decimal" placeholder="قیمت"></div><div class="acts"><button class="btn" data-act="al-add">افزودن</button><button class="btn o" data-act="al-sig">هشدار سیگنال درجه B</button></div></div>`;
  const d = cur('alerts'), l = $('#al-list', el), e = noData(d); if (e) { l.innerHTML = e; return; }
  l.innerHTML = (d.alerts || []).length ? d.alerts.map(x => `<div class="row"><span class="g"><b>${esc(base(x.symbol))}</b> ${x.type === 'price' ? `${x.op === '>' ? 'بالاتر از' : 'پایین‌تر از'} ${N(fp(x.price))}` : 'سیگنال درجه ' + esc(x.min_grade)}</span><span class="tag ${x.fired ? 'am' : ''}">${x.fired ? 'فعال شد' : 'منتظر'}</span><button class="btn s o" data-act="al-del" data-id="${esc(x.id)}" aria-label="حذف">✕</button></div>`).join('') : empty('هشداری ثبت نشده');
} };
V['ai:trk'] = { needs: ['log', 'ev'], live: true, paint(el) {
  const l = cur('log'), ev = cur('ev'); if (!l && !ev) { el.innerHTML = `<div class="glass card">${loading}</div>`; return; }
  const en = g(l, 'entries', []).slice(-10).reverse(), p = g(l, 'path', {}), a = g(ev, 'agg', null);
  el.innerHTML = `${a ? `<div class="glass card"><h2>شواهد بک‌تست همهٔ ارزها</h2><div class="kv c3">${kv('معاملات', N(a.trades))}${kv('نرخ برد', N(fmt(a.win, 1) + '٪'))}${kv('میانگین R', N(sg(a.avg_r, 2)), a.avg_r >= 0 ? 'up' : 'dn')}${kv('ارز مثبت', N(a.positive + '/' + a.coins))}${kv('معنادار', N(a.significant))}</div></div>` : ''}
  <div class="glass card"><h2>سیگنال‌های ثبت‌شده <small>${N(g(l, 'total', 0))} / ${N(g(l, 'resolved', 0))} نتیجه‌دار</small></h2>${num(p.tp1_rate) || num(p.sl_rate) ? `<div class="kv">${kv('رسیدن به TP1', N(fmt(p100(p.tp1_rate), 0) + '٪'), 'up')}${kv('خوردن حد ضرر', N(fmt(p100(p.sl_rate), 0) + '٪'), 'dn')}</div>` : ''}${en.length ? en.map(x => `<div class="row"><span class="g"><b>${esc(base(x.symbol))}</b> ${tag(x.verdict)} <span class="mu" style="font-size:.74rem">${esc(x.grade || '')}</span></span><span class="mu" style="font-size:.74rem">${ago(x.t)}</span><span class="tag ${x.hit === 'tp1' ? 'up' : x.hit === 'sl' ? 'dn' : ''}">${x.hit ? esc(x.hit) : 'باز'}</span></div>`).join('') : empty('هنوز سیگنالی ثبت نشده')}</div>`;
} };


V['ana:x10'] = { needs: ['coin'], live: true, paint(el) {
  const s = SIG(), x = g(s, 'extras.x10', null);
  el.innerHTML = symHead() + (x && x.items ? `<div class="glass card"><h2>x10 · کیفیت / زمان‌بندی / جریان <small>${esc(x.quality_label || '')}</small></h2>
  <div class="kv c3">${kv('کیفیت', N(x.quality))}${kv('زمان‌بندی', N(sg(x.timing, 0)))}${kv('جریان', N(sg(x.flow, 0)))}</div>
  ${Object.entries(x.items).map(([k, it]) => `<div class="ix ${(it.s || 0) > 0.2 ? 'up' : (it.s || 0) < -0.2 ? 'dn' : ''}"><div class="h"><span class="nm">${esc(it.n || k)}</span><span class="tag">${esc(it.role || '')}</span><b class="n">${it.v != null ? it.v : '—'}</b></div><div class="t">${esc(it.t || '')}</div></div>`).join('')}</div>` : `<div class="glass card">${empty('داده x10 نیست')}</div>`);
} };
V['ana:x11'] = { needs: ['coin'], live: true, paint(el) {
  const s = SIG(), x = g(s, 'extras.x11', null);
  el.innerHTML = symHead() + (x && x.items ? `<div class="glass card"><h2>x11 · ساختار و مشارکت</h2>
  ${Object.entries(x.items).map(([k, it]) => `<div class="ix ${(it.s || 0) > 0.2 ? 'up' : (it.s || 0) < -0.2 ? 'dn' : ''}"><div class="h"><span class="nm">${esc(it.n || k)}</span><b class="n">${it.v != null ? it.v : '—'}</b></div><div class="t">${esc(it.t || '')}</div></div>`).join('')}
  ${x.levels ? `<div class="kv c3" style="margin-top:10px">${Object.entries(x.levels).map(([k, v]) => kv(esc(k), N(fp(v)))).join('')}</div>` : ''}</div>` : `<div class="glass card">${empty('داده x11 نیست')}</div>`);
} };
V['ana:x12'] = { needs: ['coin'], live: true, paint(el) {
  const s = SIG(), x = g(s, 'extras.x12', null);
  el.innerHTML = symHead() + (x && x.items ? `<div class="glass card"><h2>x12 · رژیم / فشار / مسیر <small>${esc(x.label || '')}</small></h2>
  <div class="kv c3">${kv('امتیاز', N(sg(x.score, 0)), (x.score || 0) >= 0 ? 'up' : 'dn')}${kv('صعودی', N(x.bull))}${kv('نزولی', N(x.bear))}</div>
  ${Object.entries(x.items).map(([k, it]) => `<div class="ix ${(it.s || 0) > 0.2 ? 'up' : (it.s || 0) < -0.2 ? 'dn' : ''}"><div class="h"><span class="nm">${esc(it.n || k)}</span><span class="chipx">${esc(it.role_fa || it.role || '')}</span><b class="n">${it.v != null ? it.v : '—'}</b></div><div class="t">${esc(it.t || '')}</div></div>`).join('')}</div>` : `<div class="glass card">${empty('داده x12 نیست — پس از اسکن ظاهر می‌شود')}</div>`);
} };
V['ana:gov'] = { needs: ['deep', 'coin', 'matrix'], live: true, paint(el) {
  const d = cur('deep'), s = SIG(), r = R(ST.sel);
  const gov = g(d, 'governor', null) || g(s, 'governor', null) || {};
  el.innerHTML = symHead() + `<div class="glass card"><h2>حاکم مرکزی · Governor</h2>
  <div class="kv c3">${kv('طرف', N(esc(gov.side || g(s, 'side', '—'))))}${kv('درجه', N(esc(g(r, 'grade', '—'))))}${kv('لبه', N(fmt(gov.edge, 2)))}
  ${kv('حاشیه', N(fmt(gov.margin, 2)))}${kv('اعتماد', N(fmt(gov.confidence != null ? gov.confidence : g(s, 'confidence', null), 2)))}${kv('وتو', N(gov.veto ? 'فعال' : 'خیر'), gov.veto ? 'dn' : 'up')}</div>
  ${gov.weights ? `<div class="sh">وزن شواهد</div><div class="kv c3">${Object.entries(gov.weights).map(([k, v]) => kv(esc(k), N(fmt(v, 2)))).join('')}</div>` : ''}
  <div class="note">${esc(gov.reason || gov.note || g(s, 'summary', 'هسته مرکزی همهٔ لایه‌ها (فنی، x10/x11/x12، بافت، شواهد) را هماهنگ می‌کند.'))}</div>
  ${(g(s, 'warnings', []) || []).map(w => `<span class="chipx am">${esc(w)}</span>`).join('')}</div>
  <div class="glass card"><h2>لایه‌های متصل</h2><div class="chips">
  <button class="btn s o" data-go="ana:sig">سیگنال</button><button class="btn s o" data-go="ana:x10">x10</button>
  <button class="btn s o" data-go="ana:x11">x11</button><button class="btn s o" data-go="ana:x12">x12</button>
  <button class="btn s o" data-go="ana:tf">تایم‌فریم</button><button class="btn s o" data-go="lab:sum">آزمایشگاه</button>
  <button class="btn s o" data-go="ai:ready">آمادگی</button></div></div>`;
} };
V['ana:ev'] = { needs: ['ev', 'log'], live: true, paint(el) {
  const ev = cur('ev'), log = cur('log'), a = g(ev, 'agg', null);
  el.innerHTML = `<div class="glass card"><h2>شواهد تجمیعی</h2>
  ${a ? `<div class="kv c3">${kv('معاملات', N(a.trades))}${kv('نرخ برد', N(fmt(a.win, 1) + '٪'))}${kv('R میانگین', N(sg(a.avg_r, 2)), a.avg_r >= 0 ? 'up' : 'dn')}${kv('ارز مثبت', N((a.positive || 0) + '/' + (a.coins || 0)))}${kv('معنادار', N(a.significant ? 'بله' : 'خیر'))}</div>` : empty('هنوز شواهد کافی نیست')}
  </div><div class="glass card"><h2>سیگنال‌های ثبت‌شده</h2><div class="note">کل: ${N(g(log, 'total', 0))} · نتیجه‌دار: ${N(g(log, 'resolved', 0))}</div></div>`;
} };
V['ai:ready'] = { needs: ['ready'], live: true, paint(el) {
  const d = cur('ready');
  if (!d || d.error) { el.innerHTML = `<div class="glass card">${noData(d) || loading}</div>`; return; }
  el.innerHTML = `<div class="glass card"><h2>آمادگی معامله و فوروارد</h2>
  <div class="kv c3">${Object.entries(d).filter(([k, v]) => typeof v !== 'object').slice(0, 12).map(([k, v]) => kv(esc(k), N(typeof v === 'number' ? fmt(v, 2) : esc(String(v))))).join('')}</div>
  <pre class="note" style="direction:ltr;text-align:left;font-size:.7rem;white-space:pre-wrap">${esc(JSON.stringify(d, null, 1).slice(0, 1200))}</pre></div>`;
} };
V['lab:deep'] = { needs: ['deep', 'coin'], live: true, paint(el) {
  const d = cur('deep');
  el.innerHTML = symHead() + (d && !d.error ? `<div class="glass card"><h2>تحلیل عمیق</h2><pre class="note" style="direction:ltr;text-align:left;font-size:.68rem;white-space:pre-wrap;max-height:60vh;overflow:auto">${esc(JSON.stringify({ signal: d.signal, grade: d.grade, governor: d.governor, regime: d.regime }, null, 1).slice(0, 4000))}</pre></div>` : `<div class="glass card">${noData(d) || loading}</div>`);
} };
V['lab:pro'] = { needs: ['coin'], live: true, paint(el) {
  const s = SIG();
  el.innerHTML = symHead() + `<div class="glass card"><h2>هسته PRO · اجزای امتیاز</h2>
  ${(g(s, 'components', []) || []).slice(0, 40).map(c => `<div class="row"><span class="g">${esc(c.n || c.id || '')} <small class="mu">${esc(c.g || '')}</small></span><b class="n ${(c.s || 0) >= 0 ? 'up' : 'dn'}">${sg(c.s, 2)}</b></div>`).join('') || empty('اجزا پس از اسکن')}
  </div>`;
} };
V['ex:pol'] = { needs: ['cfg', 'status'], live: true, paint(el) {
  const cfg = cur('cfg');
  el.innerHTML = `<div class="glass card"><h2>سیاست معامله</h2>
  <pre class="note" style="direction:ltr;text-align:left;font-size:.7rem;white-space:pre-wrap">${esc(JSON.stringify(cfg || {}, null, 1).slice(0, 2500))}</pre></div>`;
} };
V['more:core'] = { needs: ['status', 'matrix'], live: false, paint(el) {
  const st = cur('status');
  el.innerHTML = `<div class="glass card"><h2>هسته مرکزی سیستم</h2>
  <p class="note" style="margin-top:0">همهٔ ماژول‌ها زیر نظر Governor و لایهٔ امتیازدهی یکپارچه کار می‌کنند: فنی · x10 · x11 · x12 · بافت · شواهد · آمادگی · سیاست معامله.</p>
  <div class="kv c3">${kv('نسخه', N(esc(g(st, 'version', '—'))))}${kv('ارزها', N((g(st, 'symbols', []) || []).length))}${kv('آخرین اسکن', st && st.last_scan ? esc(ago(st.last_scan)) : '—')}</div>
  <div class="sh">مسیرهای فعال</div>
  <div class="chips">
    <button class="btn s o" data-go="ana:gov">حاکم</button>
    <button class="btn s o" data-go="ana:x10">x10</button>
    <button class="btn s o" data-go="ana:x11">x11</button>
    <button class="btn s o" data-go="ana:x12">x12</button>
    <button class="btn s o" data-go="ana:sig">سیگنال</button>
    <button class="btn s o" data-go="lab:pro">اجزا PRO</button>
    <button class="btn s o" data-go="ai:ready">آمادگی</button>
    <button class="btn s o" data-go="ana:ev">شواهد</button>
    <button class="btn s o" data-go="ex:pol">سیاست</button>
    <button class="btn s o" data-go="more:sys">سیستم</button>
  </div></div>
  <div class="glass card"><h2>چیدمان داشبورد</h2><p class="note" style="margin-top:0">از «بیشتر → چیدمان» ترتیب، نمایش و اندازهٔ هر ویجت را عوض کنید. ویجت «هسته مرکزی» را بالای لیست بگذارید تا همیشه در دید باشد.</p>
  <div class="acts"><button class="btn" data-go="more:dash">تنظیم چیدمان</button><button class="btn o" data-go="more:look">ظاهر و تم</button></div></div>`;
} };

})();
