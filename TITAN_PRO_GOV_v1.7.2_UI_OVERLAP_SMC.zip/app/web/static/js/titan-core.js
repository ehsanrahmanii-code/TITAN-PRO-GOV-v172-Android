/* TITAN AI — core: helpers, preferences, data layer, router state, sheets. Shared through window.T */
(function () {
'use strict';
const T = window.T = { V: {}, ST: { tab: 'dash', sub: {}, cx: -1 } };
const $ = T.$ = (q, e) => (e || document).querySelector(q);
T.$$ = (q, e) => Array.from((e || document).querySelectorAll(q));
T.esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
T.g = (o, p, d) => { try { let v = o; for (const k of p.split('.')) { if (v == null) return d; v = v[k]; } return v == null ? d : v; } catch (e) { return d; } };
const num = T.num = v => typeof v === 'number' && isFinite(v);
const store = T.store = { get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }, set(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* private mode */ } } };
/* ── format ── */
const fmt = T.fmt = (v, d = 2) => num(v) ? v.toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d }) : '—';
T.fp = v => { if (!num(v)) return '—'; const a = Math.abs(v); return fmt(v, a >= 100 ? 2 : a >= 1 ? 4 : a >= .01 ? 5 : 8); };
const sg = T.sg = (v, d = 2) => num(v) ? (v >= 0 ? '+' : '') + v.toFixed(d) : '—';
T.pc = v => num(v) ? sg(v) + '٪' : '—';
T.usd = v => num(v) ? (v < 0 ? '-$' : '$') + fmt(Math.abs(v), 2) : '—';
T.p100 = v => !num(v) ? null : (Math.abs(v) <= 1 ? v * 100 : v);
const N = T.N = (s, c) => `<span class="n ${c || ''}">${s}</span>`;
T.cls = s => s === 'LONG' ? 'up' : s === 'SHORT' ? 'dn' : 'am';
T.FA = { LONG: 'خرید', SHORT: 'فروش', WAIT: 'صبر' };
T.tag = s => `<span class="tag ${T.esc(s)}">${T.FA[s] || T.esc(s)}</span>`;
T.ago = t => { const s = Math.max(0, Date.now() / 1000 - t); return s < 90 ? 'لحظاتی پیش' : s < 5400 ? Math.round(s / 60) + ' دقیقه پیش' : s < 129600 ? Math.round(s / 3600) + ' ساعت پیش' : Math.round(s / 86400) + ' روز پیش'; };
const COIN = { BTC: ['#f7931a', '₿'], ETH: ['#627eea', '◆'], SOL: ['linear-gradient(135deg,#9945ff,#14f195)', '≡'], XRP: ['#23292f', '✕'], BNB: ['#f3ba2f', '◈'], DOGE: ['#c2a633', 'Ð'], TRX: ['#eb0029', 'T'], ADA: ['#0033ad', '₳'] };
T.coin = (b, z) => { let c = COIN[b]; if (!c) { let h = 0; for (const ch of b) h = (h * 31 + ch.charCodeAt(0)) % 360; c = [`hsl(${h} 60% 42%)`, b[0] || '?']; } return `<span class="coin" style="background:${c[0]};${z ? `width:${z}px;height:${z}px;font-size:${Math.round(z * .43)}px` : ''}">${T.esc(c[1])}</span>`; };
T.kv = (l, v, c) => `<div>${l}<b class="${c || ''}">${v}</b></div>`;
T.bar = (p, c, mid) => `<div class="bar ${mid ? 'mid' : ''}"><i class="${c || ''}" style="width:${Math.max(0, Math.min(100, p || 0))}%"></i></div>`;
T.empty = m => `<div class="empty">${m}</div>`;
T.loading = '<div class="empty"><span class="spin"></span>در حال دریافت…</div>';
T.noData = (d, k) => !d ? T.loading : (d.error ? `<div class="empty err">${T.esc(d.error)}</div>` : (k && !T.g(d, k) ? T.empty('داده‌ای نیست') : ''));
/* ── icons ── */
const IC = T.IC = {
  home: '<path d="M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10"/>', mk: '<path d="M5 20V10M12 20V4M19 20v-7"/><rect x="3" y="12" width="4" height="5"/><rect x="10" y="7" width="4" height="7"/><rect x="17" y="14" width="4" height="4"/>',
  an: '<path d="M9 4a3 3 0 00-3 3 3 3 0 00-2 5 3 3 0 002 5 3 3 0 006 0V4a3 3 0 00-3 0zM15 4a3 3 0 013 3 3 3 0 012 5 3 3 0 01-2 5 3 3 0 01-6 0"/>',
  ai: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/><rect x="10" y="10" width="4" height="4"/>',
  ex: '<rect x="3" y="6" width="18" height="13" rx="2"/><path d="M3 10h18M16 15h2"/>', more: '<rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', bars: '<path d="M4 20h16"/><rect x="5" y="12" width="3" height="8"/><rect x="10.5" y="7" width="3" height="13"/><rect x="16" y="3" width="3" height="17"/>',
  cup: '<path d="M7 4h10v5a5 5 0 01-10 0zM7 6H3v2a4 4 0 004 4M17 6h4v2a4 4 0 01-4 4M12 14v4M8 21h8"/>', ind: '<path d="M4 20V10M10 20V4M16 20v-8M22 20H2"/><path d="M3 8l6-4 6 6 6-6"/>',
  exp: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>', lab: '<path d="M9 3h6M10 3v6l-5 9a2 2 0 002 3h10a2 2 0 002-3l-5-9V3"/><path d="M8 15h8"/>', scan: '<path d="M20 12a8 8 0 11-2.3-5.6M20 4v5h-5"/>'
};
T.ic = n => `<svg viewBox="0 0 24 24">${IC[n] || ''}</svg>`;
/* ── preferences (live theming) ── */
const ACC = {
  gold: { n: 'طلایی', acc: '#ffc928', acc2: '#ff9d00', pri1: '#1d62ff', pri2: '#0a39c8', ring1: '#7fe0ff', ring2: '#2d6bff', fut: '#b66bff' },
  cyan: { n: 'فیروزه‌ای', acc: '#5ef0ff', acc2: '#22b8ff', pri1: '#0a8bd6', pri2: '#07508f', ring1: '#8af5ff', ring2: '#1fa3ff', fut: '#ffd34a' },
  violet: { n: 'بنفش', acc: '#c79bff', acc2: '#8f5cff', pri1: '#7c3aed', pri2: '#4c1d95', ring1: '#d2b4ff', ring2: '#8b5cf6', fut: '#5ef0ff' },
  green: { n: 'زمردی', acc: '#6dffb0', acc2: '#19c37d', pri1: '#0f9d6b', pri2: '#065f46', ring1: '#9dffd0', ring2: '#10b981', fut: '#ffd34a' },
  rose: { n: 'صورتی', acc: '#ff8fc7', acc2: '#ff4d9a', pri1: '#d6246f', pri2: '#7a0f3f', ring1: '#ffb6dc', ring2: '#ff4d9a', fut: '#5ef0ff' },
  orange: { n: 'نارنجی', acc: '#ffa24d', acc2: '#ff6a00', pri1: '#e8590c', pri2: '#8a2f00', ring1: '#ffc58f', ring2: '#ff7a1a', fut: '#5ef0ff' },
  red: { n: 'قرمز', acc: '#ff6b7a', acc2: '#ff2e47', pri1: '#d6192f', pri2: '#7a0b19', ring1: '#ff9aa6', ring2: '#ff3b55', fut: '#ffd34a' },
  lime: { n: 'لیمویی', acc: '#d4ff4d', acc2: '#9be000', pri1: '#6fa800', pri2: '#3a5a00', ring1: '#e6ff8a', ring2: '#8fd400', fut: '#b66bff' },
  sky: { n: 'آسمانی', acc: '#8fd0ff', acc2: '#3d9bff', pri1: '#2563eb', pri2: '#1e3a8a', ring1: '#bfe3ff', ring2: '#3b82f6', fut: '#ffd34a' },
  mint: { n: 'نعنایی', acc: '#9bf6e1', acc2: '#2dd4bf', pri1: '#0d9488', pri2: '#134e4a', ring1: '#c4fbef', ring2: '#14b8a6', fut: '#ff9de2' },
  magenta: { n: 'سرخابی', acc: '#ff7ae0', acc2: '#d946ef', pri1: '#a21caf', pri2: '#581c87', ring1: '#ffb3f0', ring2: '#c026d3', fut: '#5ef0ff' },
  silver: { n: 'نقره‌ای', acc: '#dfe6f5', acc2: '#9aa8c7', pri1: '#475a85', pri2: '#27324f', ring1: '#f1f5ff', ring2: '#7385b3', fut: '#ffc928' }
};
const CND = {
  gr: ['#21e65a', '#ff3b4e', 'سبز / قرمز'], bo: ['#2d9cff', '#ffa31a', 'آبی / نارنجی'], mono: ['#e6eeff', '#5d6a8a', 'تک‌رنگ'], tv: ['#26a69a', '#ef5350', 'تریدینگ‌ویو'],
  cb: ['#3b9cff', '#ffb000', 'کم‌رنگ‌بینی'], ym: ['#ffd34a', '#b66bff', 'زرد / بنفش'], neon: ['#00ffc8', '#ff2bd6', 'نئون'], custom: ['#21e65a', '#ff3b4e', 'سفارشی']
};
/* Full surface themes. Each sets the background / card / text / border palette; the accent colour is independent (12 x 12 combinations). */
const THEMES = {
  midnight: { n: 'نیمه‌شب', bg: '#02040d', card: '#050b24', card2: '#08133a', tx: '#f2f6ff', mu: '#9db0d6', mu2: '#62729a', bgTop: '#030617', bgBot: '#040a1e', line: '#20408c', line2: '#2a52b8', line3: '#3b5ad0', btn1: '#0a1430', btn2: '#050a1d', track: '#0a1330', fill: 'rgba(20,50,130,.26)', div: 'rgba(80,130,255,.18)', inp: 'rgba(3,8,28,.9)', cbg1: '#040a22', cbg2: '#02040f', subbg: 'rgba(2,4,13,.95)', tint1: 'rgba(40,110,255,.32)', tint2: 'rgba(30,60,200,.16)', g1: '#4aa8ff', g2: '#0b2a7a', gsh: 'rgba(60,140,255,.7)' },
  amoled: { n: 'آمولد (مشکی)', bg: '#000000', card: '#0b0b0f', card2: '#14141c', tx: '#f4f4f8', mu: '#a3a3b3', mu2: '#6a6a7a', bgTop: '#000000', bgBot: '#000000', line: '#2a2a38', line2: '#3a3a4c', line3: '#4c4c62', btn1: '#12121a', btn2: '#08080c', track: '#101018', fill: 'rgba(255,255,255,.05)', div: 'rgba(255,255,255,.1)', inp: 'rgba(8,8,12,.95)', cbg1: '#050508', cbg2: '#000000', subbg: 'rgba(0,0,0,.95)', tint1: 'rgba(120,120,160,.18)', tint2: 'rgba(80,80,120,.1)', g1: '#7a7a9a', g2: '#2a2a3a', gsh: 'rgba(150,150,200,.4)' },
  ocean: { n: 'اقیانوس', bg: '#02121a', card: '#04202c', card2: '#073345', tx: '#eafaff', mu: '#8fc3d4', mu2: '#5a8a9a', bgTop: '#021822', bgBot: '#021016', line: '#14556e', line2: '#1b7494', line3: '#2a93b8', btn1: '#073040', btn2: '#04202c', track: '#05222f', fill: 'rgba(20,120,160,.24)', div: 'rgba(60,170,210,.2)', inp: 'rgba(2,20,28,.92)', cbg1: '#031a24', cbg2: '#020f15', subbg: 'rgba(2,16,22,.95)', tint1: 'rgba(30,170,210,.3)', tint2: 'rgba(20,110,150,.16)', g1: '#4fe0e8', g2: '#0a5a78', gsh: 'rgba(60,210,230,.6)' },
  emerald: { n: 'جنگل زمردی', bg: '#02100a', card: '#04201a', card2: '#073228', tx: '#eafff5', mu: '#92c9b0', mu2: '#5b8c78', bgTop: '#03160e', bgBot: '#020e08', line: '#155e44', line2: '#1d7c5a', line3: '#2a9c74', btn1: '#06301f', btn2: '#041f15', track: '#052217', fill: 'rgba(20,140,90,.22)', div: 'rgba(70,200,140,.18)', inp: 'rgba(2,20,12,.92)', cbg1: '#031a10', cbg2: '#020e08', subbg: 'rgba(2,14,8,.95)', tint1: 'rgba(30,200,120,.26)', tint2: 'rgba(20,130,80,.15)', g1: '#5ef0a8', g2: '#0a6a40', gsh: 'rgba(60,230,150,.55)' },
  crimson: { n: 'ارغوانی تیره', bg: '#0d0206', card: '#240810', card2: '#3a0d1a', tx: '#fff0f3', mu: '#d1a0ab', mu2: '#8c5a66', bgTop: '#14030a', bgBot: '#0a0205', line: '#6e1a2e', line2: '#92233c', line3: '#b83150', btn1: '#2e0b16', btn2: '#1c060d', track: '#240812', fill: 'rgba(200,30,70,.2)', div: 'rgba(230,80,110,.2)', inp: 'rgba(20,4,10,.92)', cbg1: '#1a050c', cbg2: '#0d0206', subbg: 'rgba(12,2,6,.95)', tint1: 'rgba(230,40,80,.28)', tint2: 'rgba(160,20,50,.16)', g1: '#ff7a92', g2: '#7a0f28', gsh: 'rgba(255,70,100,.6)' },
  royal: { n: 'سلطنتی بنفش', bg: '#08031a', card: '#150a38', card2: '#221058', tx: '#f5f0ff', mu: '#b9a8e6', mu2: '#7a68a8', bgTop: '#0c0424', bgBot: '#06021a', line: '#3f2a94', line2: '#5237bd', line3: '#7050e0', btn1: '#1a0e48', btn2: '#0f0730', track: '#140a34', fill: 'rgba(100,60,230,.22)', div: 'rgba(150,110,255,.2)', inp: 'rgba(10,4,30,.92)', cbg1: '#0d0626', cbg2: '#060214', subbg: 'rgba(6,2,18,.95)', tint1: 'rgba(130,80,255,.3)', tint2: 'rgba(90,50,200,.16)', g1: '#b58aff', g2: '#3a1c9a', gsh: 'rgba(160,110,255,.6)' },
  sunset: { n: 'غروب', bg: '#120804', card: '#2a1308', card2: '#40200c', tx: '#fff5ea', mu: '#d9b394', mu2: '#94725a', bgTop: '#1a0b05', bgBot: '#0e0603', line: '#7a3d12', line2: '#a2501a', line3: '#cc6a26', btn1: '#341808', btn2: '#220f05', track: '#2a1308', fill: 'rgba(230,120,30,.2)', div: 'rgba(255,160,80,.2)', inp: 'rgba(22,10,4,.92)', cbg1: '#1c0d05', cbg2: '#0e0603', subbg: 'rgba(14,6,2,.95)', tint1: 'rgba(255,130,40,.28)', tint2: 'rgba(200,80,20,.15)', g1: '#ffb36b', g2: '#8a3a08', gsh: 'rgba(255,150,70,.6)' },
  cyber: { n: 'سایبرپانک', bg: '#06020f', card: '#120628', card2: '#1c0a40', tx: '#f4eeff', mu: '#b8a0e0', mu2: '#7a60a8', bgTop: '#0a0318', bgBot: '#04010a', line: '#5b1f94', line2: '#7c2cc4', line3: '#e02bd0', btn1: '#180a36', btn2: '#0d0520', track: '#100628', fill: 'rgba(224,43,208,.14)', div: 'rgba(0,255,220,.16)', inp: 'rgba(8,3,20,.92)', cbg1: '#0b0418', cbg2: '#050210', subbg: 'rgba(5,2,12,.95)', tint1: 'rgba(224,43,208,.26)', tint2: 'rgba(0,220,255,.14)', g1: '#00f0ff', g2: '#5a1aa0', gsh: 'rgba(0,240,255,.55)' },
  slate: { n: 'اسلیت خاکستری', bg: '#0b0e14', card: '#151a24', card2: '#1e2533', tx: '#eef2f8', mu: '#a1acc0', mu2: '#6b778c', bgTop: '#0e121a', bgBot: '#080a10', line: '#2f3b52', line2: '#3f4f6e', line3: '#566a92', btn1: '#1a2130', btn2: '#10151f', track: '#131925', fill: 'rgba(120,140,190,.14)', div: 'rgba(150,170,210,.16)', inp: 'rgba(10,13,20,.92)', cbg1: '#0e121a', cbg2: '#080a10', subbg: 'rgba(8,10,16,.95)', tint1: 'rgba(100,130,200,.22)', tint2: 'rgba(80,100,160,.12)', g1: '#8fa8d8', g2: '#2c3a5a', gsh: 'rgba(130,160,220,.45)' },
  mocha: { n: 'موکا (قهوه‌ای)', bg: '#0f0a07', card: '#221711', card2: '#33231a', tx: '#fbf3ec', mu: '#c9b3a2', mu2: '#8a7565', bgTop: '#150e09', bgBot: '#0a0705', line: '#5a3d2a', line2: '#7a5238', line3: '#9c6c4a', btn1: '#2a1c13', btn2: '#1a110b', track: '#201510', fill: 'rgba(190,130,80,.16)', div: 'rgba(220,170,120,.18)', inp: 'rgba(16,10,7,.92)', cbg1: '#150e09', cbg2: '#0a0705', subbg: 'rgba(10,7,5,.95)', tint1: 'rgba(220,150,90,.24)', tint2: 'rgba(160,100,60,.13)', g1: '#e8b88a', g2: '#6a4226', gsh: 'rgba(230,170,110,.5)' },
  nord: { n: 'نورد (یخی)', bg: '#1a1f2b', card: '#242b3a', card2: '#2e3748', tx: '#eceff4', mu: '#a9b4c8', mu2: '#74809a', bgTop: '#1e2432', bgBot: '#151a24', line: '#3d4a63', line2: '#4c5c7a', line3: '#6a7ea4', btn1: '#2a3244', btn2: '#1f2634', track: '#222938', fill: 'rgba(136,192,208,.13)', div: 'rgba(136,192,208,.16)', inp: 'rgba(22,27,38,.92)', cbg1: '#1e2432', cbg2: '#151a24', subbg: 'rgba(20,25,34,.95)', tint1: 'rgba(136,192,208,.22)', tint2: 'rgba(94,129,172,.14)', g1: '#88c0d0', g2: '#3b4f6e', gsh: 'rgba(136,192,208,.5)' },
  graphite: { n: 'گرافیتی گرم', bg: '#0d0d0d', card: '#1a1a1a', card2: '#262626', tx: '#f5f5f5', mu: '#b0b0b0', mu2: '#707070', bgTop: '#111111', bgBot: '#080808', line: '#3a3a3a', line2: '#4d4d4d', line3: '#666666', btn1: '#202020', btn2: '#141414', track: '#171717', fill: 'rgba(255,255,255,.06)', div: 'rgba(255,255,255,.1)', inp: 'rgba(12,12,12,.95)', cbg1: '#101010', cbg2: '#080808', subbg: 'rgba(8,8,8,.95)', tint1: 'rgba(200,200,200,.12)', tint2: 'rgba(150,150,150,.08)', g1: '#bdbdbd', g2: '#3a3a3a', gsh: 'rgba(200,200,200,.35)' },
  light: { n: 'روز (روشن)', light: 1, bg: '#eef2fa', card: '#ffffff', card2: '#f3f6fd', tx: '#0e1730', mu: '#51607f', mu2: '#8793ae', bgTop: '#f6f8fe', bgBot: '#e6ecf8', line: '#cdd7ee', line2: '#b6c4e6', line3: '#93a6d6', btn1: '#ffffff', btn2: '#eef2fb', track: '#e3e9f6', fill: 'rgba(60,100,200,.07)', div: 'rgba(60,90,160,.14)', inp: 'rgba(255,255,255,.95)', cbg1: '#ffffff', cbg2: '#f4f7fd', subbg: 'rgba(238,242,250,.96)', tint1: 'rgba(80,130,255,.18)', tint2: 'rgba(80,130,255,.08)', g1: '#7fb2ff', g2: '#3a63c8', gsh: 'rgba(80,130,255,.3)' }
};
/* theme factory: derives the complete variable set from a few base colours, so a new theme is one line */
const hx = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16));
const mix = (a, b, t) => '#' + hx(a).map((v, i) => Math.round(v + (hx(b)[i] - v) * t).toString(16).padStart(2, '0')).join('');
const rgbaH = (h, a) => `rgba(${hx(h).join(',')},${a})`;
function mkTheme(n, o) {
  const L = !!o.light, bg = o.bg, card = o.card, card2 = o.card2 || mix(card, L ? '#000000' : '#ffffff', .07), tx = o.tx, g1 = o.g1, g2 = o.g2 || g1, line = o.line || mix(card, g1, .3);
  const t = { n, bg, card, card2, tx, mu: o.mu || mix(tx, bg, .4), mu2: o.mu2 || mix(tx, bg, .62), bgTop: mix(bg, card, .35), bgBot: mix(bg, L ? '#ffffff' : '#000000', .3), line, line2: mix(line, g1, .25), line3: mix(line, g1, .5),
    btn1: mix(card, card2, .5), btn2: mix(card, bg, .5), track: mix(card, bg, .4), fill: rgbaH(g1, L ? .08 : .14), div: rgbaH(g1, L ? .16 : .18), inp: rgbaH(mix(bg, card, .25), .92), cbg1: mix(card, bg, .3), cbg2: bg,
    subbg: rgbaH(bg, .95), tint1: rgbaH(g1, L ? .2 : .26), tint2: rgbaH(g2, L ? .1 : .14), g1, g2: mix(g2, bg, L ? .1 : .6), gsh: rgbaH(g1, L ? .3 : .55) };
  if (L) t.light = 1; return t;
}
Object.assign(THEMES, {
  obsidian: mkTheme('ابسیدین', { bg: '#07080a', card: '#11141a', tx: '#eceff4', g1: '#7aa2ff' }),
  carbon: mkTheme('کربن قرمز', { bg: '#0b0b0d', card: '#17171a', tx: '#f0f0f2', g1: '#ff3b4e' }),
  steel: mkTheme('فولاد', { bg: '#0c1117', card: '#18212b', tx: '#e8eef5', g1: '#8fb4d9' }),
  terminal: mkTheme('ترمینال سبز', { bg: '#020a04', card: '#07160b', tx: '#c8ffd4', g1: '#2cff6a' }),
  bloomberg: mkTheme('ترمینال کهربایی', { bg: '#0a0600', card: '#1a1100', tx: '#ffe9b8', g1: '#ffa31a' }),
  deepsea: mkTheme('اعماق دریا', { bg: '#00101c', card: '#021f33', tx: '#dff6ff', g1: '#3fd0ff' }),
  polar: mkTheme('شفق قطبی', { bg: '#04101a', card: '#0a2230', tx: '#e6fffa', g1: '#5effc8', g2: '#7a5cff' }),
  rose: mkTheme('گل رز', { bg: '#14060d', card: '#2a0d1a', tx: '#ffeef4', g1: '#ff6fa5' }),
  desert: mkTheme('کویر', { bg: '#160f06', card: '#2b1d0c', tx: '#fff0d6', g1: '#e8a24a' }),
  volcano: mkTheme('آتشفشان', { bg: '#130503', card: '#2a0d08', tx: '#ffece6', g1: '#ff5a36' }),
  neonviolet: mkTheme('بنفش نئونی', { bg: '#0a0214', card: '#1a0630', tx: '#f3e8ff', g1: '#c45cff', g2: '#00e5ff' }),
  sakura: mkTheme('ساکورا (روشن)', { light: 1, bg: '#fdf2f6', card: '#ffffff', tx: '#3a1624', g1: '#e0558c' }),
  arctic: mkTheme('قطب (روشن)', { light: 1, bg: '#eef7fb', card: '#ffffff', tx: '#0b2a3a', g1: '#1b8fc0' }),
  sand: mkTheme('ماسه (روشن)', { light: 1, bg: '#f7f1e6', card: '#fffdf8', tx: '#3b2f1a', g1: '#c0832b' }),
  mint: mkTheme('نعنا (روشن)', { light: 1, bg: '#eefaf3', card: '#ffffff', tx: '#0f3322', g1: '#1faa6b' }),
  lavender: mkTheme('اسطوخودوس (روشن)', { light: 1, bg: '#f3f0fc', card: '#ffffff', tx: '#241a4a', g1: '#7a5ce0' })
});
Object.assign(ACC, {
  rose: { n: 'صورتی', acc: '#ff6fa5', acc2: '#ff3d87', pri1: '#c2185b', pri2: '#7b0f3a', ring1: '#ffa6c9', ring2: '#ff4d94', fut: '#5ef0ff' },
  lime: { n: 'لیمویی', acc: '#c6ff3d', acc2: '#8be000', pri1: '#4c9a00', pri2: '#2a5a00', ring1: '#e3ff8a', ring2: '#9be52a', fut: '#ff7ad9' },
  coral: { n: 'مرجانی', acc: '#ff8a65', acc2: '#ff5a36', pri1: '#c2410c', pri2: '#7c2d12', ring1: '#ffb59d', ring2: '#ff6b45', fut: '#5eead4' },
  ice: { n: 'یخی', acc: '#bfe9ff', acc2: '#7cc8f0', pri1: '#2b7fb5', pri2: '#174f73', ring1: '#e0f5ff', ring2: '#5fb8e8', fut: '#ffc928' },
  mint: { n: 'نعنایی', acc: '#5effc8', acc2: '#19d9a0', pri1: '#0a9972', pri2: '#066248', ring1: '#a6ffe3', ring2: '#2be3ad', fut: '#ff8a65' },
  amber: { n: 'کهربایی', acc: '#ffb300', acc2: '#ff8f00', pri1: '#b45309', pri2: '#78350f', ring1: '#ffd36b', ring2: '#ffa11a', fut: '#7aa2ff' },
  violet: { n: 'ارغوانی روشن', acc: '#c9a4ff', acc2: '#a370ff', pri1: '#6d3fd6', pri2: '#40208f', ring1: '#e2cfff', ring2: '#9c6bff', fut: '#ffd34a' },
  white: { n: 'سفید درخشان', acc: '#ffffff', acc2: '#d6e4ff', pri1: '#5b7bd6', pri2: '#2a3f8f', ring1: '#ffffff', ring2: '#a9c0ff', fut: '#ffc928' }
});
const FONTS = {
  vazir: ['پیش‌فرض', '"Vazirmatn","Segoe UI",system-ui,-apple-system,Tahoma,sans-serif'], tahoma: ['تاهوما', 'Tahoma,"Segoe UI",system-ui,sans-serif'],
  serif: ['سریف', '"Noto Naskh Arabic","Times New Roman",Georgia,serif'], mono: ['تک‌فاصله', 'ui-monospace,"SFMono-Regular",Menlo,Consolas,monospace'],
  round: ['گرد', 'ui-rounded,"Nunito","Segoe UI",system-ui,sans-serif'], sys: ['سیستم', 'system-ui,-apple-system,"Segoe UI",Roboto,sans-serif']
};

Object.assign(THEMES, {
  cyberpunk: { n: 'سایبرپانک', bg: '#0a0014', card: '#1a0030', card2: '#2a0848', tx: '#f0e6ff', mu: '#b89ad4', mu2: '#7a5a9a', bgTop: '#120028', bgBot: '#060010', line: '#6b2db5', line2: '#8b3fd9', line3: '#a855f7', btn1: '#1e0840', btn2: '#120028', track: '#1a0030', fill: 'rgba(168,85,247,.2)', div: 'rgba(192,132,252,.2)', inp: 'rgba(10,0,20,.95)', cbg1: '#120028', cbg2: '#060010', subbg: 'rgba(6,0,16,.95)', tint1: 'rgba(168,85,247,.35)', tint2: 'rgba(236,72,153,.18)', g1: '#e879f9', g2: '#6b21a8', gsh: 'rgba(232,121,249,.55)' },
  desert: { n: 'کویر طلایی', bg: '#1a1208', card: '#2a1c0c', card2: '#3d2a12', tx: '#fff8e7', mu: '#d4b896', mu2: '#9a7a50', bgTop: '#24180c', bgBot: '#120c06', line: '#8a5a20', line2: '#b07830', line3: '#d4a040', btn1: '#3a2410', btn2: '#1e1408', track: '#2a1c0c', fill: 'rgba(212,160,64,.18)', div: 'rgba(212,160,64,.22)', inp: 'rgba(20,12,4,.95)', cbg1: '#1e1408', cbg2: '#120c06', subbg: 'rgba(18,12,6,.95)', tint1: 'rgba(255,180,60,.28)', tint2: 'rgba(180,100,20,.14)', g1: '#ffc040', g2: '#8a5010', gsh: 'rgba(255,180,40,.5)' },
  ice: { n: 'یخ قطبی', bg: '#e8f4fc', card: '#ffffff', card2: '#f0f7fc', tx: '#0a1a2a', mu: '#4a6a82', mu2: '#7a9ab0', bgTop: '#d8eefc', bgBot: '#f5fafd', line: '#90b8d0', line2: '#6a9ab8', line3: '#4a7a98', btn1: '#e0eef8', btn2: '#f0f7fc', track: '#d0e4f0', fill: 'rgba(40,120,180,.08)', div: 'rgba(40,100,150,.12)', inp: 'rgba(255,255,255,.95)', cbg1: '#eef6fb', cbg2: '#f8fbfd', subbg: 'rgba(240,247,252,.95)', tint1: 'rgba(80,160,220,.2)', tint2: 'rgba(40,120,180,.1)', g1: '#5ab0e0', g2: '#1a5080', gsh: 'rgba(80,160,220,.35)', light: 1 },
  matrix: { n: 'ماتریکس', bg: '#020a02', card: '#041404', card2: '#0a220a', tx: '#b8ffb8', mu: '#5aaa5a', mu2: '#3a7a3a', bgTop: '#031003', bgBot: '#010601', line: '#1a6a1a', line2: '#28a028', line3: '#40d040', btn1: '#0a1e0a', btn2: '#041004', track: '#0a1a0a', fill: 'rgba(40,200,40,.12)', div: 'rgba(60,220,60,.18)', inp: 'rgba(2,10,2,.95)', cbg1: '#041404', cbg2: '#020a02', subbg: 'rgba(2,10,2,.95)', tint1: 'rgba(40,255,40,.2)', tint2: 'rgba(20,150,20,.12)', g1: '#60ff60', g2: '#0a5a0a', gsh: 'rgba(60,255,60,.45)' },
  royal: { n: 'سلطنتی', bg: '#0c0818', card: '#1a1230', card2: '#2a1c48', tx: '#f5eef8', mu: '#c0a0d0', mu2: '#806090', bgTop: '#140c28', bgBot: '#080510', line: '#6a4090', line2: '#8a58b8', line3: '#a878d8', btn1: '#221838', btn2: '#140c24', track: '#1a1230', fill: 'rgba(160,80,220,.16)', div: 'rgba(180,100,240,.2)', inp: 'rgba(12,8,24,.95)', cbg1: '#160e28', cbg2: '#0c0818', subbg: 'rgba(8,5,16,.95)', tint1: 'rgba(180,100,255,.28)', tint2: 'rgba(255,200,80,.12)', g1: '#d4a0ff', g2: '#5a2080', gsh: 'rgba(200,120,255,.5)' }
});

T.THEMES = THEMES; T.FONTS = FONTS;
T.TEMPLATES = {
  pro: { n: 'ترمینال حرفه‌ای', d: 'تیره، متراکم، دو ستونه', p: { theme: 'obsidian', accent: 'cyan', bg: 'carbonfib', card: 'solid', density: 'compact', font: 'sys', maxw: 1040, cols: 2, ring: 'thin', glow: 45, radius: 12 }, wp: 'decision' },
  neon: { n: 'نئون تریدر', d: 'درخشان و پرانرژی', p: { theme: 'neonviolet', accent: 'mint', bg: 'aurora', card: 'neon', density: 'normal', font: 'vazir', maxw: 760, cols: 1, ring: 'normal', glow: 100, radius: 22 }, wp: 'full' },
  clean: { n: 'روشن و تمیز', d: 'روز، کارت‌های نرم', p: { theme: 'arctic', accent: 'violet', bg: 'plain', card: 'soft', density: 'cozy', font: 'vazir', maxw: 760, cols: 1, ring: 'none', glow: 20, radius: 24 }, wp: 'simple' },
  amber: { n: 'ترمینال کهربایی', d: 'سبک تالار معاملات', p: { theme: 'bloomberg', accent: 'amber', bg: 'scan', card: 'outline', density: 'compact', font: 'mono', maxw: 1040, cols: 2, ring: 'thin', glow: 55, radius: 8 }, wp: 'trader' },
  focus: { n: 'تمرکز مینیمال', d: 'بدون حاشیه، فقط تصمیم', p: { theme: 'amoled', accent: 'white', bg: 'plain', card: 'flat', density: 'cozy', font: 'vazir', maxw: 560, cols: 1, ring: 'none', glow: 0, radius: 18 }, wp: 'simple' },
  analyst: { n: 'تحلیل‌گر پهن', d: 'ویجت‌های تحلیلی در دو ستون', p: { theme: 'deepsea', accent: 'gold', bg: 'mesh', card: 'frost', density: 'normal', font: 'vazir', maxw: 1040, cols: 2, ring: 'thin', glow: 60, radius: 18 }, wp: 'analyst' },
  forward: { n: 'ارزیابی فوروارد', d: 'کارنامه، آمادگی و بافت بازار', p: { theme: 'slate', accent: 'lime', bg: 'dots', card: 'gradient', density: 'normal', font: 'vazir', maxw: 760, cols: 1, ring: 'thin', glow: 50, radius: 18 }, wp: 'evaluate' }
};
T.applyTemplate = function (k) {
  const t = T.TEMPLATES[k]; if (!t) return false; Object.assign(P, t.p); const wp = T.WPRESET[t.wp];
  if (wp) { P.hidden = wp.hidden.slice(); P.wsize = {}; } sane(); T.applyPrefs(); T.savePrefs && T.savePrefs(); return true;
};
T.ACC = ACC; T.CND = CND;
/* widget registry: id, Persian name, default size */
const WREG = [
  ['hero', 'نمای اصلی قیمت و سیگنال', 'full'], ['chart', 'نمودار زنده + کندل آینده', 'full'], ['stats', 'روند / امتیاز AI / نرخ برد', 'full'], ['sigcard', 'جزئیات کامل سیگنال', 'full'],
  ['core', 'هسته مرکزی تصمیم (Governor)', 'full'],
  ['lab', 'نتیجهٔ تحلیل عمیق ارز', 'full'], ['mtf', 'چندتایم‌فریم', 'half'], ['x10', '۱۰ شاخص تکمیلی x10', 'full'], ['x12', '۱۰ شاخص تکمیلی x12', 'full'], ['x11', 'ساختار و مشارکت x11', 'half'],
  ['top', 'برترین سیگنال‌ها', 'full'], ['coins', 'کارت ارزها', 'full'],
  ['levels', 'سطوح کلیدی', 'half'], ['fcast', 'پیش‌بینی و لبهٔ آماری', 'half'], ['flow', 'جریان پول و ریزساختار', 'half'], ['pats', 'الگوها', 'half'],
  ['acct', 'صرافی و ترید خودکار', 'full'], ['pos', 'موقعیت‌های باز', 'half'], ['perf', 'عملکرد و نرخ برد', 'half'], ['autolog', 'گزارش ترید خودکار', 'half'],
  ['mood', 'حال بازار', 'half'], ['movers', 'پرسودها / پرضررها', 'half'], ['heat', 'نقشهٔ حرارتی', 'full'], ['alerts', 'هشدارها', 'half'], ['track', 'کارنامه سیگنال‌ها', 'half'],
  ['ctx', 'بافت بازار (فاندینگ · OI · دفتر سفارش · احساسات)', 'full'], ['ready', 'ارزیابی فوروارد و آمادگی معامله', 'half'],
  ['gov', 'حاکم و وتو', 'full'], ['learn', 'یادگیری حاکم', 'half'], ['evd', 'شواهد و بک‌تست', 'half'],
  ['sys', 'وضعیت سیستم و منابع داده', 'half'], ['banner', 'بنر', 'full']
];
const WIDGETS = WREG.map(w => w[0]);
/* widget categories (shown as tags in the layout page; presets use them) */
const WCAT = { hero: 'بازار', chart: 'بازار', coins: 'بازار', top: 'بازار', mood: 'بازار', movers: 'بازار', heat: 'بازار', banner: 'بازار',
  stats: 'تصمیم', sigcard: 'تصمیم', lab: 'تصمیم', mtf: 'تصمیم', x10: 'تصمیم', x11: 'تصمیم', x12: 'تصمیم', levels: 'تصمیم', fcast: 'تصمیم', flow: 'تصمیم', pats: 'تصمیم', ctx: 'تصمیم', core: 'هسته', gov: 'هسته',
  acct: 'معامله', pos: 'معامله', autolog: 'معامله', alerts: 'معامله', perf: 'ارزیابی', track: 'ارزیابی', ready: 'ارزیابی', learn: 'ارزیابی', evd: 'ارزیابی', sys: 'سیستم' };
T.WCAT = WCAT;
T.WREG = WREG; T.WIDGETS = WIDGETS;
const WPRESET = {
  full: { n: 'کامل', hidden: [] },
  trader: { n: 'معامله‌گر', hidden: ['banner', 'mood', 'movers', 'heat', 'sys', 'track', 'pats', 'flow', 'levels', 'mtf', 'top', 'coins'] },
  analyst: { n: 'تحلیل‌گر', hidden: ['banner', 'acct', 'pos', 'perf', 'autolog', 'sys', 'stats', 'top'] },
  decision: { n: 'مرکز تصمیم', hidden: ['banner', 'mood', 'movers', 'heat', 'sys', 'acct', 'pos', 'autolog', 'alerts', 'coins', 'perf', 'track', 'ready', 'stats'] },
  evaluate: { n: 'ارزیابی و کارنامه', hidden: ['banner', 'mood', 'movers', 'heat', 'sigcard', 'lab', 'mtf', 'x10', 'levels', 'fcast', 'flow', 'pats', 'ctx', 'coins', 'top', 'chart', 'stats'] },
  simple: { n: 'ساده', hidden: ['banner', 'sigcard', 'lab', 'mtf', 'x10', 'levels', 'fcast', 'flow', 'pats', 'pos', 'perf', 'autolog', 'movers', 'heat', 'alerts', 'track', 'sys'] }
};
T.WPRESET = WPRESET;
const PD = {
  theme: 'midnight', accent: 'gold', glow: 85, blur: 10, radius: 16, fs: 14, fw: 400, font: 'vazir', density: 'compact', card: 'glass', ring: 'thin', bg: 'stars', maxw: 560, cols: 1,
  candle: 'gr', cup: '#21e65a', cdn: '#ff3b4e', ema: 1, vol: 1, fut: 1, band: 1, lvl: 1, grid: 1, fcN: 32, ctype: 'candle', ch: 300, vwap: 0, bb: 0, zones: 0, ez: 1, lr: 0, lastp: 1, tag: 1,
  tf: '1h', sel: 'BTCUSDT', tab: 'dash', anim: 1, refresh: 6, sound: 0, tbl: 1, brand: 1, hero: 1, banner: 1, tabs: 'labels',
  widgets: WIDGETS.slice(), hidden: [], wsize: {},
  /* v1.5 full personalization */
  pxfs: 165, secgap: 10, heroLayout: 'split', glassop: 88, bgImg: '', bgImgO: 35, heroImg: '', cardBg: '', sheetBg: '',
  customCss: '', pad: 10, gap: 8, brandSize: 26, showGlobe: 1, showBull: 1, headerCompact: 1
};
T.PD = PD;
let P = T.P = Object.assign({}, PD);
try { const raw = store.get('titan.prefs'); if (raw) Object.assign(P, JSON.parse(raw)); } catch (e) { /* corrupt prefs → defaults */ }
function sane() {
  const c = (v, a, b, d) => num(+v) ? Math.max(a, Math.min(b, +v)) : d, hex = (v, d) => /^#[0-9a-f]{6}$/i.test(String(v)) ? v : d;
  P.glow = c(P.glow, 0, 100, 100); P.blur = c(P.blur, 0, 30, 10); P.radius = c(P.radius, 4, 34, 20); P.fs = c(P.fs, 11, 22, 14); P.fcN = c(P.fcN, 6, 32, 32); P.fw = c(P.fw, 300, 700, 400);
  P.ch = c(P.ch, 200, 640, 320); P.refresh = c(P.refresh, 3, 60, 6); P.maxw = [560, 760, 1040].includes(+P.maxw) ? +P.maxw : 560; P.cols = +P.cols === 2 ? 2 : 1;
  P.cup = hex(P.cup, '#21e65a'); P.cdn = hex(P.cdn, '#ff3b4e');
  if (!ACC[P.accent]) P.accent = 'gold'; if (!CND[P.candle]) P.candle = 'gr'; if (!THEMES[P.theme]) P.theme = 'midnight'; if (!FONTS[P.font]) P.font = 'vazir';
  if (!['compact', 'normal', 'cozy', 'ultra'].includes(P.density)) P.density = 'compact'; if (!['glass', 'solid', 'outline', 'flat', 'neon', 'soft', 'gradient', 'frost'].includes(P.card)) P.card = 'glass';
  if (!['normal', 'thin', 'none'].includes(P.ring)) P.ring = 'normal'; if (!['stars', 'grid', 'aurora', 'grad', 'plain', 'mesh', 'dots', 'waves', 'radial', 'scan', 'carbonfib', 'image'].includes(P.bg)) P.bg = 'stars';
  if (!['candle', 'hollow', 'ohlc', 'line', 'area', 'heikin'].includes(P.ctype)) P.ctype = 'candle'; if (!['labels', 'icons'].includes(P.tabs)) P.tabs = 'labels';
  if (!['split', 'stack', 'signal'].includes(P.heroLayout)) P.heroLayout = 'split';
  P.pxfs = c(P.pxfs, 110, 240, 165); P.secgap = c(P.secgap, 0, 28, 10); P.glassop = c(P.glassop, 30, 100, 88);
  P.bgImgO = c(P.bgImgO, 0, 100, 35); P.pad = c(P.pad, 4, 28, 10); P.gap = c(P.gap, 2, 24, 8); P.brandSize = c(P.brandSize, 18, 40, 26);
  P.bgImg = typeof P.bgImg === 'string' ? P.bgImg : ''; P.heroImg = typeof P.heroImg === 'string' ? P.heroImg : '';
  P.cardBg = typeof P.cardBg === 'string' ? P.cardBg : ''; P.sheetBg = typeof P.sheetBg === 'string' ? P.sheetBg : '';
  P.customCss = typeof P.customCss === 'string' ? P.customCss.slice(0, 8000) : '';
  ['showGlobe', 'showBull', 'headerCompact'].forEach(k => { P[k] = P[k] ? 1 : 0; });
  if (!Array.isArray(P.widgets)) P.widgets = WIDGETS.slice(); P.widgets = P.widgets.filter((w, i, a) => WIDGETS.includes(w) && a.indexOf(w) === i); WIDGETS.forEach(w => { if (!P.widgets.includes(w)) P.widgets.push(w); });
  if (!Array.isArray(P.hidden)) P.hidden = []; P.hidden = P.hidden.filter(w => WIDGETS.includes(w));
  if (!P.wsize || typeof P.wsize !== 'object') P.wsize = {}; Object.keys(P.wsize).forEach(k => { if (!WIDGETS.includes(k) || !['full', 'half'].includes(P.wsize[k])) delete P.wsize[k]; });
  ['ema', 'vol', 'fut', 'band', 'lvl', 'grid', 'vwap', 'bb', 'zones', 'ez', 'lr', 'lastp', 'tag', 'anim', 'sound', 'brand', 'hero', 'banner', 'tbl', 'showGlobe', 'showBull', 'headerCompact'].forEach(k => { P[k] = P[k] ? 1 : 0; });
}
T.wsize = w => P.wsize[w] || (WREG.find(x => x[0] === w) || [0, 0, 'full'])[2];
T.applyPrefs = function () {
  sane(); const r = document.documentElement.style, a = ACC[P.accent], th = THEMES[P.theme], k = P.candle === 'custom' ? [P.cup, P.cdn] : CND[P.candle], b = document.body;
  ['acc', 'acc2', 'pri1', 'pri2', 'ring1', 'ring2'].forEach(x => r.setProperty('--' + x, a[x])); r.setProperty('--fut', a.fut);
  Object.keys(th).forEach(x => { if (x !== 'n' && x !== 'light') r.setProperty('--' + x, th[x]); });
  r.setProperty('--glow', P.glow / 100); r.setProperty('--blur', P.blur + 'px'); r.setProperty('--r', P.radius + 'px'); r.setProperty('--fs', P.fs + 'px'); r.setProperty('--fw', P.fw);
  r.setProperty('--cup', k[0]); r.setProperty('--cdn', k[1]); r.setProperty('--font', FONTS[P.font][1]); r.setProperty('--maxw', P.maxw + 'px'); r.setProperty('--ch', P.ch + 'px');
  r.setProperty('--pxfs', (P.pxfs / 100) + 'rem'); r.setProperty('--secgap', P.secgap + 'px'); r.setProperty('--glassop', P.glassop / 100);
  r.setProperty('--pad', P.pad + 'px'); r.setProperty('--gap', P.gap + 'px'); r.setProperty('--bgimgo', P.bgImgO / 100);
  if (P.bgImg) { r.setProperty('--bgimg', 'url("' + String(P.bgImg).replace(/"/g, '') + '")'); } else { r.setProperty('--bgimg', 'none'); }
  if (P.cardBg) { r.setProperty('--cardbg', P.cardBg); } else { r.setProperty('--cardbg', 'transparent'); }
  if (P.sheetBg) { r.setProperty('--sheetbg', P.sheetBg); } else { r.setProperty('--sheetbg', 'transparent'); }
  const meta = document.querySelector('meta[name=theme-color]'); if (meta) meta.setAttribute('content', th.bg);
  const dens = P.density === 'ultra' ? 'ultra' : P.density === 'compact' ? 'compact' : P.density === 'cozy' ? 'cozy' : '';
  b.className = b.className.split(/\s+/).filter(c => !/^(bg-|card-|ring-|tb-|cols2|light|noanim|compact|cozy|ultra|nobrand|nohero|nobanner|has-cardbg|has-sheetbg|bg-image|no-bull|no-globe|header-compact)/.test(c) && c).concat(['bg-' + (P.bgImg ? 'image' : P.bg), 'card-' + P.card, 'ring-' + P.ring]).join(' ');
  if (dens) b.classList.add(dens);
  b.classList.toggle('noanim', !P.anim); b.classList.toggle('light', !!th.light);
  b.classList.toggle('cols2', P.cols === 2); b.classList.toggle('nobrand', !P.brand); b.classList.toggle('nohero', !P.hero); b.classList.toggle('nobanner', !P.banner);
  b.classList.toggle('has-cardbg', !!P.cardBg); b.classList.toggle('has-sheetbg', !!P.sheetBg); b.classList.toggle('bg-image', !!P.bgImg);
  b.classList.toggle('no-bull', !P.showBull); b.classList.toggle('no-globe', !P.showGlobe); b.classList.toggle('header-compact', !!P.headerCompact);
  if (P.tabs === 'icons') b.classList.add('tb-icons');
  /* inject custom CSS */
  let st = document.getElementById('titan-custom-css');
  if (!st) { st = document.createElement('style'); st.id = 'titan-custom-css'; document.head.appendChild(st); }
  st.textContent = P.customCss || '';
  /* brand size live */
  const brandH = document.querySelector('.brand h1'); if (brandH) brandH.style.fontSize = P.brandSize + 'px';
};
let syncT = 0;
T.savePrefs = function () { store.set('titan.prefs', JSON.stringify(P)); clearTimeout(syncT); syncT = setTimeout(() => T.post('/api/settings', { ui: { skin: 'titan-ai', prefs: P } }), 900); };
T.setPref = (k, v) => { P[k] = v; T.applyPrefs(); T.savePrefs(); };
T.resetPrefs = (keys) => { if (keys) keys.forEach(k => { P[k] = JSON.parse(JSON.stringify(PD[k])); }); else { const sel = P.sel; Object.keys(P).forEach(k => delete P[k]); Object.assign(P, JSON.parse(JSON.stringify(PD)), { sel }); } T.applyPrefs(); T.savePrefs(); };
T.adoptServerPrefs = function (ui) { if (!store.get('titan.prefs') && ui && ui.prefs && typeof ui.prefs === 'object') { Object.assign(P, ui.prefs); T.applyPrefs(); store.set('titan.prefs', JSON.stringify(P)); return true; } return false; };
const ST = T.ST; ST.sel = P.sel; ST.tf = P.tf; ST.tab = P.tab;
const ATF = T.ATF = ['15m', '1h', '4h', '1d'], CTF = T.CTF = [['1m', '1m'], ['5m', '5m'], ['15m', '15m'], ['1h', '1h'], ['4h', '4h'], ['1d', '1D']];
if (!CTF.some(x => x[0] === ST.tf)) ST.tf = '1h';
T.atf = () => ATF.includes(ST.tf) ? ST.tf : '15m';
/* ── data layer (race-safe, cached) ── */
const U = T.URLS = {
  matrix: () => '/api/matrix', status: () => '/api/status', coin: () => `/api/coin/${ST.sel}?tf=${T.atf()}`, k: () => `/api/klines/${ST.sel}?tf=${ST.tf}&limit=200`,
  deep: () => `/api/deep/${ST.sel}?tf=${T.atf()}`, plan: () => `/api/plan/${ST.sel}?tf=${T.atf()}`, pat: () => `/api/patterns/${ST.sel}?tf=${T.atf()}`, micro: () => `/api/micro/${ST.sel}`,
  bt: () => `/api/backtest/${ST.sel}?tf=${T.atf()}`, ai: () => `/api/ai/${ST.sel}?tf=${T.atf()}`, mkt: () => '/api/market', acct: () => '/api/exchange', alerts: () => '/api/alerts',
  log: () => '/api/signals/log', ev: () => '/api/evidence', settings: () => '/api/settings', cfg: () => '/api/auto/config',
  rep: () => `/api/report/${ST.sel}?tf=${T.atf()}`, perf: () => '/api/exchange/performance', ctx: () => `/api/context/${ST.sel}`, ready: () => '/api/readiness', learn: () => '/api/learn'
};
const TTL = { matrix: 6, status: 6, coin: 20, k: 8, deep: 45, plan: 60, pat: 90, micro: 20, bt: 300, ai: 120, mkt: 30, acct: 6, alerts: 15, log: 60, ev: 120, settings: 600, cfg: 600, rep: 40, perf: 8, ctx: 30, ready: 90, learn: 45 };
const D = T.D = {}, PEND = {};
T.api = async (u, o) => { try { const r = await fetch(u, Object.assign({ headers: { 'Content-Type': 'application/json' } }, o || {})); return await r.json(); } catch (e) { return { error: 'خطای ارتباط با سرور' }; } };
T.post = (u, b) => T.api(u, { method: 'POST', body: JSON.stringify(b || {}) });
const cur = T.cur = n => { const d = D[n]; return d && d.u === U[n]() ? d.d : null; };
T.load = async function (n, force) {
  const u = U[n](), d = D[n]; if (!force && d && d.u === u && Date.now() - d.t < TTL[n] * 1000) return;
  if (PEND[n] === u) return; PEND[n] = u; const r = await T.api(u); if (PEND[n] === u) PEND[n] = null;
  if (U[n]() !== u) return; D[n] = { u, t: Date.now(), d: r }; if (T.onData) T.onData(n);
};
T.R = s => T.g(cur('matrix'), 'matrix.' + s, null);
T.syms = () => { const l = T.g(cur('status'), 'symbols', []); return l && l.length ? l : Object.keys(T.g(cur('matrix'), 'matrix', {})); };
T.sideOf = r => r ? (r.verdict || T.g(r, 'tfs.1h.side', 'WAIT')) : 'WAIT';
T.SIG = () => T.g(cur('coin'), 'signal', null);
/* ── toast + sheets ── */
T.toast = m => { const t = $('#toast'); t.textContent = m; t.classList.add('on'); clearTimeout(T.toast.h); T.toast.h = setTimeout(() => t.classList.remove('on'), 2600); };
T.sheet = function (title, html) { T.closeSheet(); $('#sheet-root').innerHTML = `<div class="bd" data-act="sheet-x"></div><div class="sheet" role="dialog" aria-label="${T.esc(title)}"><div class="grab"></div>${title ? `<h3>${T.esc(title)}</h3>` : ''}<div id="sheet-body">${html}</div></div>`; };
T.closeSheet = () => { $('#sheet-root').innerHTML = ''; };
})();
