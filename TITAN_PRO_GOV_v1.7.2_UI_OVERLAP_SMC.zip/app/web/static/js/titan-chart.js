/* TITAN AI — chart engine (candles, EMA, volume, levels, FUTURE candles + probability bands) and small SVG helpers */
(function () {
'use strict';

/* bar timestamp → human label (date + hour) */
T.fmtBarTime = function (t, tf) {
  if (t == null) return "—";
  const d = new Date(typeof t === "number" ? (t < 1e12 ? t * 1000 : t) : t);
  if (isNaN(d.getTime())) return "—";
  const pad = n => String(n).padStart(2, "0");
  const Y = d.getFullYear(), M = pad(d.getMonth() + 1), D = pad(d.getDate());
  const h = pad(d.getHours()), m = pad(d.getMinutes());
  if (tf === "1d") return `${Y}/${M}/${D}`;
  if (tf === "4h" || tf === "1h") return `${M}/${D} ${h}:00`;
  return `${M}/${D} ${h}:${m}`;
};

const { $, $$, g, num, fp, cur, ST, P, esc } = Object.assign({}, T, { P: null });
const PR = () => T.P;
const css = n => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
function ema(a, n) { const k = 2 / (n + 1); let e = null; return a.map(v => (e = e == null ? v : v * k + e * (1 - k))); }
const rgba = (hex, a) => { const m = /^#?([\da-f]{2})([\da-f]{2})([\da-f]{2})$/i.exec(hex.trim()); return m ? `rgba(${parseInt(m[1], 16)},${parseInt(m[2], 16)},${parseInt(m[3], 16)},${a})` : hex; };
function haSeries(a) { const o = []; let po = null, pc = null; a.forEach(k => { const c = (k.o + k.h + k.l + k.c) / 4, op = po == null ? (k.o + k.c) / 2 : (po + pc) / 2; o.push({ o: op, c, h: Math.max(k.h, op, c), l: Math.min(k.l, op, c), v: k.v }); po = op; pc = c; }); return o; }
T.forecastOf = () => { const f = T.g(cur('coin'), 'forecast', null); return f && Array.isArray(f.candles) && f.candles.length ? f : null; };

/* geometry shared by draw + hit-test so crosshair always matches */
function layout(cv, full) {
  const W = cv.clientWidth, H = cv.clientHeight, p = PR(), all = T.g(cur('k'), 'klines', []), f = (p.fut && ST.tf === T.atf()) ? T.forecastOf() : null;
  const AX = 60, top = 14, bot = 16, vh = p.vol ? (H - top - bot) * .15 : 0, ph = H - top - bot - vh, pw = W - AX;
  const slots = Math.max(24, Math.floor(pw / (full ? 8 : 6))), nf = f ? Math.min(p.fcN, f.candles.length, Math.floor(slots * .42)) : 0, nh = Math.min(all.length, slots - nf);
  return { W, H, AX, top, bot, vh, ph, pw, slots, nf, nh, cw: pw / (nh + nf), all, f, off: all.length - nh };
}
T.drawChart = function (cv, full) {
  if (!cv) return; const dpr = window.devicePixelRatio || 1, W = cv.clientWidth, H = cv.clientHeight; if (!W || !H) return;
  cv.width = W * dpr; cv.height = H * dpr; const x = cv.getContext('2d'); x.setTransform(dpr, 0, 0, dpr, 0, 0); x.clearRect(0, 0, W, H);
  const p = PR(), d = cur('k'), L = layout(cv, full), all = L.all;
  if (!all.length) { x.fillStyle = css('--mu'); x.font = '600 13px sans-serif'; x.textAlign = 'center'; x.fillText(d && d.error ? d.error : 'در حال دریافت نمودار…', W / 2, H / 2); return; }
  const { AX, top, bot, vh, ph, pw, nf, nh, cw, f, off } = L, ks = all.slice(off), up = css('--cup'), dn = css('--cdn'), fut = css('--fut'), sig = T.SIG();
  const fc = f ? f.candles.slice(0, nf) : [], bd = f && f.bands ? f.bands : {};
  const lv = p.lvl && sig && sig.side !== 'WAIT' ? [['ورود', sig.entry, css('--info')], ['SL', sig.stop, css('--cdn')], ['TP1', sig.tp1, css('--up')], ['TP2', sig.tp2, css('--up')], ['TP3', sig.tp3, css('--up')], ['حد متحرک', T.g(sig, 'levels.trail', null), css('--am')]].filter(l => num(l[1])) : [];
  let hi = -Infinity, lo = Infinity, vm = 0; ks.forEach(k => { hi = Math.max(hi, k.h); lo = Math.min(lo, k.l); vm = Math.max(vm, k.v); });
  fc.forEach(k => { hi = Math.max(hi, k.high); lo = Math.min(lo, k.low); });
  if (p.band && nf) ['p10', 'p90'].forEach(q => (bd[q] || []).slice(0, nf).forEach(v => { if (num(v)) { hi = Math.max(hi, v); lo = Math.min(lo, v); } }));
  lv.forEach(l => { if (l[1] < hi * 1.12 && l[1] > lo * .88) { hi = Math.max(hi, l[1]); lo = Math.min(lo, l[1]); } });
  const pad = (hi - lo) * .06 || hi * .01; hi += pad; lo -= pad; const Y = v => top + (hi - v) / (hi - lo) * ph, X = i => i * cw + cw / 2;
  x.font = '600 11.5px sans-serif'; x.textAlign = 'left'; x.lineWidth = 1;
  for (let i = 0; i <= 4; i++) { const v = hi - (hi - lo) * i / 4, y = Y(v); if (p.grid) { x.strokeStyle = 'rgba(60,110,255,.18)'; x.beginPath(); x.moveTo(0, y); x.lineTo(pw, y); x.stroke(); } x.fillStyle = css('--tx'); x.fillText(fp(v), pw + 5, Math.min(H - 3, Math.max(11, y + 4))); }
  if (p.grid) for (let i = 0; i < nh + nf; i += 7) { x.strokeStyle = 'rgba(60,110,255,.12)'; x.beginPath(); x.moveTo(X(i), top); x.lineTo(X(i), top + ph); x.stroke(); }
  if (nf) { const sx = X(nh - 1) + cw / 2; x.fillStyle = rgba(fut, .07); x.fillRect(sx, 0, pw - sx, H); x.setLineDash([4, 4]); x.strokeStyle = rgba(fut, .7); x.beginPath(); x.moveTo(sx, top); x.lineTo(sx, H - bot); x.stroke(); x.setLineDash([]); x.fillStyle = fut; x.font = '700 11px sans-serif'; x.fillText('پیش‌بینی ▸', sx + 4, top + 10); x.font = '600 11.5px sans-serif'; }
  const ct = p.ctype || 'candle', HA = ct === 'heikin' ? haSeries(all).slice(off) : null;
  if (ct === 'line' || ct === 'area') {
    x.beginPath(); ks.forEach((k, i) => i ? x.lineTo(X(i), Y(k.c)) : x.moveTo(X(i), Y(k.c))); x.strokeStyle = css('--acc'); x.lineWidth = 2; x.stroke();
    if (ct === 'area') { x.lineTo(X(ks.length - 1), top + ph); x.lineTo(X(0), top + ph); x.closePath(); const gr = x.createLinearGradient(0, top, 0, top + ph); gr.addColorStop(0, rgba(css('--acc'), .35)); gr.addColorStop(1, rgba(css('--acc'), 0)); x.fillStyle = gr; x.fill(); }
  }
  ks.forEach((k0, i) => {
    const k = HA ? HA[i] : k0, cx = X(i), u = k.c >= k.o, c = u ? up : dn, bw = Math.max(2, cw * .62); x.strokeStyle = c; x.fillStyle = c; x.lineWidth = 1.2;
    if (ct === 'ohlc') { x.beginPath(); x.moveTo(cx, Y(k.h)); x.lineTo(cx, Y(k.l)); x.moveTo(cx - bw / 2, Y(k.o)); x.lineTo(cx, Y(k.o)); x.moveTo(cx, Y(k.c)); x.lineTo(cx + bw / 2, Y(k.c)); x.stroke(); }
    else if (ct !== 'line' && ct !== 'area') {
      x.beginPath(); x.moveTo(cx, Y(k.h)); x.lineTo(cx, Y(k.l)); x.stroke(); const by = Y(Math.max(k.o, k.c)), bh = Math.max(1.5, Math.abs(Y(k.o) - Y(k.c)));
      if (ct === 'hollow' && u) { x.fillStyle = css('--cbg2'); x.fillRect(cx - bw / 2, by, bw, bh); x.strokeRect(cx - bw / 2, by, bw, bh); } else x.fillRect(cx - bw / 2, by, bw, bh);
    }
    if (p.vol && vm) { x.globalAlpha = .5; x.fillStyle = c; x.fillRect(cx - bw / 2, H - bot - k0.v / vm * vh, bw, k0.v / vm * vh); x.globalAlpha = 1; }
  });
  if (p.ema) { const cl = all.map(k => k.c); [[9, css('--am')], [21, css('--info')], [50, css('--vio')]].forEach(([m, c]) => { const e = ema(cl, m).slice(off); x.strokeStyle = c; x.lineWidth = 1.5; x.beginPath(); e.forEach((v, i) => i ? x.lineTo(X(i), Y(v)) : x.moveTo(X(i), Y(v))); x.stroke(); }); }
  const lvl = (sig && sig.levels) || {}, x10 = T.g(sig, 'extras.x10', {}) || {}, refs = x10.exit_refs || {}, hl = (v, col, lab, dash) => { if (!num(v) || v > hi || v < lo) return; const y = Y(v); x.setLineDash(dash || [2, 4]); x.strokeStyle = col; x.lineWidth = 1; x.beginPath(); x.moveTo(0, y); x.lineTo(pw, y); x.stroke(); x.setLineDash([]); if (p.tag && lab) { x.fillStyle = col; x.font = '700 10px sans-serif'; x.textAlign = 'right'; x.fillText(lab, pw - 4, y - 3); x.textAlign = 'left'; } };
  if (p.ez && sig && sig.side !== 'WAIT' && lvl.entry_zone && num(lvl.entry_zone.lo) && num(lvl.entry_zone.hi)) { const y1 = Y(Math.min(hi, lvl.entry_zone.hi)), y2 = Y(Math.max(lo, lvl.entry_zone.lo)); if (y2 > y1) { x.fillStyle = rgba(css('--info'), .13); x.fillRect(0, y1, pw, y2 - y1); if (p.tag) { x.fillStyle = css('--info'); x.font = '700 10px sans-serif'; x.fillText('ناحیهٔ ورود', 4, y1 + 11); } } }
  if (p.vwap && refs.vwap) { hl(refs.vwap, css('--am'), 'VWAP', [6, 3]); hl(refs.vwap_u1, rgba(css('--am'), .6), '+1σ'); hl(refs.vwap_l1, rgba(css('--am'), .6), '−1σ'); hl(refs.vwap_u2, rgba(css('--am'), .4), '+2σ'); hl(refs.vwap_l2, rgba(css('--am'), .4), '−2σ'); }
  if (p.zones && Array.isArray(lvl.zones)) lvl.zones.forEach(z => hl(z.p, z.kind === 'R' ? rgba(css('--cdn'), .7) : rgba(css('--cup'), .7), (z.kind === 'R' ? 'مقاومت ' : 'حمایت ') + fp(z.p), [8, 3]));
  if (p.bb) { const cl = all.map(k => k.c), n = 20, mid = [], up_ = [], lo_ = []; for (let i = n - 1; i < cl.length; i++) { const w = cl.slice(i - n + 1, i + 1), m = w.reduce((a, b) => a + b, 0) / n, sd = Math.sqrt(w.reduce((a, b) => a + (b - m) * (b - m), 0) / n); mid[i] = m; up_[i] = m + 2 * sd; lo_[i] = m - 2 * sd; }
    [[up_, .55], [mid, .3], [lo_, .55]].forEach(([arr, al]) => { x.strokeStyle = rgba(css('--ring1'), al); x.lineWidth = 1; x.beginPath(); let st = false; for (let i = 0; i < ks.length; i++) { const v = arr[i + off]; if (!num(v)) continue; st ? x.lineTo(X(i), Y(v)) : (x.moveTo(X(i), Y(v)), st = true); } x.stroke(); }); }
  if (p.lr && x10.items && x10.items.linreg && num(x10.items.linreg.mid)) { const lr = x10.items.linreg, n = Math.min(lr.n || 50, ks.length), slope = lr.slope_pct != null ? lr.slope_pct / 100 * lr.mid : 0, i0_ = ks.length - n, y0 = v => Y(v);
    [[0, .9], [lr.upper - lr.mid, .5], [lr.lower - lr.mid, .5]].forEach(([dv, al]) => { x.setLineDash(dv ? [4, 3] : []); x.strokeStyle = rgba(css('--vio'), al); x.lineWidth = 1.2; x.beginPath(); x.moveTo(X(i0_), y0(lr.mid - slope * (n - 1) + dv)); x.lineTo(X(ks.length - 1), y0(lr.mid + dv)); x.stroke(); x.setLineDash([]); }); }
  if (nf) {
    const last = ks[ks.length - 1], x0 = X(nh - 1), band = (a, b, al) => { const A = (bd[a] || []).slice(0, nf), B = (bd[b] || []).slice(0, nf); if (A.length < 2 || B.length < 2) return; x.beginPath(); x.moveTo(x0, Y(last.c)); A.forEach((v, i) => x.lineTo(X(nh + i), Y(v))); for (let i = B.length - 1; i >= 0; i--) x.lineTo(X(nh + i), Y(B[i])); x.closePath(); x.fillStyle = rgba(fut, al); x.fill(); };
    if (p.band) { band('p10', 'p90', .1); band('p25', 'p75', .18); const m = (bd.p50 || []).slice(0, nf); if (m.length) { x.setLineDash([5, 4]); x.strokeStyle = rgba('#ffffff', .75); x.lineWidth = 1.4; x.beginPath(); x.moveTo(x0, Y(last.c)); m.forEach((v, i) => x.lineTo(X(nh + i), Y(v))); x.stroke(); x.setLineDash([]); } }
    fc.forEach((k, i) => { const cx = X(nh + i), u = k.close >= k.open, bw = Math.max(2, cw * .62); x.strokeStyle = fut; x.lineWidth = 1.2; x.beginPath(); x.moveTo(cx, Y(k.high)); x.lineTo(cx, Y(k.low)); x.stroke(); const y1 = Y(Math.max(k.open, k.close)), h = Math.max(1.5, Math.abs(Y(k.open) - Y(k.close))); if (u) { x.fillStyle = rgba(fut, .75); x.fillRect(cx - bw / 2, y1, bw, h); } else { x.fillStyle = rgba(fut, .12); x.fillRect(cx - bw / 2, y1, bw, h); x.strokeRect(cx - bw / 2, y1, bw, h); } });
  }
  lv.forEach(l => { if (l[1] > hi || l[1] < lo) return; const y = Y(l[1]); x.setLineDash([5, 4]); x.strokeStyle = l[2]; x.lineWidth = 1; x.beginPath(); x.moveTo(0, y); x.lineTo(pw, y); x.stroke(); x.setLineDash([]); x.fillStyle = l[2]; x.font = '700 10.5px sans-serif'; x.fillText(l[0], 4, y - 3); });
  const lk = ks[ks.length - 1], yl = Y(lk.c), lc = lk.c >= lk.o ? up : dn; if (p.lastp) { x.setLineDash([3, 3]); x.strokeStyle = lc; x.lineWidth = 1; x.beginPath(); x.moveTo(0, yl); x.lineTo(pw, yl); x.stroke(); x.setLineDash([]); }
  const ty = Math.max(0, Math.min(H - 20, yl - 10)); x.fillStyle = lc; x.fillRect(pw + 1, ty, AX - 2, 20); x.fillStyle = '#04101c'; x.font = '800 11.5px sans-serif'; x.fillText(fp(lk.c), pw + 4, ty + 14);
  /* X-axis date/time labels under candles */
  x.fillStyle = css('--mu'); x.font = '600 9.5px sans-serif'; x.textAlign = 'center';
  const step = Math.max(1, Math.floor(nh / 5));
  for (let i = 0; i < nh; i += step) {
    const k = ks[i]; if (!k || k.t == null) continue;
    const lab = T.fmtBarTime(k.t, ST.tf);
    x.fillText(lab, X(i), H - 2);
  }
  if (nh > 0) { const k = ks[nh - 1]; if (k && k.t != null) x.fillText(T.fmtBarTime(k.t, ST.tf), X(nh - 1), H - 2); }

  if (ST.cx >= 0 && ST.cx < nh + nf) { const cx = X(ST.cx); x.strokeStyle = 'rgba(255,255,255,.45)'; x.setLineDash([3, 3]); x.beginPath(); x.moveTo(cx, top); x.lineTo(cx, H - bot); x.stroke(); x.setLineDash([]); x.fillStyle = css('--tx'); x.font = '700 11px sans-serif'; x.textAlign = 'left';
    if (ST.cx < nh) { const k = ks[ST.cx]; const tm = T.fmtBarTime(k.t, ST.tf); x.fillText(`${tm}   O ${fp(k.o)}  H ${fp(k.h)}  L ${fp(k.l)}  C ${fp(k.c)}`, 6, 13); } else { const k = fc[ST.cx - nh]; if (k) { x.fillStyle = fut; const tm = k.t ? T.fmtBarTime(k.t, ST.tf) : ('#' + (ST.cx - nh + 1)); x.fillText(`پیش‌بینی ${tm}  O ${fp(k.open)}  H ${fp(k.high)}  L ${fp(k.low)}  C ${fp(k.close)}`, 6, 13); } } }
};
T.redrawCharts = () => { ['cv-dash', 'cv-fc', 'cv-full'].forEach(id => { const c = $('#' + id); if (c) T.drawChart(c, id === 'cv-full'); }); };
T.chartHTML = (id, tall, tfs) => `${tfs === false ? '' : `<div class="tfs">${T.CTF.map(([k, n]) => `<button data-tf="${k}" class="${ST.tf === k ? 'on' : ''}">${n}</button>`).join('')}<button class="ic" data-act="chart-opts" aria-label="تنظیمات نمودار">${T.ic('ind')}</button><button class="ic" data-act="full" aria-label="تمام‌صفحه">${T.ic('exp')}</button></div>`}<div class="cwrap ${tall ? 'tall' : ''}"><canvas id="${id}"></canvas></div>
  <div class="legend"><span><i style="background:var(--am)"></i>EMA9</span><span><i style="background:var(--info)"></i>EMA21</span><span><i style="background:var(--vio)"></i>EMA50</span><span><i style="background:var(--fut)"></i>کندل آینده</span><span><i style="background:#fff"></i>میانهٔ پیش‌بینی</span>${T.P.vwap ? `<span><i style="background:var(--am)"></i>VWAP±σ</span>` : ''}${T.P.lr ? `<span><i style="background:var(--vio)"></i>کانال رگرسیون</span>` : ''}${T.P.bb ? `<span><i style="background:var(--ring1)"></i>بولینگر</span>` : ''}</div>`;
T.chartInit = function (id) {
  const cv = $('#' + id); if (!cv || cv.dataset.ev) return; cv.dataset.ev = 1; const full = id === 'cv-full';
  const mv = e => { const L = layout(cv, full), r = cv.getBoundingClientRect(); ST.cx = Math.max(0, Math.min(L.nh + L.nf - 1, Math.floor((e.clientX - r.left) / L.cw))); T.redrawCharts(); };
  cv.addEventListener('pointerdown', mv); cv.addEventListener('pointermove', e => { if (e.buttons || e.pointerType === 'mouse') mv(e); });
  const out = () => { ST.cx = -1; T.redrawCharts(); }; cv.addEventListener('pointerleave', out); cv.addEventListener('pointerup', out); cv.addEventListener('pointercancel', out);
  T.drawChart(cv, full);
};
/* ── svg helpers ── */
let gid = 0;
T.gauge = (p, c) => { const C = 2 * Math.PI * 42, a = C * .75, v = Math.max(0, Math.min(100, p || 0)) / 100 * a, col = c === 'up' ? 'var(--up)' : c === 'dn' ? 'var(--dn)' : c === 'score' ? 'url(#gs' + (++gid) + ')' : 'var(--am)';
  const def = c === 'score' ? `<defs><linearGradient id="gs${gid}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#b44bff"/><stop offset=".4" stop-color="#2d8cff"/><stop offset=".7" stop-color="#21e65a"/><stop offset="1" stop-color="#ff9d00"/></linearGradient></defs>` : '';
  return `<svg viewBox="0 0 100 100">${def}<circle cx="50" cy="50" r="42" fill="none" stroke="#0b1a46" stroke-width="10" stroke-linecap="round" stroke-dasharray="${a} ${C}"/><circle cx="50" cy="50" r="42" fill="none" stroke="${col}" stroke-width="10" stroke-linecap="round" stroke-dasharray="${v} ${C}" style="filter:drop-shadow(0 0 calc(4px*var(--glow)) rgba(80,255,120,.6))"/></svg>`; };
T.spark = (a, w = 100, h = 36, fa) => { a = (a || []).filter(num); if (a.length < 2) return ''; const f = (fa || []).filter(num), all = a.concat(f), mn = Math.min(...all), mx = Math.max(...all), t = all.length - 1, X = i => (i / t * w).toFixed(1), Yv = v => (h - 3 - (v - mn) / ((mx - mn) || 1) * (h - 6)).toFixed(1), up = a[a.length - 1] >= a[0];
  return `<svg viewBox="0 0 ${w} ${h}" width="${w}" height="${h}" preserveAspectRatio="none"><polyline points="${a.map((v, i) => X(i) + ',' + Yv(v)).join(' ')}" fill="none" stroke="${up ? 'var(--up)' : 'var(--dn)'}" stroke-width="1.8" stroke-linejoin="round"/>${f.length ? `<polyline points="${[a[a.length - 1]].concat(f).map((v, i) => X(a.length - 1 + i) + ',' + Yv(v)).join(' ')}" fill="none" stroke="var(--fut)" stroke-width="1.6" stroke-dasharray="3 2"/>` : ''}</svg>`; };
T.heatColor = (side, score) => { const a = Math.min(.85, .15 + Math.abs(score || 0) / 100 * .7); return side === 'LONG' ? `rgba(33,230,90,${a})` : side === 'SHORT' ? `rgba(255,59,78,${a})` : 'rgba(255,176,32,.16)'; };
})();
