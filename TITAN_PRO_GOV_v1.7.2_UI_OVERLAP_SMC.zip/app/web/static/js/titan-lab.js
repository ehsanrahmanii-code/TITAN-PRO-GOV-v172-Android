/* TITAN AI — Coin Lab (deep per-coin analysis) + new analysis / markets pages */
(function () {
'use strict';
const { $, g, num, fmt, fp, sg, pc, usd, p100, N, cls, FA, ago, coin, kv, bar, empty, loading, noData, esc, ic, cur, ST, R, syms, sideOf, SIG, ATF } = T;
const V = T.V, H = T.H, base = s => String(s).replace('USDT', '');
const sdp = H.side;
const TFN = { '15m': '۱۵ دقیقه', '1h': '۱ ساعت', '4h': '۴ ساعت', '1d': '۱ روز' };
const SEC_FA = { trend: 'روند', momentum: 'مومنتوم', volume: 'حجم و جریان پول', structure: 'ساختار و SMC', levels: 'سطوح و فضای حرکت', pattern: 'الگوها', osc: 'اسیلاتورها', forecast: 'پیش‌بینی آماری', volat: 'نوسان', quality: 'کیفیت بازار' };
const symHead = () => { const r = R(ST.sel), t = g(r, 'ticker', {}); return `<div class="glass card" style="margin-top:6px"><div class="row" style="padding:0;border:0"><span style="display:flex;align-items:center;gap:8px;font-weight:800;direction:ltr">${coin(base(ST.sel), 30)}${esc(base(ST.sel))}<span class="mu n" style="font-weight:600">/USDT</span></span><span class="n" style="font-weight:800">${fp(t.price)}</span><button class="btn s o" data-act="pick">تغییر ارز</button></div></div>`; };
const tfBar = () => `<div class="seg" style="margin:8px 0 0">${ATF.map(t => `<button data-tf="${t}" class="${T.atf() === t ? 'on' : ''}">${t}</button>`).join('')}</div>`;
const repGuard = (el, withHead = true) => {
  const d = cur('rep'), h = withHead ? symHead() + tfBar() : '';
  if (!d) { el.innerHTML = h + `<div class="glass card">${loading}<div class="note ctr">تحلیل عمیق چند ثانیه طول می‌کشد…</div></div>`; return null; }
  if (d.error || d.ok === false) { el.innerHTML = h + `<div class="glass card"><div class="empty err">${esc(d.error || 'داده کافی برای تحلیل عمیق نیست')}</div></div>`; return null; }
  return d;
};
const secLabel = k => SEC_FA[k] || k;

/* ═════════ Coin Lab: final verdict ═════════ */
V['lab:sum'] = { needs: ['rep'], live: true, paint(el) {
  const d = repGuard(el); if (!d) return; const p = d.plan, ez = d.entry_zone || {};
  el.innerHTML = symHead() + tfBar() + `<div class="glass card gold"><h2>نتیجهٔ نهایی یکپارچه <small>درجه ${esc(d.grade)}</small></h2>
  <div style="display:flex;align-items:center;gap:14px"><div class="gauge" style="width:108px;height:108px">${T.gauge(d.confidence * 100, d.final === 'SHORT' ? 'dn' : d.final === 'WAIT' ? 'am' : 'up')}<div class="t"><b class="${cls(d.final)}">${FA[d.final] || d.final}</b><small>${fmt(d.confidence * 100, 0)}٪</small></div></div>
  <div style="flex:1"><div class="kv">${kv('امتیاز یکپارچه', N(sg(d.unified_score, 0)), H.pcls(d.unified_score))}${kv('اقدام', esc(d.action))}${kv('هستهٔ AI', N(sg(d.core_score, 0)))}${kv('ماتریس', N(sg(d.matrix_score, 0)))}</div></div></div>${H.meter(d.unified_score)}
  <p class="note">${esc(d.action_why)}</p></div>
  <div class="glass card"><h2>روایت تحلیل</h2>${(d.narrative || []).map((x, i) => `<div class="step"><b class="n">${i + 1}</b><span>${esc(x)}</span></div>`).join('')}</div>
  ${p ? `<div class="glass card"><h2>برنامهٔ معامله <small>${esc(d.primary_tf)}</small></h2><div class="kv c3">${kv('ورود', N(fp(p.entry)))}${kv('حد ضرر', N(fp(p.stop)), 'dn')}${kv('R:R', N(fmt(p.risk_reward, 2)))}${kv('TP1', N(fp(p.tp1)), 'up')}${kv('TP2', N(fp(p.tp2)), 'up')}${kv('TP3', N(fp(p.tp3)), 'up')}</div>
  ${ez.lo ? `<div class="note">ناحیهٔ ورود بهتر: <b class="n" dir="ltr">${fp(ez.lo)} – ${fp(ez.hi)}</b> ${ez.now_ok ? '· قیمت داخل ناحیه است ✓' : ''}</div>` : ''}${d.trail ? `<div class="note">حد ضرر متحرک (Chandelier): <b class="n">${fp(d.trail)}</b></div>` : ''}${(d.tp_notes || []).map(x => `<div class="note am">• ${esc(x)}</div>`).join('')}
  <div class="acts"><button class="btn ${d.final === 'SHORT' ? 'r' : 'g'}" data-act="to-ticket">ارسال به برگهٔ سفارش</button><button class="btn o" data-go="lab:plan">جزئیات برنامه</button></div></div>` : ''}
  <div class="glass card"><h2>تفکیک اطمینان</h2>${(d.confidence_parts || []).map(x => `<div class="row"><span class="g">${esc(x.k)}<div class="mu" style="font-size:.7rem">${esc(x.note)}</div></span><span style="width:90px">${H.m100(x.v)}</span><b class="n" style="width:34px;text-align:left">${x.v}</b></div>`).join('')}</div>
  <div class="glass card"><h2>نظر هر تایم‌فریم</h2>${(d.horizons || []).map(h => `<div class="row" data-go="lab:tf" style="cursor:pointer"><b style="width:34px">${esc(h.tf)}</b>${sdp(h.side)}<span class="g mu" style="font-size:.74rem">${esc(h.role)}</span><b class="n ${H.sc(h.score)}">${sg(h.score, 0)}</b></div>`).join('')}</div>
  ${(d.risks || []).length ? `<div class="glass card"><h2>ریسک‌ها</h2><ul class="ls am">${d.risks.map(x => `<li>${esc(x)}</li>`).join('')}</ul></div>` : ''}
  ${(d.conflicts || []).length ? `<div class="glass card"><h2>تعارض‌ها</h2><ul class="ls am">${d.conflicts.map(x => `<li>${esc(x)}</li>`).join('')}</ul></div>` : ''}
  ${(d.invalidation || []).length ? `<div class="glass card"><h2>چه چیزی ایده را باطل می‌کند؟</h2><ul class="ls">${d.invalidation.map(x => `<li>${esc(x)}</li>`).join('')}</ul></div>` : ''}
  ${(d.grade_why || []).length ? `<div class="glass card"><h2>دلیل درجه ${esc(d.grade)}</h2>${d.grade_why.map(w => `<div class="row"><span>${esc(w.t)}</span><b class="n ${w.p >= 0 ? 'up' : 'dn'}">${sg(w.p, 0)}</b></div>`).join('')}</div>` : ''}`;
} };

/* ═════════ Section × timeframe matrix ═════════ */
V['lab:mx'] = { needs: ['rep'], live: true, paint(el) {
  const d = repGuard(el); if (!d) return;
  const dir = (d.matrix || []).filter(r => r.kind === 'dir'), st = (d.matrix || []).filter(r => r.kind !== 'dir');
  el.innerHTML = symHead() + tfBar() + `<div class="glass card"><h2>ماتریس بخش × تایم‌فریم <small>روی هر خانه بزنید</small></h2><div class="mxw"><table class="tbl"><tr><th style="text-align:left">بخش</th>${d.tfs.map(t => `<th>${t}</th>`).join('')}<th>کل</th></tr>
  ${dir.map(r => `<tr><td>${esc(r.name)}${r.conflict ? ' <span class="am">⚠</span>' : ''}</td>${d.tfs.map(t => { const c = r.cells[t]; return `<td class="cell" style="${H.scoreCell(c.score)}" data-cell="${r.id}|${t}">${sg(c.score, 0)}</td>`; }).join('')}<td class="cell" style="${H.scoreCell(r.score)}" data-cell="${r.id}|all"><b>${sg(r.score, 0)}</b></td></tr>`).join('')}
  <tr><td><b>نتیجهٔ تایم‌فریم</b></td>${d.tfs.map(t => `<td class="cell" style="${H.scoreCell(d.per_tf[t].score)}" data-go="lab:tf"><b>${sg(d.per_tf[t].score, 0)}</b></td>`).join('')}<td style="${H.scoreCell(d.unified_score)}"><b>${sg(d.unified_score, 0)}</b></td></tr></table></div>
  <p class="note">⚠ یعنی تایم‌فریم‌ها در آن بخش هم‌نظر نیستند.</p></div>
  <div class="glass card"><h2>بخش‌های وضعیتی</h2>${st.map(r => `<div class="ix"><div class="h"><span class="nm">${esc(r.name)}</span></div>${d.tfs.map(t => `<div class="t"><b>${t}:</b> ${esc(r.cells[t].text)}</div>`).join('')}</div>`).join('')}</div>
  <div class="glass card"><h2>ریزساختار بازار <small>${H.chip(d.micro.ok ? 'فعال' : 'نامشخص', d.micro.ok ? 'up' : 'am')}</small></h2><p class="note">${esc(d.micro.text)} ${d.micro.ok ? '(' + sg(d.micro.score, 0) + ')' : ''}</p></div>`;
} };
T.cellSheet = (id, tf) => {
  const d = cur('rep'); if (!d) return; const row = (d.matrix || []).find(r => r.id === id); if (!row) return;
  if (tf === 'all') return T.sheet(row.name + ' — همهٔ تایم‌فریم‌ها', `<p class="note">${esc(row.text)}</p>${d.tfs.map(t => `<div class="ix ${row.cells[t].score >= 14 ? 'up' : row.cells[t].score <= -14 ? 'dn' : ''}"><div class="h"><b>${t}</b>${sdp(row.cells[t].side)}<span class="nm"></span><b class="n">${sg(row.cells[t].score, 0)}</b></div><div class="t">${esc(row.cells[t].text)}</div></div>`).join('')}`);
  const c = row.cells[tf]; T.sheet(`${row.name} · ${tf}`, `<div class="row" style="border:0">${sdp(c.side)}<span class="g"></span><b class="n ${H.sc(c.score)}">${sg(c.score, 0)}</b></div>${H.meter(c.score)}<p class="note">${esc(c.text)}</p>${(c.facts || []).map(f => `<div class="step"><b class="n">•</b><span>${esc(f)}</span></div>`).join('') || empty('جزئیات بیشتری نیست')}`);
};

/* ═════════ Per-timeframe opinion ═════════ */
V['lab:tf'] = { needs: ['rep'], live: true, paint(el) {
  const d = repGuard(el, false); if (!d) { el.innerHTML = symHead() + el.innerHTML; return; }
  el.innerHTML = symHead() + d.tfs.map(t => { const p = d.per_tf[t]; return `<div class="glass card"><h2>${t} · ${esc(p.role)} <small>${TFN[t]}</small></h2><div class="row" style="border:0;padding:0">${sdp(p.side)}<span class="g mu" style="font-size:.76rem">هسته: ${FA[p.core_side] || p.core_side} (${sg(p.core_score, 0)})</span><b class="n ${H.sc(p.score)}">${sg(p.score, 0)}</b></div>${H.meter(p.score)}
  <p class="note">${esc(p.text)}</p><div class="kv c3">${kv('اطمینان', N(fmt(p.confidence * 100, 0) + '٪'))}${kv('هم‌سویی', N(fmt(p.agree * 100, 0) + '٪'))}${kv('کیفیت', N(fmt(p.quality, 0)))}</div>
  <div class="sh">نظر هر بخش</div>${Object.entries(p.sections).map(([k, s]) => `<div class="row" data-cell="${k}|${t}" style="cursor:pointer"><span class="g"><b>${esc(secLabel(k))}</b><div class="mu" style="font-size:.72rem">${esc(s.text)}</div></span>${s.kind === 'dir' ? `<b class="n ${H.sc(s.score)}" style="width:38px;text-align:left">${sg(s.score, 0)}</b>` : ''}</div>`).join('')}</div>`; }).join('');
} };

/* ═════════ x10 inside the lab (per timeframe) ═════════ */
const X10_INFO = {
  hurst: ['نمای هرست', 'میزان پایداری روند را می‌سنجد. بالای ۰٫۵۶ یعنی حرکت‌ها تمایل به ادامه دارند (روندی)، زیر ۰٫۴۴ یعنی بازگشت به میانگین. برای انتخاب بین «دنبال‌کردن روند» و «خرید ارزان/فروش گران» استفاده می‌شود.'],
  chop: ['شاخص چاپی', 'اگر بالای ۶۱٫۸ باشد بازار خرد و بدون جهت است و سیگنال‌های روندی بارها حد ضرر می‌خورند؛ زیر ۳۸٫۲ حرکت تمیز و جهت‌دار است.'],
  linreg: ['کانال رگرسیون خطی', 'یک خط روند آماری با باند ±۲σ. R² نشان می‌دهد روند چقدر تمیز است و موقعیت قیمت در کانال، بهترین ناحیهٔ ورود و خروج را نشان می‌دهد.'],
  vol_exp: ['انبساط نوسان', 'نسبت نوسان کوتاه‌مدت به بلندمدت (Garman‑Klass). انبساط شکست‌ها را تأیید می‌کند؛ انقباض نشانهٔ حرکت ناگهانی در راه است.'],
  crsi: ['Connors RSI', 'ترکیب RSI کوتاه، RSI روند متوالی و رتبهٔ درصدی بازده. مقادیر زیر ۱۵ و بالای ۸۵ بهترین نقاط ورود کوتاه‌مدت‌اند.'],
  fisher: ['تبدیل فیشر', 'قیمت را به توزیع نرمال نزدیک می‌کند تا نقاط چرخش واضح شوند؛ چرخش از ناحیهٔ عمیق منفی/مثبت سیگنال برگشت است.'],
  vwapz: ['باندهای σ‑VWAP', 'فاصلهٔ قیمت از VWAP بر حسب انحراف معیار حجم‌وزنی. بیش از +۲σ جای تعقیب نیست و جای خوبی برای برداشت سود است.'],
  sqz: ['مومنتوم اسکوییز', 'وقتی بولینگر داخل کلتنر باشد انرژی انباشته می‌شود؛ هیستوگرام مومنتوم جهت احتمالی شکست را نشان می‌دهد.'],
  klinger: ['اسیلاتور کلینگر', 'جریان پول بلندمدت بر اساس حجم و رنج. تقاطع با خط سیگنال، ورود یا خروج پول هوشمند را تأیید می‌کند.'],
  vortex: ['ویتکس', 'دو خط VI+ و VI− شروع روند را زودتر از میانگین‌ها نشان می‌دهند؛ تقاطع تازه نشانهٔ تغییر جهت است.']
};
T.infoSheet = k => { const i = X10_INFO[k]; if (!i) return; const it = g(SIG(), 'extras.x10.items.' + k, null); T.sheet(i[0], `<p class="note" style="font-size:.9rem">${esc(i[1])}</p>${it ? `<div class="ix ${it.s >= .25 ? 'up' : it.s <= -.25 ? 'dn' : ''}"><div class="h"><span class="nm">مقدار فعلی</span><b class="n">${num(it.v) ? fmt(it.v, 2) : '—'}</b></div><div class="t">${esc(it.t)}</div></div>` : ''}`); };
const x10Cards = x => Object.entries(x.items).map(([k, it]) => `<div class="ix ${it.s >= .25 ? 'up' : it.s <= -.25 ? 'dn' : ''}" data-info="${k}" style="cursor:pointer"><div class="h"><span class="nm">${esc(it.n)}</span>${H.chip(({ quality: 'کیفیت', timing: 'زمان‌بندی', flow: 'جریان' })[it.role], 'info')}<b class="n">${num(it.v) ? fmt(it.v, Math.abs(it.v) >= 10 ? 0 : 2) : '—'}</b></div>${H.meter(it.s * 100)}<div class="t">${esc(it.t)}</div></div>`).join('');
V['lab:ind'] = { needs: ['rep'], live: true, paint(el) {
  const d = repGuard(el); if (!d) return; const sel = ST.labTf && d.per_tf[ST.labTf] ? ST.labTf : d.primary_tf, s = g(cur('coin'), 'signal', null);
  const x = d.x10; if (!x || !x.items) { el.innerHTML = symHead() + `<div class="glass card">${empty('داده کافی نیست')}</div>`; return; }
  el.innerHTML = symHead() + tfBar() + `<div class="glass card"><h2>خلاصهٔ ۱۰ شاخص تکمیلی <small>${esc(d.primary_tf)}</small></h2><div class="kv c3">${kv('کیفیت', N(fmt(x.quality, 0)), x.quality >= 60 ? 'up' : x.quality >= 40 ? 'am' : 'dn')}${kv('زمان‌بندی', N(sg(x.timing, 0)), H.pcls(x.timing))}${kv('جریان', N(sg(x.flow, 0)), H.pcls(x.flow))}</div><p class="note">${esc(x.quality_label)} · ${esc(x.timing_label)}</p></div>${x10Cards(x)}`;
} };

/* ═════════ plan ═════════ */
V['lab:plan'] = { needs: ['rep', 'plan'], live: true, paint(el) {
  const d = repGuard(el); if (!d) return; const pl = cur('plan'), s = d.plan, rf = d.refs || {};
  const rows = sd => g(pl, sd + '.rows', []) || [];
  const tbl = (t, rs) => rs.length ? `<div class="glass card"><h2>${t} <small>امید ریاضی R</small></h2>${rs.slice(0, 6).map(r => `<div class="row"><span class="g"><b>${esc(r.name)}</b><div class="mu n" style="font-size:.7rem">ورود ${fp(r.p)} · SL ${fp(r.stop)} · پر شدن ${fmt(p100(r.p_fill), 0)}٪</div></span><span class="mu n">TP1 ${fmt(p100(r.p_tp1), 0)}٪</span><b class="n ${r.ev_r >= 0 ? 'up' : 'dn'}">${sg(r.ev_r, 2)}R</b></div>`).join('')}</div>` : '';
  el.innerHTML = symHead() + tfBar() + `<div class="glass card"><h2>برنامهٔ ورود و خروج</h2>${s ? `<div class="kv c3">${kv('ورود', N(fp(s.entry)))}${kv('SL', N(fp(s.stop)), 'dn')}${kv('R:R', N(fmt(s.risk_reward, 2)))}${kv('TP1', N(fp(s.tp1)), 'up')}${kv('TP2', N(fp(s.tp2)), 'up')}${kv('TP3', N(fp(s.tp3)), 'up')}</div>` : `<p class="note">نتیجهٔ نهایی «صبر» است؛ برنامهٔ ورود صادر نمی‌شود. جدول‌های زیر فقط برای بررسی دو سمت هستند.</p>`}
  ${g(d, 'entry_zone.lo', null) ? `<div class="note">ناحیهٔ ورود بهتر: <b class="n" dir="ltr">${fp(d.entry_zone.lo)} – ${fp(d.entry_zone.hi)}</b> (${esc(d.entry_zone.note || '')})</div>` : ''}${d.trail ? `<div class="note">حد متحرک Chandelier: <b class="n">${fp(d.trail)}</b></div>` : ''}${(d.tp_notes || []).map(x => `<div class="note am">• ${esc(x)}</div>`).join('')}</div>
  <div class="glass card"><h2>مراجع خروج و تثبیت سود</h2><div class="kv c3">${kv('VWAP', N(fp(rf.vwap)))}${kv('+۱σ', N(fp(rf.vwap_u1)), 'dn')}${kv('+۲σ', N(fp(rf.vwap_u2)), 'dn')}${kv('−۱σ', N(fp(rf.vwap_l1)), 'up')}${kv('−۲σ', N(fp(rf.vwap_l2)), 'up')}${kv('میانهٔ رگرسیون', N(fp(rf.lr_mid)))}${kv('کران بالا', N(fp(rf.lr_upper)), 'dn')}${kv('کران پایین', N(fp(rf.lr_lower)), 'up')}</div></div>${tbl('روش‌های ورود LONG', rows('long'))}${tbl('روش‌های ورود SHORT', rows('short'))}`;
} };

/* ═════════ forecast per timeframe ═════════ */
V['lab:fc'] = { needs: ['rep'], live: true, paint(el) {
  const d = repGuard(el, false); if (!d) { el.innerHTML = symHead() + el.innerHTML; return; }
  el.innerHTML = symHead() + `<div class="glass card"><h2>پیش‌بینی هر تایم‌فریم</h2>${d.tfs.map(t => { const c = d.per_tf[t].sections.forecast; return `<div class="ix ${c.score >= 14 ? 'up' : c.score <= -14 ? 'dn' : ''}"><div class="h"><b>${t}</b>${sdp(c.side)}<span class="nm"></span><b class="n">${sg(c.score, 0)}</b></div><div class="t">${esc(c.text)}</div>${(c.facts || []).map(f => `<div class="t">• ${esc(f)}</div>`).join('')}</div>`; }).join('')}</div>
  ${d.backtest ? `<div class="glass card"><h2>بک‌تست ${esc(d.primary_tf)}</h2><div class="kv c3">${kv('معاملات', N(d.backtest.n))}${kv('نرخ برد', N(num(d.backtest.win_rate) ? fmt(p100(d.backtest.win_rate), 0) + '٪' : '—'))}${kv('میانگین R', N(sg(d.backtest.avg_r, 2)), H.pcls(d.backtest.avg_r))}${kv('PF', N(fmt(d.backtest.pf, 2)))}${kv('افت R', N(fmt(d.backtest.max_dd_r, 1)), 'dn')}${kv('معنادار', d.backtest.significant ? 'بله' : 'خیر')}</div></div>` : ''}
  <div class="acts"><button class="btn o" data-go="ana:fc">نمودار پیش‌بینی</button><button class="btn o" data-go="ana:bt">بک‌تست کامل</button></div>`;
} };

/* ═════════ microstructure ═════════ */
V['lab:mic'] = { needs: ['rep', 'micro'], live: true, paint(el) {
  const d = repGuard(el, false); const m = cur('micro'); if (!d) { el.innerHTML = symHead() + el.innerHTML; return; } const dp = g(m, 'depth', {}), dv = g(m, 'derivs', {});
  el.innerHTML = symHead() + `<div class="glass card"><h2>نظر ریزساختار <small>${sg(d.micro.score, 0)}</small></h2>${H.meter(d.micro.score)}<p class="note">${esc(d.micro.text)}</p>${(d.micro.facts || []).map(f => `<div class="step"><b class="n">•</b><span>${esc(f)}</span></div>`).join('') || empty('داده‌ای نیست')}</div>
  ${dp.ok ? `<div class="glass card"><h2>دفتر سفارش</h2><div class="kv c3">${kv('بهترین خرید', N(fp(dp.bid)))}${kv('بهترین فروش', N(fp(dp.ask)))}${kv('اسپرد', N(fmt(dp.spread_pct, 3) + '٪'))}${kv('عمق خرید ۱٪', N('$' + fmt(dp.bid_usd_1pct, 0)))}${kv('عمق فروش ۱٪', N('$' + fmt(dp.ask_usd_1pct, 0)))}${kv('عدم‌توازن', N(sg(dp.imb_1pct * 100, 0) + '٪'), H.pcls(dp.imb_1pct))}</div></div>` : ''}
  ${dv.ok ? `<div class="glass card"><h2>مشتقات</h2><div class="kv c3">${kv('فاندینگ', N(fmt(dv.funding_pct, 4) + '٪'))}${kv('APR', N(fmt(dv.funding_apr, 0) + '٪'))}${kv('OI', N('$' + fmt(dv.oi_usd / 1e6, 0) + 'M'))}${kv('لانگ', N(num(dv.ls_buy) ? fmt(dv.ls_buy <= 1 ? dv.ls_buy * 100 : dv.ls_buy, 0) + '٪' : '—'))}${kv('بیس', N(fmt(dv.basis_pct, 3) + '٪'))}${kv('گردش ۲۴س', N('$' + fmt(dv.turnover_24h / 1e6, 0) + 'M'))}</div></div>` : ''}`;
} };

/* ═════════ new analysis pages ═════════ */
V['ana:x10'] = { needs: ['coin'], live: true, paint(el) {
  const s = SIG(); if (!s) { el.innerHTML = symHead() + `<div class="glass card">${noData(cur('coin'), 'signal') || loading}</div>`; return; } const x = g(s, 'extras.x10', null);
  if (!x || !x.items) { el.innerHTML = symHead() + `<div class="glass card">${empty('داده کافی نیست')}</div>`; return; }
  el.innerHTML = symHead() + tfBar() + `<div class="glass card"><h2>۱۰ شاخص تکمیلی هسته <small>${x.bull} صعودی · ${x.bear} نزولی</small></h2><div class="fgrid"><div><div class="mu" style="font-size:.74rem">کیفیت بازار <b class="n">${fmt(x.quality, 0)}</b></div>${H.m100(x.quality)}</div><div><div class="mu" style="font-size:.74rem">زمان‌بندی ورود <b class="n">${sg(x.timing, 0)}</b></div>${H.meter(x.timing)}</div></div>
  <div class="fgrid" style="margin-top:8px"><div><div class="mu" style="font-size:.74rem">جریان مشارکت <b class="n">${sg(x.flow, 0)}</b></div>${H.meter(x.flow)}</div><div><div class="mu" style="font-size:.74rem">امتیاز کل شاخص‌ها <b class="n">${sg(x.score, 0)}</b></div>${H.meter(x.score)}</div></div><p class="note">${esc(x.quality_label)} · ${esc(x.timing_label)}</p><p class="note">این شاخص‌ها در امتیاز سیگنال، اطمینان، ناحیهٔ ورود، حد متحرک و دروازه‌های ترید خودکار دخیل‌اند. برای توضیح هر شاخص روی آن بزنید.</p></div>${x10Cards(x)}`;
} };

V['ana:flow'] = { needs: ['coin'], live: true, paint(el) {
  const s = SIG(); if (!s) { el.innerHTML = symHead() + `<div class="glass card">${loading}</div>`; return; } const e = s.extras || {}, fl = e.flow || {}, vp = e.vp || {}, st = e.stats || {}, ic_ = e.ichimoku || {}, I = s.indicators || {};
  const bins = vp.bins || [], mx = Math.max(1e-9, ...bins.map(b => b.v)), px = g(R(ST.sel), 'ticker.price', null);
  el.innerHTML = symHead() + tfBar() + `<div class="glass card"><h2>جریان پول</h2><div class="kv c3">${kv('سهم خرید', N(num(fl.buy_share) ? fmt(fl.buy_share * 100, 0) + '٪' : '—'))}${kv('حجم نسبی', N(fmt(fl.rel_vol, 2) + '×'))}${kv('حجم ۵ کندل', N(fmt(fl.rel_vol5, 2) + '×'))}${kv('شیب CVD', N(sg(fl.cvd_slope, 2)), H.pcls(fl.cvd_slope))}${kv('واگرایی CVD', fl.div ? (fl.div === 'bull' ? 'صعودی' : 'نزولی') : 'ندارد')}${kv('واگرایی OBV', fl.obv_div ? (fl.obv_div === 'bull' ? 'صعودی' : 'نزولی') : 'ندارد')}</div>${(fl.cvd || []).length > 2 ? `<div style="direction:ltr;margin-top:8px">${T.spark(fl.cvd, 300, 56).replace(/width="300" height="56"/, 'style="width:100%;height:64px"')}</div>` : ''}</div>
  <div class="glass card"><h2>پروفایل حجم <small>POC ${fp(vp.poc)}</small></h2><div class="kv c3">${kv('POC', N(fp(vp.poc)))}${kv('VAH', N(fp(vp.vah)), 'dn')}${kv('VAL', N(fp(vp.val)), 'up')}</div>${bins.length ? `<div style="margin-top:8px;direction:ltr">${bins.slice().reverse().map(b => `<div style="display:flex;align-items:center;gap:6px;height:9px"><span class="n mu" style="width:56px;font-size:.55rem">${fp(b.p)}</span><i style="display:block;height:7px;border-radius:3px;width:${b.v / mx * 100}%;background:${num(px) && Math.abs(b.p - px) / px < .008 ? 'var(--acc)' : 'var(--info)'};opacity:.75"></i></div>`).join('')}</div>` : ''}</div>
  <div class="glass card"><h2>ایچیموکو</h2><div class="kv c3">${kv('تنکان', N(fp(ic_.tenkan)))}${kv('کیجون', N(fp(ic_.kijun)))}${kv('ابر بالا', N(fp(ic_.cloud_top)))}${kv('ابر پایین', N(fp(ic_.cloud_bot)))}${kv('موقعیت', ic_.pos > 0 ? 'بالای ابر' : ic_.pos < 0 ? 'زیر ابر' : 'داخل ابر', ic_.pos > 0 ? 'up' : ic_.pos < 0 ? 'dn' : 'am')}${kv('ابر آینده', ic_.future_bull ? 'صعودی' : 'نزولی', ic_.future_bull ? 'up' : 'dn')}</div></div>
  <div class="glass card"><h2>آمار بازده و رفتار قیمت</h2><div class="kv c3">${kv('صدک نوسان', N(fmt(st.vol_pct, 2)))}${kv('میانگین رنج', N(fmt(st.avg_range_pct, 2) + '٪'))}${kv('چولگی', N(fmt(st.skew, 2)))}${kv('کشیدگی', N(fmt(st.kurt, 2)))}${kv('خودهمبستگی', N(fmt(st.ac1, 2)))}${kv('نسبت واریانس', N(fmt(st.vr4, 2)))}${kv('رفتار', esc(st.hurst_hint || '—'))}${kv('نسبت صعودی', N(num(st.up_ratio) ? fmt(st.up_ratio * 100, 0) + '٪' : '—'))}${kv('موقعیت در رنج', N(num(st.range_pos) ? fmt(st.range_pos * 100, 0) + '٪' : '—'))}${kv('افت از سقف', N(fmt(st.dd_from_high, 1) + '٪'), 'dn')}${kv('بهترین کندل', N(pc(st.best_pct)), 'up')}${kv('بدترین کندل', N(pc(st.worst_pct)), 'dn')}</div></div>
  <div class="glass card"><h2>اندیکاتورهای خام</h2><div class="kv c3">${['adx', 'pdi', 'mdi', 'rsi', 'mfi', 'cmf', 'srsi_k', 'stoch_k', 'roc10', 'obv_slope', 'vol_ratio', 'bb_pos', 'atr_pct', 'supertrend', 'vwap', 'ema21', 'ema50', 'donch_hi', 'donch_lo'].map(k => kv(k.toUpperCase(), N(num(I[k]) ? fmt(I[k], Math.abs(I[k]) >= 100 ? 2 : 3) : '—'))).join('')}</div></div>`;
} };

V['ana:comp'] = { needs: ['coin'], live: true, paint(el) {
  const s = SIG(); if (!s) { el.innerHTML = symHead() + `<div class="glass card">${loading}</div>`; return; } const GN = { trend: 'روند', momentum: 'مومنتوم', volume: 'حجم', structure: 'ساختار', revert: 'بازگشت به میانگین', volatility: 'نوسان', pattern: 'الگو', flow: 'جریان', other: 'سایر' }, by = {};
  (s.components || []).forEach(c => (by[c.g || 'other'] = by[c.g || 'other'] || []).push(c));
  el.innerHTML = symHead() + tfBar() + `<div class="glass card"><h2>همهٔ مولفه‌های سیگنال <small>${(s.components || []).length} مولفه</small></h2><p class="note">هر مولفه یک رای بین −۱ و +۱ با وزن مشخص دارد؛ مولفه‌ها در گروه‌های مستقل جمع می‌شوند تا یک اطلاعات دوبار شمرده نشود.</p></div>${Object.entries(by).map(([k, l]) => `<div class="glass card"><h2>${esc(GN[k] || k)} <small>${l.length}</small></h2>${l.sort((a, b) => Math.abs(b.s * b.w) - Math.abs(a.s * a.w)).map(c => `<div class="row"><span class="g">${esc(c.n)}<div class="mu" style="font-size:.7rem">${esc(c.t || '')}</div></span><span class="mu n" style="width:30px">×${fmt(c.w, 1)}</span><span style="width:70px">${bar(50 + (c.s || 0) * 50, (c.s || 0) > 0 ? '' : 'dn', 1)}</span></div>`).join('')}</div>`).join('')}`;
} };

V['ana:evid'] = { needs: ['ev'], live: true, paint(el) {
  const ev = cur('ev'); if (!ev) { el.innerHTML = `<div class="glass card">${loading}</div>`; return; } const rows = ev.rows || {}, a = ev.agg || null, l = Object.entries(rows).filter(([, v]) => v && v.n != null).sort((x, y) => (y[1].avg_r || 0) - (x[1].avg_r || 0));
  el.innerHTML = (a ? `<div class="glass card"><h2>شواهد همهٔ ارزها</h2><div class="kv c3">${kv('معاملات', N(a.trades))}${kv('نرخ برد', N(fmt(a.win, 1) + '٪'))}${kv('میانگین R', N(sg(a.avg_r, 2)), H.pcls(a.avg_r))}${kv('ارز مثبت', N(a.positive + '/' + a.coins))}${kv('معنادار', N(a.significant))}</div></div>` : '') + `<div class="glass card"><h2>شواهد بک‌تست هر ارز <small>${l.length}</small></h2>${l.map(([s, v]) => `<div class="row" data-sheet="${esc(s)}" style="cursor:pointer"><span class="g"><b>${esc(base(s))}</b><div class="mu" style="font-size:.7rem">${v.n} معامله · برد ${num(v.win) ? fmt(v.win <= 1 ? v.win * 100 : v.win, 0) : '—'}٪</div></span><b class="n ${H.pcls(v.avg_r)}">${sg(v.avg_r, 2)}R</b></div>`).join('') || empty('هنوز شواهدی محاسبه نشده؛ پس از اسکن کامل ظاهر می‌شود')}</div>`;
} };

/* ═════════ markets: ranking ═════════ */
ST.rk = ST.rk || { k: 'cons', d: -1 };
V['mkt:rank'] = { needs: ['matrix', 'status'], live: true, paint(el) {
  const rows = syms().map(s => ({ s, r: R(s) })).filter(x => x.r); if (!rows.length) { el.innerHTML = `<div class="glass card">${loading}</div>`; return; }
  const val = { cons: x => x.r.cons, chg: x => g(x.r, 'ticker.change_pct', 0), grade: x => 'DCBA'.indexOf(x.r.grade || 'D'), q: x => g(x.r, 'tfs.1h.quality', 0), tm: x => g(x.r, 'tfs.1h.timing', 0), ev: x => g(x.r, 'tfs.1h.ev_r', 0), btc: x => g(x.r, 'corr', 0), rs: x => g(x.r, 'rs24', 0), vol: x => g(x.r, 'ticker.quote_volume', 0), atr: x => g(x.r, 'tfs.1h.atr_pct', 0) }[ST.rk.k] || (x => 0);
  rows.sort((a, b) => (val(b) - val(a)) * -ST.rk.d);
  const th = (k, n) => `<th data-rk="${k}" style="cursor:pointer;${ST.rk.k === k ? 'color:var(--acc)' : ''}">${n}${ST.rk.k === k ? (ST.rk.d < 0 ? '▼' : '▲') : ''}</th>`;
  el.innerHTML = `<div class="glass card"><h2>رتبه‌بندی ارزها <small>روی سرستون بزنید</small></h2><div class="mxw"><table class="tbl"><tr class="sortable"><th style="text-align:left">ارز</th>${th('cons', 'اجماع')}${th('grade', 'درجه')}${th('chg', 'تغییر')}${th('q', 'کیفیت')}${th('tm', 'تایمینگ')}${th('ev', 'EV')}${th('rs', 'RS')}${th('btc', 'BTC')}${th('atr', 'ATR')}${th('vol', 'حجم')}</tr>
  ${rows.map(({ s, r }) => { const t = r.tfs && r.tfs['1h'] || {}, tk = r.ticker || {}; return `<tr data-sheet="${esc(s)}" style="cursor:pointer"><td>${esc(base(s))} ${sdp(sideOf(r))}</td><td style="${H.scoreCell(r.cons)}">${sg(r.cons, 0)}</td><td>${esc(r.grade || '—')}</td><td class="${H.pcls(tk.change_pct)}">${pc(tk.change_pct)}</td><td>${num(t.quality) ? fmt(t.quality, 0) : '—'}</td><td class="${H.pcls(t.timing)}">${num(t.timing) ? sg(t.timing, 0) : '—'}</td><td class="${H.pcls(t.ev_r)}">${num(t.ev_r) ? sg(t.ev_r, 2) : '—'}</td><td>${num(r.rs24) ? sg(r.rs24, 1) : '—'}</td><td>${num(r.corr) ? fmt(r.corr, 2) : '—'}</td><td>${num(t.atr_pct) ? fmt(t.atr_pct, 2) : '—'}</td><td>$${fmt((tk.quote_volume || 0) / 1e6, 0)}M</td></tr>`; }).join('')}</table></div></div>`;
} };
T.ACT = T.ACT || {};
T.DATA = T.DATA || {};
T.ACT.rk = T.DATA.rk = (el, d) => { ST.rk = { k: d.rk, d: ST.rk.k === d.rk ? -ST.rk.d : -1 }; V['mkt:rank'].paint($('#page')); };
})();
