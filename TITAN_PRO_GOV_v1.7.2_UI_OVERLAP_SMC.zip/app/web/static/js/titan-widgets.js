/* TITAN AI — dashboard shell, shared UI helpers (T.H) and every dashboard widget */
(function () {
'use strict';
const { $, $$, g, num, fmt, fp, sg, pc, usd, p100, N, cls, FA, tag, ago, coin, kv, bar, empty, loading, noData, esc, ic, cur, ST, R, syms, sideOf, SIG, ATF } = T;
const W = T.W, base = s => String(s).replace('USDT', '');
const sdp = s => `<span class="sd sm ${esc(s)}">${FA[s] || esc(s)}</span>`;

/* ── shared helpers ── */
const H = T.H = {
  sc: v => !num(v) ? '' : v >= 14 ? 'up' : v <= -14 ? 'dn' : 'am',
  chip: (t, c) => `<span class="chipx ${c || ''}">${t}</span>`,
  /* bi-directional meter: score -100..100, marker at position */
  meter: v => { const x = num(v) ? Math.max(-100, Math.min(100, v)) : 0, pos = 50 + x / 2, l = x >= 0 ? 50 : pos, w = Math.abs(x) / 2, c = x >= 0 ? 'rgba(33,230,90,.75)' : 'rgba(255,59,78,.75)'; return `<div class="meter bi"><i style="left:${l}%;width:${w}%;background:${c}"></i><span class="mk" style="left:${pos}%"></span></div>`; },
  /* 0..100 meter */
  m100: (v, good) => { const x = num(v) ? Math.max(0, Math.min(100, v)) : 0, c = good === false ? 'var(--dn)' : x >= 65 ? 'var(--up)' : x >= 40 ? 'var(--am)' : 'var(--dn)'; return `<div class="meter"><i style="left:0;width:${x}%;background:${c}"></i></div>`; },
  side: s => `<span class="sd sm ${esc(s)}">${FA[s] || (s === 'STATE' ? '—' : esc(s))}</span>`,
  scoreCell: v => { const x = num(v) ? v : 0, a = Math.min(1, Math.abs(x) / 70); return `background:${x >= 0 ? `rgba(33,230,90,${.08 + a * .5})` : `rgba(255,59,78,${.08 + a * .5})`}`; },
  head: (t, sm, go) => `<h2>${t}${sm ? ` <small>${sm}</small>` : ''}${go ? `<button class="btn s o" style="margin-inline-start:auto" data-go="${go}">بیشتر</button>` : ''}</h2>`,
  guard: (d, el, k) => { const e = noData(d, k); if (e) { el.innerHTML = `<div class="glass card">${e}</div>`; return true; } return false; },
  lvl: (a, b) => `${fp(a)}${b != null ? ' – ' + fp(b) : ''}`,
  pcls: v => !num(v) ? '' : v >= 0 ? 'up' : 'dn'
};

/* ── dashboard shell: ordered, sized, visible widgets ── */
T.dashShell = function (el) {
  const P = T.P; el.className = 'dash';
  el.innerHTML = P.widgets.filter(w => !P.hidden.includes(w) && W[w]).map(w => `<div data-w="${w}" class="w-${T.wsize(w)}"></div>`).join('');
};
T.dashNeeds = () => { const s = new Set(['ev']); (T.P.widgets || []).forEach(w => { if (!T.P.hidden.includes(w) && W[w]) W[w].needs.forEach(n => s.add(n)); }); return [...s]; };

const skel = '<div class="glass card"><span class="sk"></span><span class="sk" style="margin-top:8px;width:60%"></span></div>';
const wrap = (el, inner) => { el.innerHTML = `<div class="glass card">${inner}</div>`; };

/* ── signal card ── */
W.sigcard = { needs: ['coin', 'matrix'], paint(el) {
  const s = SIG(), r = R(ST.sel); if (!s) { el.innerHTML = skel; return; }
  const lv = s.levels || {}, side = s.side, ez = lv.entry_zone || {}, d = side === 'LONG' ? 1 : -1, risk = num(s.entry) && num(s.stop) ? Math.abs(s.entry - s.stop) / s.entry * 100 : null;
  wrap(el, `${H.head('جزئیات سیگنال ' + esc(base(ST.sel)), `${esc(T.atf())}`, 'ana:sig')}
  <div class="row" style="border:0;padding:0 0 6px"><span class="g">${sdp(side)} <span class="tag">درجه ${esc(g(r, 'grade', '—'))}</span> <span class="tag">${esc(({ trend: 'روندی', range: 'رنج', neutral: 'گذار' })[s.regime] || s.regime || '')}</span></span><b class="n ${cls(side)}">${num(s.score) ? sg(s.score, 0) : '—'}</b></div>
  ${H.meter(s.score)}
  ${side !== 'WAIT' ? `<div class="kv c3" style="margin-top:10px">${kv('ورود', N(fp(s.entry)))}${kv('حد ضرر', N(fp(s.stop)), 'dn')}${kv('R:R', N(fmt(s.risk_reward, 2)))}${kv('TP1', N(fp(s.tp1)), 'up')}${kv('TP2', N(fp(s.tp2)), 'up')}${kv('TP3', N(fp(s.tp3)), 'up')}</div>
  <div class="kv c3" style="margin-top:6px">${kv('اطمینان', N(fmt(p100(s.confidence), 0) + '٪'))}${kv('ریسک تا SL', N(num(risk) ? fmt(risk, 2) + '٪' : '—'), 'am')}${kv('حد متحرک', N(num(lv.trail) ? fp(lv.trail) : '—'), 'am')}</div>
  ${ez.lo ? `<div class="note">ناحیهٔ ورود بهتر: <b class="n" dir="ltr">${fp(ez.lo)} – ${fp(ez.hi)}</b> · ${esc(ez.note || '')}</div>` : ''}` : `<div class="note">${esc(s.summary || 'در حال حاضر سیگنال ورود وجود ندارد؛ منتظر هم‌سویی بیشتر بمانید.')}</div>`}
  <div class="chips">${num(lv.quality) ? H.chip('کیفیت ' + fmt(lv.quality, 0), lv.quality >= 60 ? 'up' : lv.quality >= 40 ? 'am' : 'dn') : ''}${num(lv.timing) ? H.chip('زمان‌بندی ' + sg(lv.timing, 0), H.sc(lv.timing * d)) : ''}${(s.warnings || []).slice(0, 3).map(w => H.chip(esc(w), 'am')).join('')}</div>`);
} };

/* ── deep analysis summary ── */
W.lab = { needs: ['rep'], paint(el) {
  const d = cur('rep'); if (!d) { el.innerHTML = skel; return; } if (d.error || d.ok === false) { wrap(el, `${H.head('تحلیل عمیق')}${noData(d.error ? d : { error: 'داده کافی نیست' })}`); return; }
  wrap(el, `${H.head('نتیجهٔ تحلیل عمیق ' + esc(base(d.symbol)), `درجه ${esc(d.grade)}`, 'lab:sum')}
  <div class="row" style="border:0;padding:0"><span class="g">${sdp(d.final)} <span class="chipx am">${esc(d.action)}</span></span><b class="n">${fmt(d.confidence * 100, 0)}٪ اطمینان</b></div>
  ${H.meter(d.unified_score)}
  <div class="chips">${(d.horizons || []).map(h => `<span class="tag ${h.side}" data-go="lab:tf">${esc(h.tf)} ${FA[h.side] || ''} ${sg(h.score, 0)}</span>`).join('')}</div>
  <p class="note">${esc((d.narrative || [])[0] || '')} ${esc((d.narrative || [])[2] || '')}</p>`);
} };

/* ── multi-timeframe strip ── */
W.mtf = { needs: ['matrix'], paint(el) {
  const r = R(ST.sel); if (!r) { el.innerHTML = skel; return; }
  wrap(el, `${H.head('چندتایم‌فریم', esc(base(ST.sel)), 'ana:tf')}${ATF.map(t => { const x = g(r, 'tfs.' + t, null); return x ? `<div class="row" data-hs="${esc(ST.sel)}|${t}" style="cursor:pointer"><b style="width:34px">${t}</b>${sdp(x.side)}<span class="g">${H.meter(x.score)}</span><span class="n ${cls(x.side)}" style="width:34px;text-align:left">${sg(x.score, 0)}</span></div>` : ''; }).join('')}
  <div class="kv c3" style="margin-top:8px">${kv('اجماع', N(sg(r.cons, 0)), H.pcls(r.cons))}${kv('هم‌جهتی', N(g(r, 'aligned', '—')))}${kv('درجه', esc(r.grade || '—'))}</div>`);
} };

/* ── x10 ── */
W.x10 = { needs: ['coin'], paint(el) {
  const s = SIG(), x = g(s, 'extras.x10', null); if (!s) { el.innerHTML = skel; return; } if (!x || !x.items) { wrap(el, `${H.head('۱۰ شاخص تکمیلی')}${empty('داده کافی نیست')}`); return; }
  wrap(el, `${H.head('۱۰ شاخص تکمیلی', `${x.bull} صعودی · ${x.bear} نزولی`, 'ana:x10')}
  <div class="fgrid"><div><div class="mu" style="font-size:.74rem">کیفیت بازار <b class="n">${fmt(x.quality, 0)}</b></div>${H.m100(x.quality)}</div><div><div class="mu" style="font-size:.74rem">زمان‌بندی ورود <b class="n">${sg(x.timing, 0)}</b></div>${H.meter(x.timing)}</div></div>
  <div class="tgrid" style="margin-top:10px;grid-template-columns:repeat(2,1fr)">${Object.entries(x.items).map(([k, it]) => `<div class="ix ${it.s >= .25 ? 'up' : it.s <= -.25 ? 'dn' : ''}" style="margin:0;padding:8px 10px" data-info="${k}"><div class="h" style="font-size:.78rem"><span class="nm">${esc(it.n)}</span><b class="n ${H.sc(it.s * 100)}">${num(it.v) ? fmt(it.v, Math.abs(it.v) >= 10 ? 0 : 2) : '—'}</b></div></div>`).join('')}</div>
  <p class="note">${esc(x.quality_label)} · ${esc(x.timing_label)}</p>`);
} };

/* ── levels ── */
W.levels = { needs: ['coin'], paint(el) {
  const s = SIG(); if (!s) { el.innerHTML = skel; return; }
  const z = (g(s, 'levels.zones', []) || []).slice().sort((a, b) => b.p - a.p), pv = g(s, 'extras.pivots', {}), vp = g(s, 'extras.vp', {}), fb = g(s, 'extras.fib', {});
  wrap(el, `${H.head('سطوح کلیدی', '', 'ana:lvl')}${z.slice(0, 6).map(i => `<div class="row"><span class="g">${i.kind === 'R' ? '<span class="dn">مقاومت</span>' : '<span class="up">حمایت</span>'} ${i.n > 1 ? `<span class="mu">×${i.n}</span>` : ''}</span><b class="n">${fp(i.p)}</b><span class="n mu" style="width:56px;text-align:left">${pc(i.dist_pct)}</span></div>`).join('') || empty('سطحی نیست')}
  <div class="kv c3" style="margin-top:8px">${kv('پیوت', N(fp(pv.p)))}${kv('R1', N(fp(pv.r1)), 'dn')}${kv('S1', N(fp(pv.s1)), 'up')}${kv('POC', N(fp(vp.poc)))}${kv('VAH', N(fp(vp.vah)))}${kv('VAL', N(fp(vp.val)))}</div>
  ${fb.near ? `<p class="note">نزدیک فیبوناچی ${esc(fb.near.r)} (${fp(fb.near.p)})</p>` : ''}`);
} };

/* ── forecast ── */
W.fcast = { needs: ['coin'], paint(el) {
  const f = g(cur('coin'), 'forecast', null); if (!f) { el.innerHTML = skel; return; } const e = f.edge || {}, pu = p100(f.prob_up);
  wrap(el, `${H.head('پیش‌بینی و لبهٔ آماری', esc(T.atf()), 'ana:fc')}
  <div class="row" style="border:0;padding:0"><span class="g">${sdp(f.direction === 'UP' ? 'LONG' : f.direction === 'DOWN' ? 'SHORT' : 'WAIT')}</span><b class="n">${num(pu) ? fmt(pu, 0) + '٪ صعود' : '—'}</b></div>${bar(pu || 0, pu < 45 ? 'dn' : pu < 55 ? 'am' : '', 1)}
  <div class="kv c3" style="margin-top:8px">${kv('حرکت مورد انتظار', N(pc(f.expected_move_pct)), H.pcls(f.expected_move_pct))}${kv('σ', N(fmt(f.sigma_pct, 2) + '٪'))}${kv('هم‌راستایی', esc(({ aligned: 'هم‌جهت', divergent: 'مخالف' })[f.alignment] || '—'))}${kv('EV', N(sg(e.ev_r, 2) + 'R'), H.pcls(e.ev_r))}${kv('P(TP1)', N(num(e.p_tp1) ? fmt(p100(e.p_tp1), 0) + '٪' : '—'))}${kv('P(SL)', N(num(e.p_sl) ? fmt(p100(e.p_sl), 0) + '٪' : '—'), 'dn')}</div>`);
} };

/* ── flow + microstructure ── */
W.flow = { needs: ['coin', 'micro'], paint(el) {
  const s = SIG(), m = cur('micro'); if (!s) { el.innerHTML = skel; return; } const fl = g(s, 'extras.flow', {}), dp = g(m, 'depth', {}), dv = g(m, 'derivs', {});
  wrap(el, `${H.head('جریان پول و ریزساختار', '', 'ana:flow')}<div class="kv c3">${kv('سهم خرید', N(num(fl.buy_share) ? fmt(fl.buy_share * 100, 0) + '٪' : '—'), fl.buy_share > .55 ? 'up' : fl.buy_share < .45 ? 'dn' : '')}${kv('حجم نسبی', N(num(fl.rel_vol) ? fmt(fl.rel_vol, 1) + '×' : '—'))}${kv('شیب CVD', N(num(fl.cvd_slope) ? sg(fl.cvd_slope, 2) : '—'), H.pcls(fl.cvd_slope))}
  ${kv('عدم‌توازن دفتر', N(dp.ok ? sg(dp.imb_1pct * 100, 0) + '٪' : '—'), dp.ok ? H.pcls(dp.imb_1pct) : '')}${kv('اسپرد', N(dp.ok ? fmt(dp.spread_pct, 3) + '٪' : '—'))}${kv('فاندینگ', N(dv.ok ? fmt(dv.funding_pct, 3) + '٪' : '—'), dv.ok && dv.funding_pct > .05 ? 'dn' : '')}</div>
  ${dv.ok ? `<div class="kv c3" style="margin-top:6px">${kv('OI', N('$' + fmt(dv.oi_usd / 1e6, 0) + 'M'))}${kv('لانگ', N(num(dv.ls_buy) ? fmt(dv.ls_buy <= 1 ? dv.ls_buy * 100 : dv.ls_buy, 0) + '٪' : '—'))}${kv('بیس', N(num(dv.basis_pct) ? fmt(dv.basis_pct, 2) + '٪' : '—'))}</div>` : ''}${fl.div ? `<p class="note am">واگرایی ${fl.div === 'bull' ? 'صعودی' : 'نزولی'} CVD</p>` : ''}`);
} };

/* ── patterns ── */
W.pats = { needs: ['pat'], paint(el) {
  const d = cur('pat'); if (!d) { el.innerHTML = skel; return; } const rc = (d.recent || []).slice(0, 4), st = (d.structs || []).slice(0, 2);
  wrap(el, `${H.head('الگوها', esc(base(ST.sel)), 'ana:pat')}${[...st.map(x => `<div class="row"><span class="g"><b>${esc(x.fa || x.k)}</b></span>${x.target ? `<span class="n ${x.bias >= 0 ? 'up' : 'dn'}">→ ${fp(x.target)}</span>` : ''}</div>`), ...rc.map(x => `<div class="row"><span class="g"><b>${esc(x.fa || x.k)}</b></span><span class="tag ${x.bias > 0 ? 'up' : x.bias < 0 ? 'dn' : 'am'}">${x.ago} کندل پیش</span></div>`)].join('') || empty('الگوی معناداری نیست')}`);
} };

/* ── exchange summary with the auto switch ── */
W.acct = { needs: ['acct'], paint(el) {
  const a = cur('acct'); if (!a) { el.innerHTML = skel; return; } if (a.error) { wrap(el, noData(a)); return; }
  wrap(el, `${H.head('صرافی کاغذی', a.auto_trade ? 'خودکار روشن' : 'دستی', 'ex:pos')}
  <button class="bsw ${a.auto_trade ? 'on' : ''}" data-act="auto" aria-label="ترید خودکار"><span class="k"></span><span><b>ترید خودکار ${a.auto_trade ? 'روشن' : 'خاموش'}</b><small>${a.paused ? esc(a.pause_reason || 'متوقف شده') : a.auto_trade ? 'ورود فقط با سیگنال‌های تأییدشده' : 'برای شروع روشن کنید'}</small></span></button>
  <div class="kv c3" style="margin-top:10px">${kv('سرمایه', N(usd(a.equity)))}${kv('سود امروز', N(usd(a.day_pnl)), H.pcls(a.day_pnl))}${kv('نرخ برد', N(a.trades ? fmt(a.win_rate, 1) + '٪' : '—'))}${kv('باز', N((a.open_positions || []).length))}${kv('معلق', N((a.orders || []).length))}${kv('افت', N(fmt(a.max_drawdown_pct, 2) + '٪'), 'dn')}</div>`);
} };

W.pos = { needs: ['acct'], paint(el) {
  const a = cur('acct'); if (!a) { el.innerHTML = skel; return; } const p = a.open_positions || [];
  wrap(el, `${H.head('موقعیت‌های باز', N(p.length), 'ex:pos')}${p.slice(0, 5).map(x => `<div class="row" data-pos="${esc(x.id)}" style="cursor:pointer"><span class="g"><b>${esc(base(x.symbol))}</b> ${sdp(x.side)} <span class="tag">${esc(x.grade || '—')}</span></span><span class="n mu">${sg(x.r_now, 1)}R</span><b class="n ${H.pcls(x.unrealized)}">${usd(x.unrealized)}</b></div>`).join('') || empty('موقعیت بازی نیست')}`);
} };

W.perf = { needs: ['perf'], paint(el) {
  const p = cur('perf'); if (!p) { el.innerHTML = skel; return; }
  wrap(el, `${H.head('عملکرد و نرخ برد', N(p.n || 0) + ' معامله', 'ex:perf')}${p.n ? `<div class="kv c3">${kv('نرخ برد', N(fmt(p.win_rate, 1) + '٪'), p.win_rate >= 50 ? 'up' : 'am')}${kv('ضریب سود', N(fmt(p.pf, 2)), p.pf >= 1 ? 'up' : 'dn')}${kv('امید ریاضی', N(usd(p.expectancy)), H.pcls(p.expectancy))}${kv('میانگین R', N(sg(p.avg_r, 2)), H.pcls(p.avg_r))}${kv('سود کل', N(usd(p.total_pnl)), H.pcls(p.total_pnl))}${kv('حداکثر افت', N(fmt(p.max_dd_pct, 1) + '٪'), 'dn')}</div>
  <div style="direction:ltr;margin-top:8px">${(p.equity || []).length > 2 ? T.spark(p.equity, 300, 60).replace(/width="300" height="60"/, 'style="width:100%;height:70px"') : ''}</div>` : empty('هنوز معامله‌ای بسته نشده')}`);
} };

W.autolog = { needs: ['acct'], paint(el) {
  const a = cur('acct'); if (!a) { el.innerHTML = skel; return; } const l = (a.auto_log || []).slice(-6).reverse();
  wrap(el, `${H.head('گزارش ترید خودکار', '', 'ex:auto')}${l.map(x => `<div class="row"><span class="g" style="font-size:.8rem"><b>${esc(base(x.symbol || ''))}</b> ${esc(x.text || x.reason || x.msg || '')}</span><span class="mu" style="font-size:.7rem">${ago(x.t)}</span></div>`).join('') || empty('گزارشی نیست')}`);
} };

W.movers = { needs: ['mkt'], paint(el) {
  const m = cur('mkt'); if (!m) { el.innerHTML = skel; return; } const row = (t, a) => `<div class="sh" style="margin-top:0">${t}</div>${(a || []).slice(0, 3).map(i => `<div class="row" data-sheet="${esc(i.symbol)}" style="cursor:pointer"><span class="g"><b>${esc(i.base)}</b></span><span class="n ${H.pcls(i.chg)}">${pc(i.chg)}</span></div>`).join('') || ''}`;
  wrap(el, `${H.head('پرسودها / پرضررها', '', 'mkt:move')}${row('پرسودترین', m.gainers)}${row('پرضررترین', m.losers)}`);
} };

W.heat = { needs: ['matrix', 'status'], paint(el) {
  const l = syms().filter(s => R(s)).slice(0, 12); if (!l.length) { el.innerHTML = skel; return; }
  wrap(el, `${H.head('نقشهٔ حرارتی', '', 'mkt:heat')}<div class="heat" style="grid-template-columns:62px repeat(${ATF.length + 1},1fr)"><div style="cursor:default"></div>${ATF.map(t => `<div style="cursor:default;color:var(--mu)">${t}</div>`).join('')}<div style="cursor:default;color:var(--acc)">اجماع</div>${l.map(s => { const r = R(s); return `<div style="text-align:left;cursor:pointer" data-sheet="${esc(s)}">${esc(base(s))}</div>${ATF.map(t => { const x = g(r, 'tfs.' + t, null); return x ? `<div style="background:${T.heatColor(x.side, x.score)}" data-hs="${esc(s)}|${t}">${fmt(x.score, 0)}</div>` : '<div style="opacity:.3">—</div>'; }).join('')}<div style="background:${T.heatColor(sideOf(r), r.cons)}" data-hs="${esc(s)}|${T.atf()}">${sg(r.cons, 0)}</div>`; }).join('')}</div>`);
} };

W.alerts = { needs: ['alerts'], paint(el) {
  const d = cur('alerts'); if (!d) { el.innerHTML = skel; return; } const l = d.alerts || [], f = l.filter(x => x.fired);
  wrap(el, `${H.head('هشدارها', `${f.length} فعال‌شده از ${l.length}`, 'ai:al')}${l.slice(0, 4).map(x => `<div class="row"><span class="g"><b>${esc(base(x.symbol))}</b> ${x.type === 'price' ? (x.op === '>' ? 'بالاتر از ' : 'پایین‌تر از ') + N(fp(x.price)) : 'سیگنال ' + esc(x.min_grade)}</span><span class="tag ${x.fired ? 'am' : ''}">${x.fired ? 'فعال شد' : 'در انتظار'}</span></div>`).join('') || empty('هشداری ثبت نشده')}`);
} };

W.track = { needs: ['log', 'ev'], paint(el) {
  const l = cur('log'), ev = cur('ev'); if (!l && !ev) { el.innerHTML = skel; return; } const p = g(l, 'path', {}), a = g(ev, 'agg', null);
  wrap(el, `${H.head('کارنامه سیگنال‌ها', '', 'ai:trk')}<div class="kv c3">${kv('ثبت‌شده', N(g(l, 'total', 0)))}${kv('نتیجه‌دار', N(g(l, 'resolved', 0)))}${kv('TP1', N(num(p.tp1_rate) ? fmt(p100(p.tp1_rate), 0) + '٪' : '—'), 'up')}${a ? kv('برد بک‌تست', N(fmt(a.win, 1) + '٪')) + kv('میانگین R', N(sg(a.avg_r, 2)), H.pcls(a.avg_r)) + kv('ارز مثبت', N(a.positive + '/' + a.coins)) : ''}</div>`);
} };

W.sys = { needs: ['status'], paint(el) {
  const st = cur('status'); if (!st) { el.innerHTML = skel; return; }
  wrap(el, `${H.head('وضعیت سیستم', 'v' + esc(st.version || ''), 'more:sys')}<div class="kv c3">${kv('آخرین اسکن', st.last_scan ? esc(ago(st.last_scan)) : '—')}${kv('مدت اسکن', N(fmt(st.duration, 1) + 's'))}${kv('ارزها', N((st.symbols || []).length))}</div><div class="chips">${Object.entries(st.sources || {}).map(([k, v]) => `<span class="tag ${v && v.ok === false ? 'dn' : 'up'}">${esc(k)}</span>`).join('')}</div>`);
} };
/* ── v3.3: market context (derivatives / order book / sentiment) and forward-evaluation readiness ── */
W.ctx = { needs: ['ctx'], paint(el) {
  const c = cur('ctx'); if (!c) { el.innerHTML = skel; return; }
  if (c.error) { wrap(el, `${H.head('بافت بازار', esc(base(ST.sel)))}<p class="note">${esc(c.error)}</p>`); return; }
  const b = num(c.bias) ? c.bias : 0, lq = c.liq || {};
  const parts = (c.parts || []).slice().sort((x, y) => Math.abs(y.v * y.w) - Math.abs(x.v * x.w)).map(p => `<div class="row"><span class="g">${esc(p.t)}</span><span class="n ${H.pcls(p.v)}">${p.v > 0 ? '+' : ''}${fmt(p.v, 2)}</span></div>`).join('') || '<p class="note">برای این ارز داده‌ای از مشتقات/دفتر سفارش در دسترس نیست؛ سوگیری صفر و بدون اثر بر سیگنال است.</p>';
  const fg = num(c.fng) ? `${N(c.fng)} ${esc(c.fng_label || '')}` : '—';
  wrap(el, `${H.head('بافت بازار', esc(base(ST.sel)))}${H.meter(b * 100)}<p class="note" style="margin:4px 0 8px">سوگیری ${b >= 0 ? '+' : ''}${fmt(b, 2)} · ${b >= .2 ? 'به نفع خرید' : b <= -.2 ? 'به نفع فروش' : 'خنثی'} · پوشش داده ${num(c.coverage) ? fmt(c.coverage * 100, 0) : 0}٪ — این عدد در اجماع و درجهٔ سیگنال و دروازه‌های ترید خودکار اثر دارد.</p>
  <div class="kv c3">${kv('فاندینگ سالانه', num(c.funding_apr) ? N(fmt(c.funding_apr, 0) + '٪') : '—')}${kv('تغییر OI ۲۴س', num(c.oi_chg_24h) ? N(fmt(c.oi_chg_24h, 1) + '٪') : '—')}${kv('حساب‌های لانگ', num(c.ls_buy) ? N(fmt(c.ls_buy * 100, 0) + '٪') : '—')}${kv('ترس/طمع', fg)}${kv('دامیننس BTC', num(c.btc_dom) ? N(fmt(c.btc_dom, 1) + '٪') : '—')}${kv('اسپرد / عمق ±۱٪', num(lq.spread_pct) ? N(fmt(lq.spread_pct, 3) + '٪ · $' + fmt((lq.depth_usd || 0) / 1000, 0) + 'k') : '—')}</div>
  ${lq.ok === false ? '<p class="note" style="color:var(--dn)">نقدینگی/اسپرد نامناسب: ورود خودکار مسدود است.</p>' : ''}<div class="sh">دلایل (به ترتیب اثر)</div>${parts}`);
} };
W.ready = { needs: ['ready'], paint(el) {
  const r = cur('ready'); if (!r) { el.innerHTML = skel; return; }
  if (r.error) { wrap(el, `${H.head('ارزیابی فوروارد')}<p class="note">${esc(r.error)}</p>`); return; }
  const p = r.paper || {}, st = p.stats || {}, v = p.verdict || {}, sg = (r.signals || {}).path || {}, ci = st.ci95 || [null, null];
  const lvl = v.level === 'candidate' ? 'up' : v.level === 'promising' ? 'am' : v.level === 'not_ready' ? 'dn' : '';
  wrap(el, `${H.head('ارزیابی فوروارد', 'معاملات بستهٔ کاغذی', 'more:perf')}<div class="chips">${H.chip(esc(v.fa || '—'), lvl)}</div><p class="note" style="margin:6px 0">${esc(v.why || '')}</p>
  <div class="kv c3">${kv('تعداد معامله', N(st.n || 0))}${kv('میانگین R', st.n ? N((st.mean >= 0 ? '+' : '') + fmt(st.mean, 2)) : '—')}${kv('t-stat', st.n ? N(fmt(st.t, 2)) : '—')}${kv('بازه ۹۵٪', num(ci[0]) ? N(fmt(ci[0], 2) + ' تا ' + fmt(ci[1], 2)) : '—')}${kv('PF', st.n ? N(fmt(st.pf, 2)) : '—')}${kv('افت حداکثر', st.n ? N(fmt(st.max_dd, 1) + 'R') : '—')}</div>
  <p class="note">سیگنال‌ها: TP1 قبل از حدضرر ${N(sg.tp1 || 0)} از ${N((sg.tp1 || 0) + (sg.sl || 0))}. ${esc(r.rules || '')}</p>`);
} };

/* ── x11 structure ── */
W.learn = { needs: ['learn'], paint(el) {
  const d = cur('learn');
  if (!d) { el.innerHTML = skel; return; }
  if (d.error) { el.innerHTML = `<div class="glass card">${H.head('یادگیری حاکم')}<div class="empty err">${esc(d.error)}</div></div>`; return; }
  const rel = d.reliability || {};
  const g = d.global || {};
  const ready = !!d.ready;
  const n = d.n_resolved || 0;
  const keys = Object.keys(rel).sort((a, b) => Math.abs(rel[b] - 1) - Math.abs(rel[a] - 1));
  const rows = keys.map(k => {
    const v = +rel[k] || 1;
    const pct = Math.round((v - 0.72) / (1.38 - 0.72) * 100);
    const cls = v >= 1.08 ? 'up' : v <= 0.92 ? 'dn' : 'am';
    const bar = H.m100(Math.max(0, Math.min(100, (v - 0.72) / 0.66 * 100)));
    return `<div class="kv-row" style="display:flex;align-items:center;gap:8px;margin:4px 0"><span style="min-width:92px;font-size:.78rem;opacity:.85">${esc(k)}</span><div style="flex:1">${bar}</div><span class="n ${cls}" style="min-width:42px;text-align:start">${v.toFixed(2)}</span></div>`;
  }).join('');
  const win = g.n ? Math.round((g.wins / g.n) * 100) : null;
  el.innerHTML = `<div class="glass card">${H.head('یادگیری حاکم', ready ? 'فعال' : 'در انتظار نمونه')}
  <div class="kv c3">${kv('نمونه‌های resolve', N(n))}${kv('نرخ برد', win != null ? win + '٪' : '—', win >= 55 ? 'up' : win != null && win < 45 ? 'dn' : '')}${kv('وضعیت', ready ? 'کالیبره' : 'خنثی')}</div>
  <div style="margin-top:8px;max-height:220px;overflow:auto">${rows || '<div class="empty">هنوز داده‌ای نیست</div>'}</div>
  <div class="muted" style="font-size:.72rem;margin-top:6px;opacity:.7">ضریب reliability هر خانواده شواهد از نتیجه واقعی سیگنال‌ها (SL/TP یا ۴س) تنظیم می‌شود. بازه امن ۰.۷۲–۱.۳۸</div>
  </div>`;
}},


W.x11 = { needs: ['coin'], paint(el) {
  const s = SIG(), x = g(s, 'extras.x11', null); if (!s) { el.innerHTML = skel; return; }
  if (!x || !x.items) { wrap(el, `${H.head('ساختار و مشارکت (x11)')}${empty('داده کافی نیست')}`); return; }
  const items = Object.entries(x.items);
  wrap(el, `${H.head('ساختار و مشارکت x11', `${items.length} مورد`, 'ana:x11')}
  <div class="kv c3">${items.map(([k, it]) => kv(esc(it.n || k), N(it.v != null ? it.v : '—'), (it.s || 0) > 0.15 ? 'up' : (it.s || 0) < -0.15 ? 'dn' : '')).join('')}</div>
  <div class="note" style="margin-top:8px">${items.map(([, it]) => esc(it.t || '')).filter(Boolean).slice(0, 4).join(' · ')}</div>`);
} };

/* ── x12 complementary ── */
W.x12 = { needs: ['coin'], paint(el) {
  const s = SIG(), x = g(s, 'extras.x12', null); if (!s) { el.innerHTML = skel; return; }
  if (!x || !x.items) { wrap(el, `${H.head('۱۰ شاخص تکمیلی x12')}${empty('داده کافی نیست')}`); return; }
  const items = Object.entries(x.items);
  wrap(el, `${H.head('۱۰ شاخص تکمیلی x12', `${esc(x.label || '')} · ${x.bull || 0}↑ ${x.bear || 0}↓`, 'ana:x12')}
  <div class="kv c3">${items.map(([k, it]) => `<div><span class="mu" style="font-size:.68rem">${esc(it.role_fa || it.role || '')}</span><b class="${(it.s || 0) > 0.15 ? 'up' : (it.s || 0) < -0.15 ? 'dn' : ''}">${esc(it.n || k)}</b><span class="n" style="display:block;font-size:.85rem">${it.v != null ? it.v : '—'}</span><span class="mu" style="font-size:.68rem">${esc(it.t || '')}</span></div>`).join('')}</div>
  ${x.roles ? `<div class="chips" style="margin-top:8px">${Object.entries(x.roles).map(([k, v]) => H.chip(esc(k) + ' ' + v, v >= 15 ? 'up' : v <= -15 ? 'dn' : 'am')).join('')}</div>` : ''}`);
} };

/* ── central core / governor summary ── */
W.core = { needs: ['coin', 'deep', 'matrix', 'ready', 'ctx'], paint(el) {
  const s = SIG(), d = cur('deep'), r = R(ST.sel), ready = cur('ready'), ctx = cur('ctx');
  if (!s && !d) { el.innerHTML = skel; return; }
  const side = s ? s.side : 'WAIT', conf = p100(g(s, 'confidence', null));
  const gov = g(d, 'governor', null) || g(s, 'governor', null) || {};
  const grade = g(r, 'grade', g(s, 'grade', '—'));
  const cons = g(r, 'cons', g(s, 'score', null));
  const x10 = g(s, 'extras.x10', {}), x11 = g(s, 'extras.x11', {}), x12 = g(s, 'extras.x12', {});
  const veto = gov.veto || gov.blocked || g(s, 'warnings', []);
  wrap(el, `${H.head('هسته مرکزی تصمیم', 'Governor · Fuse · x10/x11/x12', 'ana:gov')}
  <div class="row" style="border:0;padding:0 0 8px"><span class="g">${sdp(side)} <span class="tag">درجه ${esc(grade)}</span></span><b class="n ${cls(side)}">${num(cons) ? sg(cons, 0) : '—'}</b></div>
  ${H.meter(cons)}
  <div class="kv c3" style="margin-top:10px">
    ${kv('اطمینان', N(num(conf) ? fmt(conf, 0) + '٪' : '—'))}
    ${kv('کیفیت x10', N(x10.quality != null ? x10.quality : '—'), x10.quality >= 60 ? 'up' : x10.quality < 40 ? 'dn' : 'am')}
    ${kv('زمان‌بندی x10', N(x10.timing != null ? sg(x10.timing, 0) : '—'), (x10.timing || 0) >= 20 ? 'up' : (x10.timing || 0) <= -20 ? 'dn' : '')}
    ${kv('امتیاز x12', N(x12.score != null ? sg(x12.score, 0) : '—'), (x12.score || 0) >= 20 ? 'up' : (x12.score || 0) <= -20 ? 'dn' : '')}
    ${kv('x11 موارد', N(x11.n || Object.keys(x11.items || {}).length || '—'))}
    ${kv('آمادگی', N(g(ready, 'score', g(ready, 'ready', '—'))))}
  </div>
  ${gov.reason || gov.note ? `<div class="note">${esc(gov.reason || gov.note)}</div>` : ''}
  ${(Array.isArray(veto) ? veto : []).slice(0, 4).map(w => H.chip(esc(typeof w === 'string' ? w : (w.msg || w.reason || '')), 'am')).join('') || ''}
  <div class="acts" style="margin-top:8px"><button class="btn s o" data-go="ana:sig">سیگنال کامل</button><button class="btn s o" data-go="ana:gov">حاکم</button><button class="btn s o" data-go="ana:x12">x12</button><button class="btn s o" data-go="ai:ready">آمادگی</button></div>`);
} };

W.gov = { needs: ['deep', 'coin'], paint(el) {
  const d = cur('deep'), s = SIG();
  const gov = g(d, 'governor', null) || g(s, 'governor', null);
  if (!gov && !s) { el.innerHTML = skel; return; }
  wrap(el, `${H.head('حاکم مرکزی (Governor)', '', 'ana:gov')}
  <div class="kv c3">${kv('نسخه', N(esc(gov && gov.version || '—')))}${kv('طرف', N(esc(gov && (gov.side || gov.decision) || g(s, 'side', '—'))))}${kv('لبه', N(fmt(g(gov, 'edge', null), 2)))}
  ${kv('حاشیه', N(fmt(g(gov, 'margin', null), 2)))}${kv('اعتماد', N(fmt(g(gov, 'confidence', g(s, 'confidence', null)), 2)))}${kv('منتشر', N(gov && gov.published ? 'بله' : 'خیر'), gov && gov.published ? 'up' : 'dn')}
  ${kv('پشتیبانی', N(g(gov, 'support', '—')))}${kv('مخالف', N(g(gov, 'oppose', '—')))}${kv('تضاد', N(g(gov, 'contradiction', null) != null ? Math.round((+g(gov, 'contradiction', 0)) * 100) + '٪' : '—'), (+g(gov, 'contradiction', 0)) >= 0.5 ? 'dn' : 'up')}</div>
  ${(() => { const smc = g(s, 'extras.smc', null); if (!smc) return ''; const nob = smc.nearest_ob, nf = smc.nearest_fvg; return `<div class="sh">SMC · Order Block / FVG</div><div class="kv c2">${kv('نزدیک‌ترین OB', N(nob ? (nob.type + ' @ ' + fp(nob.mid)) : '—'))}${kv('نزدیک‌ترین FVG', N(nf ? (nf.type + ' @ ' + fp(nf.mid)) : '—'))}</div>`; })()}
  ${gov && gov.weights ? `<div class="sh">وزن‌ها</div><div class="kv c3">${Object.entries(gov.weights).map(([k, v]) => kv(esc(k), N(fmt(v, 2)))).join('')}</div>` : ''}
  <div class="note">${esc(g(gov, 'reason', g(gov, 'note', g(s, 'summary', ''))))}</div>`);
} };

W.evd = { needs: ['ev', 'log'], paint(el) {
  const ev = cur('ev'), log = cur('log');
  const a = g(ev, 'agg', null);
  wrap(el, `${H.head('شواهد و کارنامه', '', 'ai:trk')}
  ${a ? `<div class="kv c3">${kv('معاملات', N(a.trades))}${kv('نرخ برد', N(fmt(a.win, 1) + '٪'))}${kv('میانگین R', N(sg(a.avg_r, 2)), a.avg_r >= 0 ? 'up' : 'dn')}${kv('معنادار', N(a.significant ? 'بله' : 'خیر'), a.significant ? 'up' : 'am')}</div>` : empty('شواهد هنوز آماده نیست')}
  <div class="note">سیگنال‌های ثبت‌شده: ${N(g(log, 'total', 0))} · نتیجه‌دار: ${N(g(log, 'resolved', 0))}</div>`);
} };

})();
