"""TITAN PRO Clean — configuration. All persistent data lives ONLY under XXX/."""
from __future__ import annotations
import os
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# ── ALL data must live inside XXX only ─────────────────────────────────────
DATA_DIR = Path(os.getenv("TITAN_DATA", str(ROOT / "XXX"))).expanduser()
SECRET_DIR = Path(os.getenv("TITAN_SECRET", str(DATA_DIR / "secret"))).expanduser()
for _d in (DATA_DIR, SECRET_DIR):
    _d.mkdir(parents=True, exist_ok=True)

HOST = os.getenv("TITAN_HOST", "127.0.0.1")
PORT = int(os.getenv("TITAN_PORT", "8080"))
VERSION = "1.7.2-UI-OVERLAP-SMC"

# ── indicators ─────────────────────────────────────────────────────────────
ADV_INDICATORS = os.getenv("TITAN_ADV", "1") != "0"

DEFAULT_COINS = [
    "BTC/USDT", "ETH/USDT", "BNB/USDT", "XRP/USDT", "SOL/USDT",
    "ADA/USDT", "DOGE/USDT", "AVAX/USDT", "LINK/USDT", "NEAR/USDT",
    "SUI/USDT", "TAO/USDT", "AAVE/USDT", "BCH/USDT", "XLM/USDT",
    "TRX/USDT", "SHIB/USDT", "PEPE/USDT", "WIF/USDT", "FLOKI/USDT",
    "CAKE/USDT", "HYPE/USDT", "ZEC/USDT", "XAUT/USDT",
]
SYMBOL_RE = re.compile(r"^[A-Z0-9]{2,14}USDT$")


def to_symbol(coin: str) -> str:
    return str(coin).replace("/", "").replace("-", "").strip().upper()


def to_base(coin: str) -> str:
    c = str(coin).upper()
    if "/" in c:
        return c.split("/")[0]
    return c[:-4] if c.endswith("USDT") else c


def valid_symbol(sym: str) -> bool:
    return bool(SYMBOL_RE.match(to_symbol(sym)))


DEFAULT_SYMBOLS = [to_symbol(c) for c in DEFAULT_COINS]
MAX_WATCHLIST = 30

# ── timeframes ─────────────────────────────────────────────────────────────
TIMEFRAMES = ["15m", "1h", "4h", "1d"]
TF_PRIORITY = ["1h", "4h", "1d", "15m"]
TF_WEIGHT = {"15m": 0.15, "1h": 0.28, "4h": 0.32, "1d": 0.25}

KLINE_LIMIT = 280
CHART_KLINES = 160
FORECAST_CANDLES = 10
MC_PATHS = 400                  # Monte-Carlo paths (lighter than 600)
SIDE_THRESHOLD = 18.0

# ── risk & paper / live readiness ──────────────────────────────────────────
STARTING_CAPITAL = 10_000.0
DEFAULT_LEVERAGE = 3
MAX_LEVERAGE = 10                    # conservative for real readiness
FEE_TAKER = 0.0006
FEE_MAKER = 0.0002
SLIPPAGE = 0.0005
RISK_PER_TRADE_PCT = 0.8
MAX_RISK_PCT_PER_TRADE = 1.5
MAX_OPEN_POSITIONS = 4
MAX_MARGIN_PCT_PER_POS = 20.0
MAX_TOTAL_MARGIN_PCT = 50.0
DAILY_LOSS_LIMIT_PCT = 4.0
PARTIALS = (0.40, 0.35, 0.25)

# auto-trade gates (stricter for real readiness)
AUTO_MIN_CONF = 62.0
AUTO_MIN_RR = 1.6
AUTO_COOLDOWN_SEC = 240
AUTO_MIN_GRADE = "B"

# ── scan & network ─────────────────────────────────────────────────────────
SCAN_INTERVAL_SEC = 45
CPU_WORKERS = int(os.getenv("TITAN_CPU_WORKERS", "4"))
CONNECT_TIMEOUT = 1.2
READ_TIMEOUT = 2.6
RACE_BUDGET = 4.0
SOURCE_ORDER = ["okx", "mexc", "bybit", "gate", "binance"]

# ── Gemini only (no other AI providers) ────────────────────────────────────
GEMINI_MODELS = [
    "gemini-2.0-flash",
    "gemini-1.5-flash",
    "gemini-1.5-flash-latest",
]
AI_TIMEOUT_SEC = 12

# ── storage limits (keep memory light) ─────────────────────────────────────
SIGLOG_MAX = 400                 # max signal log entries kept
PAPER_HISTORY_MAX = 300          # max closed trades kept
EQUITY_LOG_MAX = 400
ALERTS_MAX = 80
CACHE_MAX_SYMBOLS = 40
