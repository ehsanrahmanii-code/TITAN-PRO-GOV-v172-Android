"""Gemini AI opinion layer — optional, graceful without key."""
from __future__ import annotations
import json
import time
from pathlib import Path
from typing import Any
import requests

from app.config import SECRET_DIR, GEMINI_MODELS, AI_TIMEOUT_SEC

_CACHE: dict[str, tuple[float, dict]] = {}
_CACHE_TTL = 300.0


def _load_key() -> str:
    for name in ("gemini_api_key.txt", "gemini_key.txt", "GEMINI_API_KEY.txt"):
        p = SECRET_DIR / name
        if p.exists():
            key = p.read_text(encoding="utf-8").strip()
            if key:
                return key
    import os
    return (os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY") or "").strip()


def _call_gemini(prompt: str, key: str) -> str:
    last_err = ""
    for model in GEMINI_MODELS:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
        try:
            r = requests.post(
                url,
                headers={"x-goog-api-key": key},               # header, not URL (keys leak into logs)
                json={
                    "contents": [{"parts": [{"text": prompt}]}],
                    "generationConfig": {"temperature": 0.3, "maxOutputTokens": 700,
                                         "responseMimeType": "application/json"},
                },
                timeout=AI_TIMEOUT_SEC,
            )
            if r.status_code != 200:
                last_err = f"{model}: HTTP {r.status_code}"
                continue
            data = r.json()
            parts = (((data.get("candidates") or [{}])[0].get("content") or {}).get("parts") or [])
            text = "".join(p.get("text", "") for p in parts).strip()
            if text:
                return text
            last_err = f"{model}: empty"
        except Exception as e:
            last_err = f"{model}: {e}"
    raise RuntimeError(last_err or "gemini failed")


def _parse_json_loose(text: str) -> dict:
    text = text.strip()
    if text.startswith("```"):
        lines = text.split("\n")
        lines = [l for l in lines if not l.strip().startswith("```")]
        text = "\n".join(lines)
    try:
        return json.loads(text)
    except Exception:
        start, end = text.find("{"), text.rfind("}")
        if start >= 0 and end > start:
            try:
                return json.loads(text[start:end + 1])
            except Exception:
                pass
    return {"opinion": text[:800], "side": "WAIT", "confidence": 0.4}


def ai_opinion(symbol: str, deep: dict[str, Any], ticker: dict | None = None) -> dict[str, Any]:
    """
    Returns structured AI view. Without API key returns rule-based summary.
    """
    cache_key = f"{symbol}:{deep.get('primary_tf')}:{deep.get('consensus_score')}:{deep.get('verdict')}"
    now = time.time()
    if cache_key in _CACHE and now - _CACHE[cache_key][0] < _CACHE_TTL:
        return _CACHE[cache_key][1]

    sig = deep.get("signal") or {}
    key = _load_key()

    if not key:
        result = {
            "ok": True,
            "source": "local",
            "side": sig.get("side", "WAIT"),
            "confidence": sig.get("confidence", 0.4),
            "summary": deep.get("narrative") or "تحلیل محلی بدون کلید Gemini",
            "bullets": (sig.get("reasons") or [])[:5],
            "risk_note": "کلید Gemini در XXX/secret/gemini_api_key.txt قرار دهید برای نظر هوش مصنوعی.",
        }
        _CACHE[cache_key] = (now, result)
        return result

    price = (ticker or {}).get("price") or sig.get("entry")
    prompt = f"""You are a professional crypto analyst. Reply ONLY valid JSON with keys:
side (LONG|SHORT|WAIT), confidence (0-1), summary (Persian, 2-3 sentences), bullets (array of 3 short Persian points), risk_note (Persian one line).

Coin: {symbol}
Price: {price}
MTF verdict: {deep.get('verdict')} consensus={deep.get('consensus_score')} conviction={deep.get('conviction')} veto={deep.get('veto')}
Technical signal: {sig.get('side')} score={sig.get('score')} conf={sig.get('confidence')}
Entry/SL/TP: {sig.get('entry')} / {sig.get('stop')} / {sig.get('tp1')}-{sig.get('tp2')}
Regime: {deep.get('regime')}
TF agreement: {deep.get('agreement')} (L={deep.get('long_count')} S={deep.get('short_count')} W={deep.get('wait_count')})
Reasons: {', '.join(sig.get('reasons') or [])}
Forecast: {deep.get('forecast', {}).get('direction')} move={deep.get('forecast', {}).get('expected_move_pct')}%
"""
    try:
        text = _call_gemini(prompt, key)
        data = _parse_json_loose(text)
        side = str(data.get("side", "WAIT")).upper()
        if side not in ("LONG", "SHORT", "WAIT"):
            side = "WAIT"
        result = {
            "ok": True,
            "source": "gemini",
            "side": side,
            "confidence": float(data.get("confidence") or 0.5),
            "summary": str(data.get("summary") or "")[:600],
            "bullets": list(data.get("bullets") or [])[:5],
            "risk_note": str(data.get("risk_note") or "")[:200],
        }
    except Exception as e:
        result = {
            "ok": False,
            "source": "error",
            "side": sig.get("side", "WAIT"),
            "confidence": sig.get("confidence", 0.4),
            "summary": deep.get("narrative") or "خطا در Gemini — نمایش تحلیل تکنیکال",
            "bullets": (sig.get("reasons") or [])[:5],
            "risk_note": str(e)[:160],
        }

    if result.get("ok"):
        _CACHE[cache_key] = (now, result)
    return result
