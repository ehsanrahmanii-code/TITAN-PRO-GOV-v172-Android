"""Multi-timeframe fusion: weighted consensus, higher-TF veto, coherent verdict + narrative."""
from __future__ import annotations
from typing import Any
import pandas as pd

from app.config import TF_WEIGHT, SIDE_THRESHOLD, FORECAST_CANDLES
from app.analysis.technicals import analyze
from app.analysis.forecast import forecast_summary
from app.analysis.grade import fuse, grade_from
from app.engine.governor import govern

REGIME_FA = {"trend": "روندی", "range": "رنج", "neutral": "گذار", "unknown": "نامشخص"}
SIDE_SHORT = {"LONG": "خرید", "SHORT": "فروش", "WAIT": "انتظار"}
SIDE_FA = {"LONG": "خرید (LONG)", "SHORT": "فروش (SHORT)", "WAIT": "انتظار"}


def deep_analyze(frames: dict[str, pd.DataFrame], symbol: str, primary_tf: str = "1h",
                 prices: dict[str, float] | None = None, ctx: dict | None = None) -> dict[str, Any]:
    prices = prices or {}
    sigs, fcs = {}, {}
    for tf, df in frames.items():
        if df is None or len(df) < 60:
            continue
        s = analyze(df, symbol, tf, price=prices.get(tf))
        sigs[tf] = s
        lv = {"entry": s.entry, "stop": s.stop, "tp1": s.tp1, "tp2": s.tp2, "tp3": s.tp3} if s.side != "WAIT" else None
        fcs[tf] = forecast_summary(df, s.side, n_ahead=FORECAST_CANDLES, seed_key=f"{symbol}{tf}", levels=lv)
    if not sigs:
        return {"symbol": symbol, "primary_tf": primary_tf, "signal": None, "all_tf": {}, "verdict": "WAIT",
                "consensus_score": 0, "conviction": 0, "agreement": "mixed", "regime": "unknown", "narrative": "داده کافی نیست"}

    consensus, side, note = fuse({t: x.score for t, x in sigs.items()}, (ctx or {}).get("bias", 0.0))
    wsum = sum(TF_WEIGHT.get(t, .2) for t in sigs)
    sides = [s.side for s in sigs.values()]
    ln, sn = sides.count("LONG"), sides.count("SHORT")
    agreement = ("strong_long" if ln >= 3 else "strong_short" if sn >= 3 else
                 "lean_long" if ln > sn else "lean_short" if sn > ln else "mixed")
    aligned = sum(TF_WEIGHT.get(t, .2) for t, s in sigs.items() if (s.score > 10) == (consensus > 0) and abs(s.score) > 10) / wsum
    conviction = round(min(0.97, 0.55 * min(1, abs(consensus) / 70) + 0.45 * aligned), 3)

    ptf = primary_tf if primary_tf in sigs else next(iter(sigs))
    prim = sigs[ptf]
    plan = prim
    if side in ("LONG", "SHORT") and prim.side != side:
        plan = analyze(frames[ptf], symbol, ptf, price=prices.get(ptf), force_side=side)
    regime = prim.regime
    pf = fcs[ptf]
    if side in ("LONG", "SHORT"):                                   # re-run the path statistics for the plan actually proposed
        pf = forecast_summary(frames[ptf], side, n_ahead=FORECAST_CANDLES, seed_key=f"{symbol}{ptf}",
                              levels={"entry": plan.entry, "stop": plan.stop, "tp1": plan.tp1, "tp2": plan.tp2, "tp3": plan.tp3})
        fcs[ptf] = pf
    sd = {t: x.to_dict() for t, x in sigs.items()}
    if side in ("LONG", "SHORT") and plan is not prim:
        sd[ptf] = plan.to_dict()
    gr = grade_from(sd, fcs, side, consensus, ptf, ctx)
    # Central Governor — sole publisher over fuse side
    gov = govern(sd, fcs, ctx, gr if isinstance(gr, dict) else {}, symbol=symbol)
    pub_side = gov.get("side") or "WAIT"
    if not gov.get("published"):
        pub_side = "WAIT"

    parts = [f"رژیم {REGIME_FA.get(regime, regime)} · اجماع وزنی {consensus:+.0f} → {SIDE_FA[side]}"]
    if note:
        parts.append(note)
    if gov.get("vetoes"):
        parts.append("وتوی حاکم: " + " · ".join(gov["vetoes"][:3]))
    if gov.get("reasons"):
        parts.append("حاکم: " + " · ".join(gov["reasons"][:3]))
    # V84-hardened diagnostics
    if gov.get("published") and gov.get("support") is not None:
        parts.append(f"پشتیبانی {gov.get('support')} · تضاد {gov.get('contradiction', 0):.0%}")
    parts.append("تایم‌فریم‌ها: " + " | ".join(f"{t}: {SIDE_SHORT[s.side]} {s.score:+.0f}" for t, s in sigs.items()))
    parts.append(f"احتمال صعود ({ptf}، ۳۲ کندل) {pf['prob_up'] * 100:.0f}٪ · حرکت میانه {pf['expected_move_pct']:+.2f}٪")
    if pub_side != "WAIT":
        parts.append(f"ورود {plan.entry} · حدضرر {plan.stop} · اهداف {plan.tp1}/{plan.tp2}/{plan.tp3} · R:R {plan.risk_reward}")
    if ctx and ctx.get("parts"):
        parts.append(f"بافت بازار {ctx['bias']:+.2f}: " + " · ".join(p_["t"] for p_ in sorted(ctx["parts"], key=lambda x: -abs(x["v"] * x["w"]))[:2]))
    if prim.reasons:
        parts.append("دلایل: " + " · ".join(prim.reasons[:4]))

    # If governor publishes WAIT, keep plan levels but mark verdict WAIT for consistency
    out_signal = plan.to_dict()
    if pub_side == "WAIT" and out_signal.get("side") in ("LONG", "SHORT"):
        out_signal = dict(out_signal)
        out_signal["side"] = "WAIT"
        out_signal["warnings"] = list(out_signal.get("warnings") or []) + list(gov.get("vetoes") or [])

    return {"symbol": symbol, "primary_tf": ptf, "signal": out_signal, "primary": prim.to_dict(),
            "forecast": pf, "all_tf": {t: s.to_dict() for t, s in sigs.items()}, "all_forecasts": fcs, "grade": gr,
            "consensus_score": round(consensus, 1), "conviction": conviction, "verdict": pub_side, "veto": note,
            "agreement": agreement, "regime": regime, "narrative": " — ".join(parts),
            "governor": gov, "fuse_side": side,
            "ctx": ctx, "long_count": ln, "short_count": sn, "wait_count": sides.count("WAIT")}
