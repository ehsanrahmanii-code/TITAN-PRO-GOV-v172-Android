"""TITAN x11 — structure & participation indicators that are NOT price-oscillator variations.

The core already holds ~60 OHLCV oscillators/averages (RSI, MACD, AO, UO, TRIX, HMA ...). Adding more of those would only double-count
the same information, so x11 adds information of a different kind:

  anchored_vwap  fair value measured from the last swing (who is in profit since the turn?)       -> structure
  donchian       55-bar breakout / channel position (turtle breakout state)                        -> trend
  prior_levels   previous day high/low: acceptance above/below and liquidity sweeps (stop-runs)   -> structure
  rvol           volume vs the SAME hour-of-day median (participation behind the last candle)      -> volume
  persistence    share of the last 20 closes above EMA20 (trend persistence)                      -> trend

Every item is {v, s (-1..+1), t (Persian text), role}. Everything is defensive: a failing item is skipped.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

NAMES = {"avwap": "VWAP لنگرشده از آخرین سوینگ", "donch": "کانال دانچیان ۵۵", "prior": "سطوح روز قبل و شکار نقدینگی", "rvol": "حجم نسبی هم‌ساعت",
         "persist": "پایداری روند (۲۰ کندل)"}
ROLES = {"avwap": "structure", "donch": "trend", "prior": "structure", "rvol": "volume", "persist": "trend"}


def _c(x, a=-1.0, b=1.0) -> float:
    return float(max(a, min(b, x)))


def _fx(x) -> float | None:
    try:
        x = float(x)
        return float(f"{x:.8g}") if np.isfinite(x) else None
    except (TypeError, ValueError):
        return None


def _atr(df: pd.DataFrame, n: int = 14) -> pd.Series:
    pc = df["close"].shift()
    tr = pd.concat([df["high"] - df["low"], (df["high"] - pc).abs(), (df["low"] - pc).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / n, adjust=False).mean()


def _last_swings(h: np.ndarray, l: np.ndarray, k: int = 3) -> tuple[int | None, int | None]:
    """Indices of the most recent confirmed swing low / swing high (fractal with k bars each side; confirmed -> no repaint)."""
    lo_i = hi_i = None
    for i in range(len(h) - k - 1, k - 1, -1):
        if lo_i is None and l[i] < l[i - k:i].min() and l[i] <= l[i + 1:i + k + 1].min():
            lo_i = i
        if hi_i is None and h[i] > h[i - k:i].max() and h[i] >= h[i + 1:i + k + 1].max():
            hi_i = i
        if lo_i is not None and hi_i is not None:
            break
    return lo_i, hi_i


def anchored_vwap(df: pd.DataFrame) -> dict:
    h, l, c, v = (df[k].values.astype(float) for k in ("high", "low", "close", "volume"))
    lo_i, hi_i = _last_swings(h, l)
    if lo_i is None and hi_i is None:
        return {}
    tp = (h + l + c) / 3
    last, a = float(c[-1]), float(_atr(df).iloc[-1]) or float(c[-1]) * 0.01

    def avwap(i):
        vv = v[i:]
        return float((tp[i:] * vv).sum() / vv.sum()) if vv.sum() > 0 else None
    al, ah = (avwap(lo_i) if lo_i is not None else None), (avwap(hi_i) if hi_i is not None else None)
    ups = [x for x in (al, ah) if x is not None]
    above, below = sum(last > x for x in ups), sum(last < x for x in ups)
    if above == len(ups):
        s, t = 0.6, "قیمت بالای VWAP لنگرشده (خریداران از سوینگ در سودند)"
    elif below == len(ups):
        s, t = -0.6, "قیمت زیر VWAP لنگرشده (فروشندگان از سوینگ در سودند)"
    else:
        near = al if (lo_i or -1) > (hi_i or -1) else ah                      # anchor of the most recent swing leg
        s, t = (0.25 if last > near else -0.25), "بین دو VWAP لنگرشده؛ جهت از آخرین سوینگ"
    dist = (last - (al if al is not None else ah)) / a
    return {"v": _fx(dist), "s": s, "t": t, "avwap_low": _fx(al), "avwap_high": _fx(ah), "anchor_low": int(lo_i) if lo_i is not None else None,
            "anchor_high": int(hi_i) if hi_i is not None else None}


def donchian(df: pd.DataFrame, n: int = 55) -> dict:
    if len(df) < n + 5:
        return {}
    h, l, c = df["high"].values.astype(float), df["low"].values.astype(float), df["close"].values.astype(float)
    hi, lo = float(h[-n - 1:-1].max()), float(l[-n - 1:-1].min())              # channel of the PREVIOUS n bars (no look-ahead)
    last = float(c[-1])
    pos = (last - lo) / (hi - lo) if hi > lo else 0.5
    if last > hi:
        s, t = 1.0, f"شکست سقف {n} کندل"
    elif last < lo:
        s, t = -1.0, f"شکست کف {n} کندل"
    else:
        s, t = _c((pos - 0.5) * 0.8), f"موقعیت در کانال {n} کندل: {pos * 100:.0f}٪"
    return {"v": _fx(pos), "s": s, "t": t, "hi": _fx(hi), "lo": _fx(lo)}


def prior_levels(df: pd.DataFrame, tf: str) -> dict:
    t = pd.to_datetime(df["open_time"])
    if tf == "1d":
        if len(df) < 3:
            return {}
        pdh, pdl = float(df["high"].iloc[-2]), float(df["low"].iloc[-2])
        recent = df.iloc[-1:]
    else:
        day = t.dt.floor("D")
        today = day.iloc[-1]
        prev = df[day < today]
        if prev.empty:
            return {}
        pday = day[day < today].iloc[-1]
        pd_ = prev[day[day < today] == pday]
        if len(pd_) < 3:
            return {}
        pdh, pdl = float(pd_["high"].max()), float(pd_["low"].min())
        recent = df.tail(12)
    last = float(df["close"].iloc[-1])
    swept_hi = bool((recent["high"] > pdh).any() and last < pdh)
    swept_lo = bool((recent["low"] < pdl).any() and last > pdl)
    if swept_hi and not swept_lo:
        s, t = -0.8, "شکار نقدینگی بالای سقف روز قبل و بازگشت به زیر آن"
    elif swept_lo and not swept_hi:
        s, t = 0.8, "شکار نقدینگی زیر کف روز قبل و بازگشت به بالای آن"
    elif last > pdh:
        s, t = 0.4, "قیمت بالای سقف روز قبل (پذیرش بالاتر)"
    elif last < pdl:
        s, t = -0.4, "قیمت زیر کف روز قبل (پذیرش پایین‌تر)"
    else:
        s, t = 0.0, "داخل دامنهٔ روز قبل"
    return {"v": _fx((last - pdl) / (pdh - pdl)) if pdh > pdl else None, "s": s, "t": t, "pdh": _fx(pdh), "pdl": _fx(pdl), "swept_hi": swept_hi, "swept_lo": swept_lo}


def rvol(df: pd.DataFrame, tf: str) -> dict:
    v = df["volume"].astype(float)
    if len(df) < 40 or v.iloc[-1] < 0:
        return {}
    t = pd.to_datetime(df["open_time"])
    if tf in ("15m", "1h", "4h"):
        key = t.dt.hour * 60 + t.dt.minute
        same = v[(key == key.iloc[-1]).values].iloc[:-1].tail(30)
        base = float(same.median()) if len(same) >= 5 else float(v.iloc[-41:-1].median())
    else:
        base = float(v.iloc[-21:-1].median())
    if base <= 0:
        return {}
    r = float(v.iloc[-1]) / base
    o, c = float(df["open"].iloc[-1]), float(df["close"].iloc[-1])
    d = 1 if c > o else -1 if c < o else 0
    s = d * _c((r - 1.0) / 1.5, 0.0, 1.0) * 0.8
    t = f"حجم {r:.1f}× میانهٔ هم‌ساعت" + (" · مشارکت ضعیف" if r < 0.6 else " · مشارکت بالا" if r > 1.6 else "")
    return {"v": _fx(r), "s": s, "t": t, "rvol": _fx(r)}


def persistence(df: pd.DataFrame) -> dict:
    c = df["close"].astype(float)
    if len(c) < 40:
        return {}
    e = c.ewm(span=20, adjust=False).mean()
    frac = float((c.tail(20) > e.tail(20)).mean())
    s = _c((frac - 0.5) * 2.0) * 0.8 if abs(frac - 0.5) >= 0.2 else 0.0
    return {"v": _fx(frac), "s": s, "t": f"{frac * 100:.0f}٪ از ۲۰ کندل اخیر بالای EMA20"}


def compute(df: pd.DataFrame, tf: str = "1h") -> dict:
    fns = {"avwap": lambda: anchored_vwap(df), "donch": lambda: donchian(df), "prior": lambda: prior_levels(df, tf), "rvol": lambda: rvol(df, tf),
           "persist": lambda: persistence(df)}
    items: dict[str, dict] = {}
    for k, fn in fns.items():
        try:
            r = fn()
        except Exception:                                    # noqa: BLE001 - an indicator must never break a signal
            r = {}
        if r:
            r.update(n=NAMES[k], role=ROLES[k])
            items[k] = r
    if not items:
        return {}
    pr, av, dn = items.get("prior") or {}, items.get("avwap") or {}, items.get("donch") or {}
    levels = {k: v for k, v in {"pdh": pr.get("pdh"), "pdl": pr.get("pdl"), "avwap_low": av.get("avwap_low"), "avwap_high": av.get("avwap_high"),
                                "don_hi": dn.get("hi"), "don_lo": dn.get("lo")}.items() if v is not None}
    return {"items": items, "levels": levels, "rvol": (items.get("rvol") or {}).get("rvol"), "n": len(items)}
