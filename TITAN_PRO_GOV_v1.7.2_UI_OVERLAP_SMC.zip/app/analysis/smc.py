"""Lightweight Smart Money Concepts helpers — Order Block / FVG + BTC correlation filter.

Ported (simplified) from TITAN PRO V84 technicals_core:
  - detect_order_blocks_fvg: pure dataframe, no network
  - btc_corr_from_frames: Pearson on provided close series
  - apply_btc_filter: soft veto for high-beta alts against BTC trend in high vol

Keeps the clean engine free of V84's heavy fetch/DB dependencies.
"""
from __future__ import annotations
from typing import Any
import math

import numpy as np
import pandas as pd


def _atr_series(df: pd.DataFrame, n: int = 14) -> pd.Series:
    h, l, c = df["high"], df["low"], df["close"]
    tr = pd.concat([(h - l), (h - c.shift()).abs(), (l - c.shift()).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / n, min_periods=n, adjust=False).mean()


def detect_order_blocks_fvg(df: pd.DataFrame, lookback: int = 40) -> dict[str, Any]:
    """Detect recent Fair Value Gaps and Order Blocks near price.

    Returns order_blocks, fvgs (nearest first), nearest_ob, nearest_fvg.
    """
    empty = {"order_blocks": [], "fvgs": [], "nearest_ob": None, "nearest_fvg": None, "price": 0.0}
    try:
        if df is None or len(df) < max(20, lookback // 2):
            return empty
        d = df.tail(max(lookback + 5, 30)).reset_index(drop=True)
        o, h, l, c = (d[k].astype(float) for k in ("open", "high", "low", "close"))
        atr = _atr_series(d).fillna(method="bfill").fillna(0.0)
        price = float(c.iloc[-1])
        obs: list[dict] = []
        fvgs: list[dict] = []
        n = len(d)
        start = max(2, n - lookback)
        for i in range(start, n):
            atr_i = float(atr.iloc[i]) or (price * 0.002)
            move = float(c.iloc[i] - c.iloc[i - 1])
            # Bullish FVG: gap up between candle i-2 high and i low
            if i >= 2:
                gap_lo, gap_hi = float(h.iloc[i - 2]), float(l.iloc[i])
                if gap_hi - gap_lo > 0.15 * atr_i:
                    # actually bullish FVG is low of current > high of i-2
                    if float(l.iloc[i]) > float(h.iloc[i - 2]):
                        glo, ghi = float(h.iloc[i - 2]), float(l.iloc[i])
                        fvgs.append({
                            "type": "bullish_fvg",
                            "low": round(glo, 8), "high": round(ghi, 8),
                            "mid": round((glo + ghi) / 2, 8), "index": i,
                        })
                if float(h.iloc[i]) < float(l.iloc[i - 2]):
                    glo, ghi = float(h.iloc[i]), float(l.iloc[i - 2])
                    fvgs.append({
                        "type": "bearish_fvg",
                        "low": round(glo, 8), "high": round(ghi, 8),
                        "mid": round((glo + ghi) / 2, 8), "index": i,
                    })
            # Order blocks: impulse after opposite candle
            if move > 1.2 * atr_i and float(c.iloc[i - 1]) < float(o.iloc[i - 1]):
                obs.append({
                    "type": "bullish_ob",
                    "low": round(float(l.iloc[i - 1]), 8),
                    "high": round(float(h.iloc[i - 1]), 8),
                    "mid": round((float(l.iloc[i - 1]) + float(h.iloc[i - 1])) / 2, 8),
                    "index": i - 1,
                })
            if move < -1.2 * atr_i and float(c.iloc[i - 1]) > float(o.iloc[i - 1]):
                obs.append({
                    "type": "bearish_ob",
                    "low": round(float(l.iloc[i - 1]), 8),
                    "high": round(float(h.iloc[i - 1]), 8),
                    "mid": round((float(l.iloc[i - 1]) + float(h.iloc[i - 1])) / 2, 8),
                    "index": i - 1,
                })

        def _dist(z: dict) -> float:
            return abs(price - float(z.get("mid") or price))

        obs = sorted(obs, key=_dist)[:4]
        fvgs = sorted(fvgs, key=_dist)[:4]
        return {
            "order_blocks": obs,
            "fvgs": fvgs,
            "nearest_ob": obs[0] if obs else None,
            "nearest_fvg": fvgs[0] if fvgs else None,
            "price": round(price, 8),
        }
    except Exception:  # noqa: BLE001
        return empty


def btc_corr_from_closes(alt_close: pd.Series, btc_close: pd.Series, lookback: int = 48) -> dict[str, Any]:
    """Pearson correlation of pct-change tails. Pure series, no network."""
    try:
        a = alt_close.astype(float).pct_change().dropna().tail(lookback)
        b = btc_close.astype(float).pct_change().dropna().tail(lookback)
        n = min(len(a), len(b))
        if n < 12:
            return {"corr": 0.0, "samples": n, "regime": "insufficient"}
        av = a.tail(n).values
        bv = b.tail(n).values
        if float(np.std(av)) < 1e-12 or float(np.std(bv)) < 1e-12:
            return {"corr": 0.0, "samples": n, "regime": "flat"}
        corr = float(np.corrcoef(av, bv)[0, 1])
        if not math.isfinite(corr):
            corr = 0.0
        regime = "high_beta" if corr >= 0.75 else "decoupled" if corr < 0.35 else "normal"
        return {"corr": round(corr, 3), "samples": n, "regime": regime}
    except Exception:  # noqa: BLE001
        return {"corr": 0.0, "samples": 0, "regime": "error"}


def apply_btc_filter(
    symbol: str,
    side: str,
    atr_pct: float,
    btc_side: str,
    corr_info: dict | None,
) -> dict[str, Any]:
    """Soft filter: high-vol alt fighting BTC while highly correlated → block.

    Returns {blocked: bool, reason: str, corr, regime}.
    """
    info = corr_info or {"corr": 0.0, "regime": "unknown"}
    corr = float(info.get("corr") or 0.0)
    regime = str(info.get("regime") or "")
    out = {"blocked": False, "reason": "", "corr": corr, "regime": regime}
    sym = str(symbol or "").upper().replace("/", "")
    if sym in ("BTCUSDT", "BTC"):
        return out
    if side not in ("LONG", "SHORT"):
        return out
    # only act in elevated volatility and high correlation
    if atr_pct < 1.2 or corr < 0.70:
        return out
    btc = str(btc_side or "WAIT").upper()
    if side == "LONG" and btc == "SHORT":
        out["blocked"] = True
        out["reason"] = f"همبستگی بالا با BTC ({corr:.2f}) و روند BTC نزولی در نوسان بالا"
    elif side == "SHORT" and btc == "LONG":
        out["blocked"] = True
        out["reason"] = f"همبستگی بالا با BTC ({corr:.2f}) و روند BTC صعودی در نوسان بالا"
    return out


def smc_score_boost(side: str, smc: dict, price: float) -> tuple[float, str]:
    """Small directional boost when price is reacting from aligned OB/FVG."""
    if side not in ("LONG", "SHORT") or not smc or price <= 0:
        return 0.0, ""
    boost = 0.0
    note = ""
    nob = smc.get("nearest_ob") or {}
    nf = smc.get("nearest_fvg") or {}
    # proximity within 0.4% of mid
    def near(z: dict) -> bool:
        mid = float(z.get("mid") or 0)
        return mid > 0 and abs(price - mid) / price < 0.004

    if nob and near(nob):
        t = nob.get("type") or ""
        if side == "LONG" and t == "bullish_ob":
            boost += 0.12
            note = "واکنش به Order Block صعودی"
        elif side == "SHORT" and t == "bearish_ob":
            boost += 0.12
            note = "واکنش به Order Block نزولی"
        elif side == "LONG" and t == "bearish_ob":
            boost -= 0.08
        elif side == "SHORT" and t == "bullish_ob":
            boost -= 0.08
    if nf and near(nf):
        t = nf.get("type") or ""
        if side == "LONG" and t == "bullish_fvg":
            boost += 0.08
            note = note or "داخل FVG صعودی"
        elif side == "SHORT" and t == "bearish_fvg":
            boost += 0.08
            note = note or "داخل FVG نزولی"
    return max(-0.2, min(0.2, boost)), note
